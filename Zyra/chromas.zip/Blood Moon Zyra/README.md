# Blood Moon Zyra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![143056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143056.png) | 143056 |
| ![143057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143057.png) | 143057 |
| ![143058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143058.png) | 143058 |
| ![143059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143059.png) | 143059 |
| ![143060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143060.png) | 143060 |
| ![143061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143061.png) | 143061 |
| ![143062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143062.png) | 143062 |
| ![143063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143063.png) | 143063 |