# Street Demons Zyra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![143047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143047.png) | 143047 |
| ![143048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143048.png) | 143048 |
| ![143049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143049.png) | 143049 |
| ![143050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143050.png) | 143050 |
| ![143051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143051.png) | 143051 |
| ![143052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143052.png) | 143052 |
| ![143053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143053.png) | 143053 |
| ![143054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143054.png) | 143054 |