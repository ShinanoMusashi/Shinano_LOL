# Mythmaker Zyra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![143037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143037.png) | 143037 |
| ![143038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143038.png) | 143038 |
| ![143039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143039.png) | 143039 |
| ![143040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143040.png) | 143040 |
| ![143041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143041.png) | 143041 |
| ![143042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143042.png) | 143042 |
| ![143043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143043.png) | 143043 |
| ![143044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143044.png) | 143044 |
| ![143045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143045.png) | 143045 |
| ![143065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143065.png) | 143065 |