# Spirit Blossom Zyra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![143066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143066.png) | 143066 |
| ![143067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143067.png) | 143067 |
| ![143068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143068.png) | 143068 |
| ![143069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143069.png) | 143069 |
| ![143070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143070.png) | 143070 |
| ![143071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143071.png) | 143071 |
| ![143072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143072.png) | 143072 |
| ![143073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/143/143073.png) | 143073 |