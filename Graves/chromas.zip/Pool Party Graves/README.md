# Pool Party Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104008.png) | 104008 |
| ![104009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104009.png) | 104009 |
| ![104010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104010.png) | 104010 |
| ![104011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104011.png) | 104011 |
| ![104012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104012.png) | 104012 |
| ![104013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104013.png) | 104013 |