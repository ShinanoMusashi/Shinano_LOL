# Battle Professor Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104027.png) | 104027 |
| ![104028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104028.png) | 104028 |
| ![104029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104029.png) | 104029 |
| ![104030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104030.png) | 104030 |
| ![104031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104031.png) | 104031 |
| ![104032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104032.png) | 104032 |
| ![104033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104033.png) | 104033 |
| ![104034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104034.png) | 104034 |