# Praetorian Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104019.png) | 104019 |
| ![104020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104020.png) | 104020 |
| ![104021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104021.png) | 104021 |
| ![104022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104022.png) | 104022 |
| ![104023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104023.png) | 104023 |
| ![104024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104024.png) | 104024 |