# Porcelain Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104046.png) | 104046 |
| ![104047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104047.png) | 104047 |
| ![104048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104048.png) | 104048 |
| ![104049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104049.png) | 104049 |
| ![104050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104050.png) | 104050 |
| ![104051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104051.png) | 104051 |
| ![104052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104052.png) | 104052 |
| ![104053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104053.png) | 104053 |
| ![104054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104054.png) | 104054 |