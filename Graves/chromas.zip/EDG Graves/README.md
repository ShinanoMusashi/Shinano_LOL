# EDG Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104043.png) | 104043 |