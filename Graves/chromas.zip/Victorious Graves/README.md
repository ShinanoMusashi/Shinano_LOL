# Victorious Graves Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![104015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104015.png) | 104015 |
| ![104016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104016.png) | 104016 |
| ![104017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/104/104017.png) | 104017 |