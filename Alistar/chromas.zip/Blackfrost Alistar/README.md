# Blackfrost Alistar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![12023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12023.png) | 12023 |
| ![12024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12024.png) | 12024 |
| ![12025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12025.png) | 12025 |
| ![12026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12026.png) | 12026 |
| ![12027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12027.png) | 12027 |
| ![12028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12028.png) | 12028 |