# Lunar Beast Alistar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![12030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12030.png) | 12030 |
| ![12031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12031.png) | 12031 |
| ![12032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12032.png) | 12032 |
| ![12033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12033.png) | 12033 |
| ![12034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12034.png) | 12034 |
| ![12035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12035.png) | 12035 |
| ![12036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12036.png) | 12036 |