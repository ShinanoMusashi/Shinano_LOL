# Moo Cow Alistar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![12011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12011.png) | 12011 |
| ![12012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12012.png) | 12012 |
| ![12013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12013.png) | 12013 |
| ![12014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12014.png) | 12014 |
| ![12015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12015.png) | 12015 |
| ![12016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12016.png) | 12016 |
| ![12017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12017.png) | 12017 |
| ![12018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/12/12018.png) | 12018 |