# High Noon Irelia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![39019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39019.png) | 39019 |
| ![39020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39020.png) | 39020 |
| ![39021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39021.png) | 39021 |
| ![39022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39022.png) | 39022 |
| ![39023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39023.png) | 39023 |
| ![39024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39024.png) | 39024 |
| ![39025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39025.png) | 39025 |