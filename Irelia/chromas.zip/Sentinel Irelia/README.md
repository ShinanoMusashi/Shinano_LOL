# Sentinel Irelia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![39027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39027.png) | 39027 |
| ![39028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39028.png) | 39028 |
| ![39029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39029.png) | 39029 |
| ![39030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39030.png) | 39030 |
| ![39031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39031.png) | 39031 |
| ![39032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39032.png) | 39032 |
| ![39033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39033.png) | 39033 |
| ![39034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39034.png) | 39034 |
| ![39035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39035.png) | 39035 |