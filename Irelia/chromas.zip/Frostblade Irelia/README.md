# Frostblade Irelia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![39014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39014.png) | 39014 |