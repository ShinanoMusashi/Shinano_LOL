# Mythmaker Irelia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![39038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39038.png) | 39038 |
| ![39039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39039.png) | 39039 |
| ![39040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39040.png) | 39040 |
| ![39041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39041.png) | 39041 |
| ![39042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39042.png) | 39042 |
| ![39043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39043.png) | 39043 |