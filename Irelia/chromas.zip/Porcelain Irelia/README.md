# Porcelain Irelia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![39046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39046.png) | 39046 |
| ![39047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39047.png) | 39047 |
| ![39048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39048.png) | 39048 |
| ![39049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39049.png) | 39049 |
| ![39050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39050.png) | 39050 |
| ![39051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39051.png) | 39051 |
| ![39052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39052.png) | 39052 |
| ![39053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39053.png) | 39053 |
| ![39054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/39/39054.png) | 39054 |