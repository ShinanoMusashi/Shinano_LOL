# Spirit Blossom Lillia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![876002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876002.png) | 876002 |
| ![876003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876003.png) | 876003 |
| ![876004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876004.png) | 876004 |
| ![876005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876005.png) | 876005 |
| ![876006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876006.png) | 876006 |
| ![876007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876007.png) | 876007 |
| ![876008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876008.png) | 876008 |
| ![876009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876009.png) | 876009 |