# Shan Hai Scrolls Lillia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![876020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876020.png) | 876020 |
| ![876021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876021.png) | 876021 |
| ![876022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876022.png) | 876022 |
| ![876023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876023.png) | 876023 |
| ![876024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876024.png) | 876024 |
| ![876025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876025.png) | 876025 |
| ![876026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876026.png) | 876026 |
| ![876027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876027.png) | 876027 |