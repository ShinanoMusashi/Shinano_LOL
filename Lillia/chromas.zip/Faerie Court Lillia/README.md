# Faerie Court Lillia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![876029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876029.png) | 876029 |
| ![876030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876030.png) | 876030 |
| ![876031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876031.png) | 876031 |
| ![876032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876032.png) | 876032 |
| ![876033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876033.png) | 876033 |
| ![876034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876034.png) | 876034 |
| ![876035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876035.png) | 876035 |
| ![876036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876036.png) | 876036 |