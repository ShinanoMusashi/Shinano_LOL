# Nightbringer Lillia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![876011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876011.png) | 876011 |
| ![876012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876012.png) | 876012 |
| ![876013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876013.png) | 876013 |
| ![876014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876014.png) | 876014 |
| ![876015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876015.png) | 876015 |
| ![876016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876016.png) | 876016 |
| ![876017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876017.png) | 876017 |
| ![876018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/876/876018.png) | 876018 |