# Freljord Sylas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![517009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517009.png) | 517009 |
| ![517010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517010.png) | 517010 |
| ![517011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517011.png) | 517011 |
| ![517012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517012.png) | 517012 |