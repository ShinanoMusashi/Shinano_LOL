# Ashen Slayer Sylas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![517035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517035.png) | 517035 |