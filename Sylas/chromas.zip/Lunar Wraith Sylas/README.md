# Lunar Wraith Sylas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![517002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517002.png) | 517002 |
| ![517003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517003.png) | 517003 |
| ![517004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517004.png) | 517004 |
| ![517005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517005.png) | 517005 |
| ![517006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517006.png) | 517006 |
| ![517007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517007.png) | 517007 |