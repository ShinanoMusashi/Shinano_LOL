# Winterblessed Sylas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![517037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517037.png) | 517037 |
| ![517038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517038.png) | 517038 |
| ![517039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517039.png) | 517039 |
| ![517040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517040.png) | 517040 |
| ![517041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517041.png) | 517041 |
| ![517042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517042.png) | 517042 |
| ![517043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517043.png) | 517043 |
| ![517044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517044.png) | 517044 |
| ![517045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517045.png) | 517045 |