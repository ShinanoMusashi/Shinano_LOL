# Battle Wolf Sylas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![517025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517025.png) | 517025 |
| ![517026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517026.png) | 517026 |
| ![517027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517027.png) | 517027 |
| ![517028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517028.png) | 517028 |
| ![517029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517029.png) | 517029 |
| ![517030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517030.png) | 517030 |
| ![517031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517031.png) | 517031 |
| ![517032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517032.png) | 517032 |
| ![517033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/517/517033.png) | 517033 |