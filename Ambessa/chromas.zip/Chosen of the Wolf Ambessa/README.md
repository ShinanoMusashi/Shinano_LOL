# Chosen of the Wolf Ambessa Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `799002` | ![799002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799002.png) | 1 |
| `799003` | ![799003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799003.png) | 2 |
| `799004` | ![799004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799004.png) | 3 |
| `799005` | ![799005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799005.png) | 4 |
| `799006` | ![799006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799006.png) | 5 |
| `799007` | ![799007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/799/799007.png) | 6 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.