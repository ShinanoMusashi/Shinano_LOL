# Old God Ivern Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![427012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427012.png) | 427012 |
| ![427013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427013.png) | 427013 |
| ![427014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427014.png) | 427014 |
| ![427015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427015.png) | 427015 |
| ![427016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427016.png) | 427016 |
| ![427017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427017.png) | 427017 |
| ![427018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427018.png) | 427018 |
| ![427019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427019.png) | 427019 |