# Dunkmaster Ivern Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![427003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427003.png) | 427003 |
| ![427004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427004.png) | 427004 |
| ![427005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427005.png) | 427005 |
| ![427006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427006.png) | 427006 |
| ![427007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427007.png) | 427007 |
| ![427008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427008.png) | 427008 |
| ![427009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427009.png) | 427009 |
| ![427010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427010.png) | 427010 |