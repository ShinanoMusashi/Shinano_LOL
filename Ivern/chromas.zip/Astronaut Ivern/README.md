# Astronaut Ivern Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![427021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427021.png) | 427021 |
| ![427022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427022.png) | 427022 |
| ![427023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427023.png) | 427023 |
| ![427024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427024.png) | 427024 |
| ![427025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427025.png) | 427025 |
| ![427026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427026.png) | 427026 |
| ![427027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427027.png) | 427027 |
| ![427028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/427/427028.png) | 427028 |