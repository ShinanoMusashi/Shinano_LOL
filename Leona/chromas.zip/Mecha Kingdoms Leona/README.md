# Mecha Kingdoms Leona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![89013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89013.png) | 89013 |
| ![89014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89014.png) | 89014 |
| ![89015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89015.png) | 89015 |
| ![89016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89016.png) | 89016 |
| ![89017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89017.png) | 89017 |
| ![89018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89018.png) | 89018 |
| ![89019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89019.png) | 89019 |
| ![89020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89020.png) | 89020 |