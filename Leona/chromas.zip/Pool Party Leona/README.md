# Pool Party Leona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![89005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89005.png) | 89005 |
| ![89006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89006.png) | 89006 |
| ![89007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89007.png) | 89007 |