# Crystalis Motus Leona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![89051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89051.png) | 89051 |