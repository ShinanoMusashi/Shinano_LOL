# High Noon Leona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![89044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89044.png) | 89044 |
| ![89045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89045.png) | 89045 |
| ![89046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89046.png) | 89046 |
| ![89047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89047.png) | 89047 |
| ![89048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89048.png) | 89048 |
| ![89049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/89/89049.png) | 89049 |