# Astronaut Maokai Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![57025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57025.png) | 57025 |
| ![57026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57026.png) | 57026 |
| ![57027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57027.png) | 57027 |
| ![57028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57028.png) | 57028 |
| ![57029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57029.png) | 57029 |
| ![57030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57030.png) | 57030 |
| ![57031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57031.png) | 57031 |
| ![57032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/57/57032.png) | 57032 |