# Dawnbringer Vex Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![711002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711002.png) | 711002 |
| ![711003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711003.png) | 711003 |
| ![711004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711004.png) | 711004 |
| ![711005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711005.png) | 711005 |
| ![711006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711006.png) | 711006 |
| ![711007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711007.png) | 711007 |
| ![711008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711008.png) | 711008 |
| ![711009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711009.png) | 711009 |