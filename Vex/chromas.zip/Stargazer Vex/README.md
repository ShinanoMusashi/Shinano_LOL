# Stargazer Vex Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![711021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711021.png) | 711021 |
| ![711022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711022.png) | 711022 |
| ![711023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711023.png) | 711023 |
| ![711024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711024.png) | 711024 |
| ![711025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711025.png) | 711025 |
| ![711026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711026.png) | 711026 |
| ![711027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711027.png) | 711027 |
| ![711028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711028.png) | 711028 |