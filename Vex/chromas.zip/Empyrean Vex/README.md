# Empyrean Vex Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![711011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711011.png) | 711011 |
| ![711012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711012.png) | 711012 |
| ![711013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711013.png) | 711013 |
| ![711014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711014.png) | 711014 |
| ![711015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711015.png) | 711015 |
| ![711016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711016.png) | 711016 |
| ![711017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711017.png) | 711017 |
| ![711018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711018.png) | 711018 |
| ![711019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/711/711019.png) | 711019 |