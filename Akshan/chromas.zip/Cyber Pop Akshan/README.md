# Cyber Pop Akshan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![166002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166002.png) | 166002 |
| ![166003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166003.png) | 166003 |
| ![166004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166004.png) | 166004 |
| ![166005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166005.png) | 166005 |
| ![166006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166006.png) | 166006 |
| ![166007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166007.png) | 166007 |
| ![166008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166008.png) | 166008 |
| ![166009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166009.png) | 166009 |