# Crystal Rose Akshan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![166011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166011.png) | 166011 |
| ![166012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166012.png) | 166012 |
| ![166013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166013.png) | 166013 |
| ![166014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166014.png) | 166014 |
| ![166015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166015.png) | 166015 |
| ![166016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166016.png) | 166016 |
| ![166017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166017.png) | 166017 |
| ![166018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166018.png) | 166018 |
| ![166019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/166/166019.png) | 166019 |