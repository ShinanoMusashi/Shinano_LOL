# Elderwood Karthus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![30027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30027.png) | 30027 |
| ![30028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30028.png) | 30028 |
| ![30029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30029.png) | 30029 |
| ![30030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30030.png) | 30030 |
| ![30031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30031.png) | 30031 |
| ![30032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30032.png) | 30032 |
| ![30033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30033.png) | 30033 |
| ![30034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30034.png) | 30034 |