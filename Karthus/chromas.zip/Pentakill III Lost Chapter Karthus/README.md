# Pentakill III Lost Chapter Karthus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![30018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30018.png) | 30018 |
| ![30019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30019.png) | 30019 |
| ![30020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30020.png) | 30020 |
| ![30021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30021.png) | 30021 |
| ![30022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30022.png) | 30022 |
| ![30023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30023.png) | 30023 |
| ![30024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30024.png) | 30024 |
| ![30025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30025.png) | 30025 |