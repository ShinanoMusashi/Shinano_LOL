# Grim Reaper Karthus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![30006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30006.png) | 30006 |
| ![30007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30007.png) | 30007 |
| ![30008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30008.png) | 30008 |