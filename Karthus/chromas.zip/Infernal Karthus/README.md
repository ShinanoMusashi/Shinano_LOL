# Infernal Karthus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![30011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30011.png) | 30011 |
| ![30012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30012.png) | 30012 |
| ![30013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30013.png) | 30013 |
| ![30014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30014.png) | 30014 |
| ![30015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30015.png) | 30015 |
| ![30016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/30/30016.png) | 30016 |