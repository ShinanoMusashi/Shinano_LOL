# HEARTSTEEL K'Sante Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![897009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897009.png) | 897009 |
| ![897010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897010.png) | 897010 |
| ![897011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897011.png) | 897011 |
| ![897012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897012.png) | 897012 |
| ![897013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897013.png) | 897013 |
| ![897014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897014.png) | 897014 |
| ![897015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897015.png) | 897015 |
| ![897016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897016.png) | 897016 |
| ![897017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/897/897017.png) | 897017 |