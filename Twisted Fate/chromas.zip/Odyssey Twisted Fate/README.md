# Odyssey Twisted Fate Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![4014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4014.png) | 4014 |
| ![4015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4015.png) | 4015 |
| ![4016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4016.png) | 4016 |
| ![4017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4017.png) | 4017 |
| ![4018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4018.png) | 4018 |
| ![4019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4019.png) | 4019 |
| ![4020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4020.png) | 4020 |
| ![4021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4021.png) | 4021 |
| ![4022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4022.png) | 4022 |