# Crime City Nightmare Twisted Fate Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![4026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4026.png) | 4026 |
| ![4027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4027.png) | 4027 |
| ![4028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4028.png) | 4028 |
| ![4029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4029.png) | 4029 |
| ![4030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4030.png) | 4030 |
| ![4031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4031.png) | 4031 |
| ![4032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4032.png) | 4032 |
| ![4033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4033.png) | 4033 |
| ![4034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4034.png) | 4034 |