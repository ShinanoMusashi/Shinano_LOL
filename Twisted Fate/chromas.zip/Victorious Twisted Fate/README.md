# Victorious Twisted Fate Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![4046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4046.png) | 4046 |
| ![4047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4047.png) | 4047 |
| ![4048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4048.png) | 4048 |
| ![4049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4049.png) | 4049 |
| ![4050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4050.png) | 4050 |
| ![4051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4051.png) | 4051 |
| ![4052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4052.png) | 4052 |
| ![4053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4053.png) | 4053 |
| ![4054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4054.png) | 4054 |