# Pulsefire Twisted Fate Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![4012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/4/4012.png) | 4012 |