# Bewitching Poppy Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![78025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78025.png) | 78025 |
| ![78026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78026.png) | 78026 |
| ![78027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78027.png) | 78027 |
| ![78028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78028.png) | 78028 |
| ![78029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78029.png) | 78029 |
| ![78030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78030.png) | 78030 |
| ![78031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78031.png) | 78031 |
| ![78032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78032.png) | 78032 |