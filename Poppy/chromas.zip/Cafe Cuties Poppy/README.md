# Cafe Cuties Poppy Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![78034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78034.png) | 78034 |
| ![78035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78035.png) | 78035 |
| ![78036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78036.png) | 78036 |
| ![78037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78037.png) | 78037 |
| ![78038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78038.png) | 78038 |
| ![78039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78039.png) | 78039 |
| ![78040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78040.png) | 78040 |
| ![78041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78041.png) | 78041 |