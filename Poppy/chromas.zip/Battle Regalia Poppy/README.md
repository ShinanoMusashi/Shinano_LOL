# Battle Regalia Poppy Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![78008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78008.png) | 78008 |
| ![78009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78009.png) | 78009 |
| ![78010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78010.png) | 78010 |
| ![78011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78011.png) | 78011 |
| ![78012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78012.png) | 78012 |
| ![78013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/78/78013.png) | 78013 |