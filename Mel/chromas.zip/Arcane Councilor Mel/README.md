# Arcane Councilor Mel Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800002.png' alt='Chroma 800002' width='100'> | Chroma 800002 | 800002 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800003.png' alt='Chroma 800003' width='100'> | Chroma 800003 | 800003 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800004.png' alt='Chroma 800004' width='100'> | Chroma 800004 | 800004 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800005.png' alt='Chroma 800005' width='100'> | Chroma 800005 | 800005 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800006.png' alt='Chroma 800006' width='100'> | Chroma 800006 | 800006 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800007.png' alt='Chroma 800007' width='100'> | Chroma 800007 | 800007 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800008.png' alt='Chroma 800008' width='100'> | Chroma 800008 | 800008 |
| 08 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/800/800009.png' alt='Chroma 800009' width='100'> | Chroma 800009 | 800009 |
