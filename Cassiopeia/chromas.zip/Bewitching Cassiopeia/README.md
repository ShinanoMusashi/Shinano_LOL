# Bewitching Cassiopeia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![69029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69029.png) | 69029 |
| ![69030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69030.png) | 69030 |
| ![69031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69031.png) | 69031 |
| ![69032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69032.png) | 69032 |
| ![69033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69033.png) | 69033 |
| ![69034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69034.png) | 69034 |
| ![69035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69035.png) | 69035 |
| ![69036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69036.png) | 69036 |