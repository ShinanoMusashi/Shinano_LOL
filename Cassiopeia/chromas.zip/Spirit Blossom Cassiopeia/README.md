# Spirit Blossom Cassiopeia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![69010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69010.png) | 69010 |
| ![69011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69011.png) | 69011 |
| ![69012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69012.png) | 69012 |
| ![69013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69013.png) | 69013 |
| ![69014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69014.png) | 69014 |
| ![69015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69015.png) | 69015 |
| ![69016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69016.png) | 69016 |
| ![69017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69017.png) | 69017 |