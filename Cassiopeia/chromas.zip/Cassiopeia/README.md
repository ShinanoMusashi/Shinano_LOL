# Cassiopeia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![69005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69005.png) | 69005 |
| ![69006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69006.png) | 69006 |
| ![69007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/69/69007.png) | 69007 |