# Bewitching Batnivia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![34038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34038.png) | 34038 |
| ![34039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34039.png) | 34039 |
| ![34040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34040.png) | 34040 |
| ![34041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34041.png) | 34041 |
| ![34042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34042.png) | 34042 |
| ![34043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34043.png) | 34043 |
| ![34044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34044.png) | 34044 |
| ![34045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34045.png) | 34045 |