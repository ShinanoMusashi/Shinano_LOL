# Divine Phoenix Anivia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![34028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34028.png) | 34028 |
| ![34029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34029.png) | 34029 |
| ![34030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34030.png) | 34030 |
| ![34031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34031.png) | 34031 |
| ![34032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34032.png) | 34032 |
| ![34033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34033.png) | 34033 |
| ![34034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34034.png) | 34034 |
| ![34035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34035.png) | 34035 |
| ![34036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34036.png) | 34036 |