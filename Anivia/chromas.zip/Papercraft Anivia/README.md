# Papercraft Anivia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![34009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34009.png) | 34009 |
| ![34010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34010.png) | 34010 |
| ![34011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34011.png) | 34011 |
| ![34012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34012.png) | 34012 |
| ![34013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34013.png) | 34013 |
| ![34014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34014.png) | 34014 |
| ![34015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34015.png) | 34015 |
| ![34016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34016.png) | 34016 |