# Victorious Anivia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![34047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34047.png) | 34047 |
| ![34048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34048.png) | 34048 |
| ![34049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34049.png) | 34049 |
| ![34050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34050.png) | 34050 |
| ![34051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34051.png) | 34051 |
| ![34052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34052.png) | 34052 |
| ![34053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34053.png) | 34053 |
| ![34054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34054.png) | 34054 |