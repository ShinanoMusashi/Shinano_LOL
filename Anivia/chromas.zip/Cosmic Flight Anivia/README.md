# Cosmic Flight Anivia Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![34018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34018.png) | 34018 |
| ![34019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34019.png) | 34019 |
| ![34020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34020.png) | 34020 |
| ![34021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34021.png) | 34021 |
| ![34022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34022.png) | 34022 |
| ![34023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34023.png) | 34023 |
| ![34024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34024.png) | 34024 |
| ![34025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34025.png) | 34025 |
| ![34026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/34/34026.png) | 34026 |