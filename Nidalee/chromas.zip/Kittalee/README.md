# Kittalee Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![76040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76040.png) | 76040 |
| ![76041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76041.png) | 76041 |
| ![76042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76042.png) | 76042 |
| ![76043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76043.png) | 76043 |
| ![76044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76044.png) | 76044 |
| ![76045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76045.png) | 76045 |
| ![76046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76046.png) | 76046 |
| ![76047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76047.png) | 76047 |