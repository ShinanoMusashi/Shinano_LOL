# Dawnbringer Nidalee Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![76012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76012.png) | 76012 |
| ![76013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76013.png) | 76013 |
| ![76014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76014.png) | 76014 |
| ![76015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76015.png) | 76015 |
| ![76016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76016.png) | 76016 |
| ![76017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76017.png) | 76017 |