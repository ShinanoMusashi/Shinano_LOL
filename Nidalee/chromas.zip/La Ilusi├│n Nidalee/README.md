# La Ilusi��n Nidalee Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![76049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76049.png) | 76049 |
| ![76050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76050.png) | 76050 |
| ![76051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76051.png) | 76051 |
| ![76052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76052.png) | 76052 |
| ![76053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76053.png) | 76053 |
| ![76054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76054.png) | 76054 |
| ![76055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76055.png) | 76055 |
| ![76056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76056.png) | 76056 |
| ![76057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/76/76057.png) | 76057 |