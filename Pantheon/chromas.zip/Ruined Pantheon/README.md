# Ruined Pantheon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![80027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80027.png) | 80027 |
| ![80028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80028.png) | 80028 |
| ![80029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80029.png) | 80029 |
| ![80030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80030.png) | 80030 |
| ![80031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80031.png) | 80031 |
| ![80032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80032.png) | 80032 |
| ![80033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80033.png) | 80033 |
| ![80034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80034.png) | 80034 |
| ![80035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80035.png) | 80035 |