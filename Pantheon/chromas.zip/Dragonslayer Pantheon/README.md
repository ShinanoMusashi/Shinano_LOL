# Dragonslayer Pantheon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![80009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80009.png) | 80009 |
| ![80010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80010.png) | 80010 |
| ![80011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80011.png) | 80011 |
| ![80012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80012.png) | 80012 |
| ![80013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80013.png) | 80013 |
| ![80014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80014.png) | 80014 |
| ![80015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80015.png) | 80015 |