# Chosen of the Wolf Pantheon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![80039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80039.png) | 80039 |
| ![80040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80040.png) | 80040 |
| ![80041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80041.png) | 80041 |
| ![80042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80042.png) | 80042 |
| ![80043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80043.png) | 80043 |
| ![80044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80044.png) | 80044 |
| ![80045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80045.png) | 80045 |
| ![80046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80046.png) | 80046 |