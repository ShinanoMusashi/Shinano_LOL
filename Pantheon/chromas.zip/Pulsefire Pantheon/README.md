# Pulsefire Pantheon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![80017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80017.png) | 80017 |
| ![80018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80018.png) | 80018 |
| ![80019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80019.png) | 80019 |
| ![80020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80020.png) | 80020 |
| ![80021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80021.png) | 80021 |
| ![80022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80022.png) | 80022 |
| ![80023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80023.png) | 80023 |
| ![80024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/80/80024.png) | 80024 |