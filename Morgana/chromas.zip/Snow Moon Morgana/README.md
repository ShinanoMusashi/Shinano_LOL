# Snow Moon Morgana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![25061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25061.png) | 25061 |
| ![25062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25062.png) | 25062 |
| ![25063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25063.png) | 25063 |
| ![25064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25064.png) | 25064 |
| ![25065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25065.png) | 25065 |
| ![25066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25066.png) | 25066 |
| ![25067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25067.png) | 25067 |
| ![25068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25068.png) | 25068 |