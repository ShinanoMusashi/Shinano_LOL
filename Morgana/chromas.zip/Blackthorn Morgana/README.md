# Blackthorn Morgana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![25012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25012.png) | 25012 |
| ![25013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25013.png) | 25013 |
| ![25014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25014.png) | 25014 |
| ![25015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25015.png) | 25015 |
| ![25016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25016.png) | 25016 |