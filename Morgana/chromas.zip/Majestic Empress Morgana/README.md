# Majestic Empress Morgana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![25018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25018.png) | 25018 |
| ![25019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25019.png) | 25019 |
| ![25020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25020.png) | 25020 |
| ![25021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25021.png) | 25021 |
| ![25022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25022.png) | 25022 |
| ![25023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25023.png) | 25023 |
| ![25024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25024.png) | 25024 |
| ![25025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25025.png) | 25025 |