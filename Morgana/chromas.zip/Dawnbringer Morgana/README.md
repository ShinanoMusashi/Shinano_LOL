# Dawnbringer Morgana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![25042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25042.png) | 25042 |
| ![25043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25043.png) | 25043 |
| ![25044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25044.png) | 25044 |
| ![25045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25045.png) | 25045 |
| ![25046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25046.png) | 25046 |
| ![25047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25047.png) | 25047 |
| ![25048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25048.png) | 25048 |
| ![25049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/25/25049.png) | 25049 |