# Empyrean Nocturne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![56027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56027.png) | 56027 |
| ![56028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56028.png) | 56028 |
| ![56029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56029.png) | 56029 |
| ![56030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56030.png) | 56030 |
| ![56031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56031.png) | 56031 |
| ![56032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56032.png) | 56032 |
| ![56033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56033.png) | 56033 |
| ![56034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56034.png) | 56034 |
| ![56035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56035.png) | 56035 |