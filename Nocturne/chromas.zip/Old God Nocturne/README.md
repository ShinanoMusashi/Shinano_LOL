# Old God Nocturne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![56008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56008.png) | 56008 |
| ![56009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56009.png) | 56009 |
| ![56010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56010.png) | 56010 |
| ![56011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56011.png) | 56011 |
| ![56012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56012.png) | 56012 |
| ![56013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56013.png) | 56013 |
| ![56014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56014.png) | 56014 |
| ![56015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/56/56015.png) | 56015 |