# Dark Waters Vladimir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![8009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8009.png) | 8009 |
| ![8010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8010.png) | 8010 |
| ![8011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8011.png) | 8011 |
| ![8012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8012.png) | 8012 |
| ![8013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8013.png) | 8013 |