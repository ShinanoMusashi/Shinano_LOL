# Cosmic Devourer Vladimir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![8022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8022.png) | 8022 |
| ![8023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8023.png) | 8023 |
| ![8024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8024.png) | 8024 |
| ![8025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8025.png) | 8025 |
| ![8026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8026.png) | 8026 |
| ![8027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8027.png) | 8027 |
| ![8028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8028.png) | 8028 |
| ![8029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8029.png) | 8029 |