# Cafe Cuties Vladimir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![8031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8031.png) | 8031 |
| ![8032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8032.png) | 8032 |
| ![8033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8033.png) | 8033 |
| ![8034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8034.png) | 8034 |
| ![8035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8035.png) | 8035 |
| ![8036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8036.png) | 8036 |
| ![8037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8037.png) | 8037 |
| ![8038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8038.png) | 8038 |