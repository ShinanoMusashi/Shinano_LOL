# Nightbringer Vladimir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![8015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8015.png) | 8015 |
| ![8016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8016.png) | 8016 |
| ![8017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8017.png) | 8017 |
| ![8018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8018.png) | 8018 |
| ![8019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8019.png) | 8019 |
| ![8020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8020.png) | 8020 |