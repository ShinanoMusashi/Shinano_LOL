# Broken Covenant Vladimir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![8040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8040.png) | 8040 |
| ![8041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8041.png) | 8041 |
| ![8042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8042.png) | 8042 |
| ![8043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8043.png) | 8043 |
| ![8044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8044.png) | 8044 |
| ![8045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8045.png) | 8045 |
| ![8046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8046.png) | 8046 |
| ![8047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/8/8047.png) | 8047 |