# Masked Justice Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777066` | ![777066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777066.png) | 1 |
| `777067` | ![777067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777067.png) | 2 |
| `777068` | ![777068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777068.png) | 3 |
| `777069` | ![777069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777069.png) | 4 |
| `777070` | ![777070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777070.png) | 5 |
| `777071` | ![777071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777071.png) | 6 |
| `777072` | ![777072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777072.png) | 7 |
| `777073` | ![777073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777073.png) | 8 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.