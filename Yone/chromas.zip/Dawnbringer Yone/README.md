# Dawnbringer Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777020` | ![777020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777020.png) | 1 |
| `777021` | ![777021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777021.png) | 2 |
| `777022` | ![777022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777022.png) | 3 |
| `777023` | ![777023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777023.png) | 4 |
| `777024` | ![777024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777024.png) | 5 |
| `777025` | ![777025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777025.png) | 6 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.