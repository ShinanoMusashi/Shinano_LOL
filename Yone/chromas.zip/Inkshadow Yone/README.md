# Inkshadow Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777036` | ![777036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777036.png) | 1 |
| `777037` | ![777037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777037.png) | 2 |
| `777038` | ![777038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777038.png) | 3 |
| `777039` | ![777039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777039.png) | 4 |
| `777040` | ![777040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777040.png) | 5 |
| `777041` | ![777041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777041.png) | 6 |
| `777042` | ![777042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777042.png) | 7 |
| `777043` | ![777043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777043.png) | 8 |
| `777044` | ![777044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777044.png) | 9 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.