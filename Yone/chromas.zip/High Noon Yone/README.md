# High Noon Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777059` | ![777059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777059.png) | 1 |
| `777060` | ![777060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777060.png) | 2 |
| `777061` | ![777061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777061.png) | 3 |
| `777062` | ![777062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777062.png) | 4 |
| `777063` | ![777063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777063.png) | 5 |
| `777064` | ![777064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777064.png) | 6 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.