# Battle Academia Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777011` | ![777011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777011.png) | 1 |
| `777012` | ![777012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777012.png) | 2 |
| `777013` | ![777013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777013.png) | 3 |
| `777014` | ![777014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777014.png) | 4 |
| `777015` | ![777015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777015.png) | 5 |
| `777016` | ![777016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777016.png) | 6 |
| `777017` | ![777017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777017.png) | 7 |
| `777018` | ![777018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777018.png) | 8 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.