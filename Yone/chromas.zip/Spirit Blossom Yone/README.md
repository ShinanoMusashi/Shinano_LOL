# Spirit Blossom Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777002` | ![777002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777002.png) | 1 |
| `777003` | ![777003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777003.png) | 2 |
| `777004` | ![777004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777004.png) | 3 |
| `777005` | ![777005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777005.png) | 4 |
| `777006` | ![777006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777006.png) | 5 |
| `777007` | ![777007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777007.png) | 6 |
| `777008` | ![777008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777008.png) | 7 |
| `777009` | ![777009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777009.png) | 8 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.