# HEARTSTEEL Yone Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `777047` | ![777047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777047.png) | 1 |
| `777048` | ![777048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777048.png) | 2 |
| `777049` | ![777049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777049.png) | 3 |
| `777050` | ![777050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777050.png) | 4 |
| `777051` | ![777051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777051.png) | 5 |
| `777052` | ![777052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777052.png) | 6 |
| `777053` | ![777053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777053.png) | 7 |
| `777054` | ![777054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777054.png) | 8 |
| `777056` | ![777056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/777/777056.png) | 9 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.