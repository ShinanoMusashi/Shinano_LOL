# Heimerstinger Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![74025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74025.png) | 74025 |
| ![74026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74026.png) | 74026 |
| ![74027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74027.png) | 74027 |
| ![74028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74028.png) | 74028 |
| ![74029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74029.png) | 74029 |
| ![74030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74030.png) | 74030 |
| ![74031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74031.png) | 74031 |
| ![74032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74032.png) | 74032 |