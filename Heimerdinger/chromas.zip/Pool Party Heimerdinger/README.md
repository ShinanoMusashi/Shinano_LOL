# Pool Party Heimerdinger Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![74016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74016.png) | 74016 |
| ![74017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74017.png) | 74017 |
| ![74018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74018.png) | 74018 |
| ![74019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74019.png) | 74019 |
| ![74020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74020.png) | 74020 |
| ![74021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74021.png) | 74021 |
| ![74022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74022.png) | 74022 |
| ![74023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74023.png) | 74023 |