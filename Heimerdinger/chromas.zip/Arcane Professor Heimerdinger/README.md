# Arcane Professor Heimerdinger Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![74034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/74/74034.png) | 74034 |