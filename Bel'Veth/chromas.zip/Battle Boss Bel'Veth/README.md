# Battle Boss Bel'Veth Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![200002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200002.png) | 200002 |
| ![200003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200003.png) | 200003 |
| ![200004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200004.png) | 200004 |
| ![200005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200005.png) | 200005 |
| ![200006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200006.png) | 200006 |
| ![200007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200007.png) | 200007 |
| ![200008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200008.png) | 200008 |
| ![200009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200009.png) | 200009 |