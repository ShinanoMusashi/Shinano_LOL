# Primordian Bel'Veth Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![200020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200020.png) | 200020 |
| ![200021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200021.png) | 200021 |
| ![200022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200022.png) | 200022 |
| ![200023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200023.png) | 200023 |
| ![200024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200024.png) | 200024 |
| ![200025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200025.png) | 200025 |
| ![200026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200026.png) | 200026 |
| ![200027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200027.png) | 200027 |
| ![200028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/200/200028.png) | 200028 |