# Astronaut Xerath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![101022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101022.png) | 101022 |
| ![101023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101023.png) | 101023 |
| ![101024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101024.png) | 101024 |
| ![101025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101025.png) | 101025 |
| ![101026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101026.png) | 101026 |
| ![101027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101027.png) | 101027 |
| ![101028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101028.png) | 101028 |
| ![101029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101029.png) | 101029 |