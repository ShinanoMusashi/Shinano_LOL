# Crystalis Indomitus Xerath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![101031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101031.png) | 101031 |