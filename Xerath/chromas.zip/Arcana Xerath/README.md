# Arcana Xerath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![101013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101013.png) | 101013 |
| ![101014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101014.png) | 101014 |
| ![101015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101015.png) | 101015 |
| ![101016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101016.png) | 101016 |
| ![101017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101017.png) | 101017 |
| ![101018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101018.png) | 101018 |
| ![101019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101019.png) | 101019 |
| ![101020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101020.png) | 101020 |