# Dark Star Xerath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![101006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101006.png) | 101006 |
| ![101007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101007.png) | 101007 |
| ![101008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101008.png) | 101008 |
| ![101009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101009.png) | 101009 |
| ![101010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101010.png) | 101010 |
| ![101011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/101/101011.png) | 101011 |