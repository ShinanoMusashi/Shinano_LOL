# Cafe Cuties Sivir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![15035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15035.png) | 15035 |
| ![15036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15036.png) | 15036 |
| ![15037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15037.png) | 15037 |
| ![15038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15038.png) | 15038 |
| ![15039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15039.png) | 15039 |
| ![15040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15040.png) | 15040 |
| ![15041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15041.png) | 15041 |
| ![15042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15042.png) | 15042 |