# Primal Ambush Sivir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![15062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15062.png) | 15062 |
| ![15063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15063.png) | 15063 |
| ![15064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15064.png) | 15064 |
| ![15065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15065.png) | 15065 |
| ![15066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15066.png) | 15066 |
| ![15067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15067.png) | 15067 |
| ![15068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15068.png) | 15068 |
| ![15069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15069.png) | 15069 |