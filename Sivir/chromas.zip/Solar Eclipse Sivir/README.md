# Solar Eclipse Sivir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![15044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15044.png) | 15044 |
| ![15045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15045.png) | 15045 |
| ![15046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15046.png) | 15046 |
| ![15047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15047.png) | 15047 |
| ![15048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15048.png) | 15048 |
| ![15049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/15/15049.png) | 15049 |