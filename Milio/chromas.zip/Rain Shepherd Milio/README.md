# Rain Shepherd Milio Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![902012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902012.png) | 902012 |
| ![902013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902013.png) | 902013 |
| ![902014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902014.png) | 902014 |
| ![902015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902015.png) | 902015 |
| ![902016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902016.png) | 902016 |
| ![902017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902017.png) | 902017 |
| ![902018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902018.png) | 902018 |
| ![902019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/902/902019.png) | 902019 |