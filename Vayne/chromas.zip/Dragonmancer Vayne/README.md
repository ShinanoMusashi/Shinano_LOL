# Dragonmancer Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67056.png) | 67056 |
| ![67057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67057.png) | 67057 |
| ![67058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67058.png) | 67058 |
| ![67059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67059.png) | 67059 |
| ![67060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67060.png) | 67060 |
| ![67061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67061.png) | 67061 |
| ![67062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67062.png) | 67062 |
| ![67063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67063.png) | 67063 |