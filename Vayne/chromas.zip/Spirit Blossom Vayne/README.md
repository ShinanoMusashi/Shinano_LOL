# Spirit Blossom Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67017.png) | 67017 |
| ![67018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67018.png) | 67018 |
| ![67019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67019.png) | 67019 |
| ![67020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67020.png) | 67020 |
| ![67021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67021.png) | 67021 |
| ![67022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67022.png) | 67022 |
| ![67023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67023.png) | 67023 |
| ![67024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67024.png) | 67024 |