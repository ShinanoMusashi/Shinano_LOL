# Firecracker Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67034.png) | 67034 |