# Sentinel Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67026.png) | 67026 |
| ![67027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67027.png) | 67027 |
| ![67028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67028.png) | 67028 |
| ![67029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67029.png) | 67029 |
| ![67030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67030.png) | 67030 |
| ![67031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67031.png) | 67031 |