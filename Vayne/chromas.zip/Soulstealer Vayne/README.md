# Soulstealer Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67053.png) | 67053 |
| ![67054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67054.png) | 67054 |