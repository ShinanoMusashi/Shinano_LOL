# Battle Bat Vayne Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![67035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67035.png) | 67035 |
| ![67036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67036.png) | 67036 |
| ![67037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67037.png) | 67037 |
| ![67038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67038.png) | 67038 |
| ![67039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67039.png) | 67039 |
| ![67040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67040.png) | 67040 |
| ![67041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67041.png) | 67041 |
| ![67042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67042.png) | 67042 |
| ![67043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/67/67043.png) | 67043 |