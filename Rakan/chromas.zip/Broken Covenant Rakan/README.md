# Broken Covenant Rakan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![497028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497028.png) | 497028 |
| ![497029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497029.png) | 497029 |
| ![497030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497030.png) | 497030 |
| ![497031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497031.png) | 497031 |
| ![497032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497032.png) | 497032 |
| ![497033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497033.png) | 497033 |
| ![497034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497034.png) | 497034 |
| ![497035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497035.png) | 497035 |