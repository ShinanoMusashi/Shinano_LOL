# Star Guardian Rakan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![497006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497006.png) | 497006 |
| ![497007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497007.png) | 497007 |
| ![497008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497008.png) | 497008 |