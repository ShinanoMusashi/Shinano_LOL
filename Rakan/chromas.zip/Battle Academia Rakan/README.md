# Battle Academia Rakan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![497048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497048.png) | 497048 |
| ![497049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497049.png) | 497049 |
| ![497050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497050.png) | 497050 |
| ![497051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497051.png) | 497051 |
| ![497052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497052.png) | 497052 |
| ![497053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497053.png) | 497053 |
| ![497054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497054.png) | 497054 |
| ![497055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497055.png) | 497055 |