# Arcana Rakan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![497019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497019.png) | 497019 |
| ![497020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497020.png) | 497020 |
| ![497021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497021.png) | 497021 |
| ![497022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497022.png) | 497022 |
| ![497023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497023.png) | 497023 |
| ![497024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497024.png) | 497024 |
| ![497025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497025.png) | 497025 |
| ![497026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497026.png) | 497026 |