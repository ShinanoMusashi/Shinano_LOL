# Dragonmancer Rakan Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![497039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497039.png) | 497039 |
| ![497040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497040.png) | 497040 |
| ![497041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497041.png) | 497041 |
| ![497042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497042.png) | 497042 |
| ![497043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497043.png) | 497043 |
| ![497044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497044.png) | 497044 |
| ![497045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497045.png) | 497045 |
| ![497046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/497/497046.png) | 497046 |