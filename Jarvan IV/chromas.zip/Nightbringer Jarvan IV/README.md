# Nightbringer Jarvan IV Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![59036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59036.png) | 59036 |
| ![59037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59037.png) | 59037 |
| ![59038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59038.png) | 59038 |
| ![59039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59039.png) | 59039 |
| ![59040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59040.png) | 59040 |
| ![59041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59041.png) | 59041 |
| ![59042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59042.png) | 59042 |
| ![59043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59043.png) | 59043 |