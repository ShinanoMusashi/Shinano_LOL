# Mythmaker Jarvan IV Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![59045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59045.png) | 59045 |
| ![59046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59046.png) | 59046 |
| ![59047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59047.png) | 59047 |
| ![59048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59048.png) | 59048 |
| ![59049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59049.png) | 59049 |
| ![59050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59050.png) | 59050 |
| ![59051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59051.png) | 59051 |
| ![59052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59052.png) | 59052 |