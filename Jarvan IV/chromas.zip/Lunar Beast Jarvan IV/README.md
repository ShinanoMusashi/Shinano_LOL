# Lunar Beast Jarvan IV Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![59022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59022.png) | 59022 |
| ![59023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59023.png) | 59023 |
| ![59024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59024.png) | 59024 |
| ![59025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59025.png) | 59025 |
| ![59026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59026.png) | 59026 |
| ![59027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59027.png) | 59027 |
| ![59028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/59/59028.png) | 59028 |