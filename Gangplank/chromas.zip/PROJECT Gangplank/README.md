# PROJECT Gangplank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![41034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41034.png) | 41034 |
| ![41035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41035.png) | 41035 |
| ![41036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41036.png) | 41036 |
| ![41037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41037.png) | 41037 |
| ![41038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41038.png) | 41038 |
| ![41039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41039.png) | 41039 |
| ![41040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41040.png) | 41040 |
| ![41041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41041.png) | 41041 |