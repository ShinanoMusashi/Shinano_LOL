# Pool Party Gangplank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![41015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41015.png) | 41015 |
| ![41016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41016.png) | 41016 |
| ![41017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41017.png) | 41017 |
| ![41018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41018.png) | 41018 |
| ![41019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41019.png) | 41019 |
| ![41020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41020.png) | 41020 |