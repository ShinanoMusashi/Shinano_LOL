# Dreadnova Gangplank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![41009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41009.png) | 41009 |
| ![41010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41010.png) | 41010 |
| ![41011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41011.png) | 41011 |
| ![41012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41012.png) | 41012 |
| ![41013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41013.png) | 41013 |
| ![41032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41032.png) | 41032 |