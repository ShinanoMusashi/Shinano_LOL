# Gangplank the Betrayer Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![41024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41024.png) | 41024 |
| ![41025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41025.png) | 41025 |
| ![41026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41026.png) | 41026 |
| ![41027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41027.png) | 41027 |
| ![41028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41028.png) | 41028 |
| ![41029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41029.png) | 41029 |
| ![41030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41030.png) | 41030 |
| ![41031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/41/41031.png) | 41031 |