# Arcanist Kog'Maw Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![96020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96020.png) | 96020 |
| ![96021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96021.png) | 96021 |
| ![96022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96022.png) | 96022 |
| ![96023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96023.png) | 96023 |
| ![96024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96024.png) | 96024 |
| ![96025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96025.png) | 96025 |
| ![96026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96026.png) | 96026 |
| ![96027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96027.png) | 96027 |