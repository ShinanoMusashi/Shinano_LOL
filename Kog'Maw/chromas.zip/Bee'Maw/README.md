# Bee'Maw Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![96029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96029.png) | 96029 |
| ![96030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96030.png) | 96030 |
| ![96031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96031.png) | 96031 |
| ![96032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96032.png) | 96032 |
| ![96033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96033.png) | 96033 |
| ![96034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96034.png) | 96034 |
| ![96035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96035.png) | 96035 |
| ![96036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96036.png) | 96036 |