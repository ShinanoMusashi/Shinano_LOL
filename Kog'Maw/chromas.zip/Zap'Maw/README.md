# Zap'Maw Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![96038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96038.png) | 96038 |
| ![96039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96039.png) | 96039 |
| ![96040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96040.png) | 96040 |
| ![96041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96041.png) | 96041 |
| ![96042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96042.png) | 96042 |
| ![96043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96043.png) | 96043 |
| ![96044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96044.png) | 96044 |
| ![96045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96045.png) | 96045 |