# Shan Hai Scrolls Kog'Maw Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![96047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96047.png) | 96047 |
| ![96048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96048.png) | 96048 |
| ![96049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96049.png) | 96049 |
| ![96050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96050.png) | 96050 |
| ![96051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96051.png) | 96051 |
| ![96052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96052.png) | 96052 |
| ![96053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96053.png) | 96053 |
| ![96054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/96/96054.png) | 96054 |