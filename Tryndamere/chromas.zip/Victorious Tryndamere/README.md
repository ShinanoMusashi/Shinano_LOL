# Victorious Tryndamere Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![23028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23028.png) | 23028 |
| ![23029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23029.png) | 23029 |
| ![23030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23030.png) | 23030 |
| ![23031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23031.png) | 23031 |
| ![23032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23032.png) | 23032 |
| ![23033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23033.png) | 23033 |
| ![23034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23034.png) | 23034 |
| ![23035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23035.png) | 23035 |
| ![23036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23036.png) | 23036 |