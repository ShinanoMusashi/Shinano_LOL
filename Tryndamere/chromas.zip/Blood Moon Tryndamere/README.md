# Blood Moon Tryndamere Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![23011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23011.png) | 23011 |
| ![23012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23012.png) | 23012 |
| ![23013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23013.png) | 23013 |
| ![23014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23014.png) | 23014 |
| ![23015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23015.png) | 23015 |
| ![23016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23016.png) | 23016 |
| ![23017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23017.png) | 23017 |