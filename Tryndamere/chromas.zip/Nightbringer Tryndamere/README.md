# Nightbringer Tryndamere Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![23019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23019.png) | 23019 |
| ![23020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23020.png) | 23020 |
| ![23021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23021.png) | 23021 |
| ![23022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23022.png) | 23022 |
| ![23023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23023.png) | 23023 |
| ![23024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23024.png) | 23024 |
| ![23025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23025.png) | 23025 |
| ![23026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/23/23026.png) | 23026 |