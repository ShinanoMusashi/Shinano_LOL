# Zesty Dip Zac Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![154025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154025.png) | 154025 |
| ![154026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154026.png) | 154026 |
| ![154027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154027.png) | 154027 |
| ![154028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154028.png) | 154028 |
| ![154029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154029.png) | 154029 |
| ![154030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154030.png) | 154030 |
| ![154031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154031.png) | 154031 |
| ![154032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154032.png) | 154032 |