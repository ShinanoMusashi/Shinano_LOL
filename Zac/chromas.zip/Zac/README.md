# Zac Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![154003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154003.png) | 154003 |
| ![154004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154004.png) | 154004 |
| ![154005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154005.png) | 154005 |