# Empyrean Zac Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![154015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154015.png) | 154015 |
| ![154016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154016.png) | 154016 |
| ![154017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154017.png) | 154017 |
| ![154018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154018.png) | 154018 |
| ![154019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154019.png) | 154019 |
| ![154020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154020.png) | 154020 |
| ![154021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154021.png) | 154021 |
| ![154022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154022.png) | 154022 |
| ![154023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/154/154023.png) | 154023 |