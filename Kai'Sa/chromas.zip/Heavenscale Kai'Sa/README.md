# Heavenscale Kai'Sa Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![145060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145060.png) | 145060 |
| ![145061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145061.png) | 145061 |
| ![145062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145062.png) | 145062 |
| ![145063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145063.png) | 145063 |
| ![145064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145064.png) | 145064 |
| ![145065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145065.png) | 145065 |
| ![145066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145066.png) | 145066 |
| ![145067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145067.png) | 145067 |
| ![145068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145068.png) | 145068 |