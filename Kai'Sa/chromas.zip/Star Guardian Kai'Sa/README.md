# Star Guardian Kai'Sa Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![145041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145041.png) | 145041 |
| ![145042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145042.png) | 145042 |
| ![145043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145043.png) | 145043 |
| ![145044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145044.png) | 145044 |
| ![145045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145045.png) | 145045 |
| ![145046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145046.png) | 145046 |