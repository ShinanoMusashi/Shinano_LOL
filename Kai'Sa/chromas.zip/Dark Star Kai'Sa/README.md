# Dark Star Kai'Sa Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![145072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145072.png) | 145072 |
| ![145073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145073.png) | 145073 |
| ![145074](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145074.png) | 145074 |
| ![145075](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145075.png) | 145075 |
| ![145076](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145076.png) | 145076 |
| ![145077](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145077.png) | 145077 |
| ![145078](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145078.png) | 145078 |
| ![145079](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145079.png) | 145079 |
| ![145080](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145080.png) | 145080 |