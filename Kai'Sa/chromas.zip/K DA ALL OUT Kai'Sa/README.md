# K DA ALL OUT Kai'Sa Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![145028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145028.png) | 145028 |