# iG Kai'Sa Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![145058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/145/145058.png) | 145058 |