# Ashen Knight Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555046.png) | 555046 |