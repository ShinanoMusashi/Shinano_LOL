# Sentinel Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555035.png) | 555035 |
| ![555036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555036.png) | 555036 |
| ![555037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555037.png) | 555037 |
| ![555038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555038.png) | 555038 |
| ![555039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555039.png) | 555039 |
| ![555040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555040.png) | 555040 |
| ![555041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555041.png) | 555041 |
| ![555042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555042.png) | 555042 |
| ![555043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555043.png) | 555043 |