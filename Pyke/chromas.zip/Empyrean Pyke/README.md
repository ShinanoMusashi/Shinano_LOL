# Empyrean Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555047.png) | 555047 |
| ![555048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555048.png) | 555048 |
| ![555049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555049.png) | 555049 |
| ![555050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555050.png) | 555050 |
| ![555051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555051.png) | 555051 |
| ![555052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555052.png) | 555052 |