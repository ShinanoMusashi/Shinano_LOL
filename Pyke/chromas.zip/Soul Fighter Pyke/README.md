# Soul Fighter Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555055.png) | 555055 |
| ![555056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555056.png) | 555056 |
| ![555057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555057.png) | 555057 |
| ![555058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555058.png) | 555058 |
| ![555059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555059.png) | 555059 |
| ![555060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555060.png) | 555060 |
| ![555061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555061.png) | 555061 |
| ![555062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555062.png) | 555062 |
| ![555063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555063.png) | 555063 |