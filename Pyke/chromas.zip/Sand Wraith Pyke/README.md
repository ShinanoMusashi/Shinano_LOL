# Sand Wraith Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555002.png) | 555002 |
| ![555003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555003.png) | 555003 |
| ![555004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555004.png) | 555004 |
| ![555005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555005.png) | 555005 |
| ![555006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555006.png) | 555006 |
| ![555007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555007.png) | 555007 |
| ![555008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555008.png) | 555008 |