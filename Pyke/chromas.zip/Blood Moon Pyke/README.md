# Blood Moon Pyke Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![555010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555010.png) | 555010 |
| ![555011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555011.png) | 555011 |
| ![555012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555012.png) | 555012 |
| ![555013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555013.png) | 555013 |
| ![555014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555014.png) | 555014 |
| ![555015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/555/555015.png) | 555015 |