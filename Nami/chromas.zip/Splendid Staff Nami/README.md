# Splendid Staff Nami Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![267016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267016.png) | 267016 |
| ![267017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267017.png) | 267017 |
| ![267018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267018.png) | 267018 |
| ![267019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267019.png) | 267019 |
| ![267020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267020.png) | 267020 |
| ![267021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267021.png) | 267021 |
| ![267022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267022.png) | 267022 |
| ![267023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267023.png) | 267023 |