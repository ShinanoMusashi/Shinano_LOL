# Bewitching Nami Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![267033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267033.png) | 267033 |
| ![267034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267034.png) | 267034 |
| ![267035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267035.png) | 267035 |
| ![267036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267036.png) | 267036 |
| ![267037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267037.png) | 267037 |
| ![267038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267038.png) | 267038 |
| ![267039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267039.png) | 267039 |
| ![267040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267040.png) | 267040 |