# Koi Nami Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![267004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267004.png) | 267004 |
| ![267005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267005.png) | 267005 |
| ![267006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267006.png) | 267006 |