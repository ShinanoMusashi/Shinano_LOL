# Coven Nami Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![267052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267052.png) | 267052 |
| ![267053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267053.png) | 267053 |
| ![267054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267054.png) | 267054 |
| ![267055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267055.png) | 267055 |
| ![267056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267056.png) | 267056 |
| ![267057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/267/267057.png) | 267057 |