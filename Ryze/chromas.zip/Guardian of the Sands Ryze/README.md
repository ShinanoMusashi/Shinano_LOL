# Guardian of the Sands Ryze Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![13014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13014.png) | 13014 |
| ![13015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13015.png) | 13015 |
| ![13016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13016.png) | 13016 |
| ![13017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13017.png) | 13017 |
| ![13018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13018.png) | 13018 |
| ![13019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13019.png) | 13019 |