# Arcana Ryze Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![13021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13021.png) | 13021 |
| ![13022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13022.png) | 13022 |
| ![13023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13023.png) | 13023 |
| ![13024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13024.png) | 13024 |
| ![13025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13025.png) | 13025 |
| ![13026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13026.png) | 13026 |
| ![13027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13027.png) | 13027 |
| ![13028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13028.png) | 13028 |