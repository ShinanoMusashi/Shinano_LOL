# SKT T1 Ryze Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![13030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13030.png) | 13030 |