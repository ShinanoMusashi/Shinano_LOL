# Blood Moon Ryze Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![13031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13031.png) | 13031 |
| ![13032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13032.png) | 13032 |
| ![13033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13033.png) | 13033 |
| ![13034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13034.png) | 13034 |
| ![13035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13035.png) | 13035 |
| ![13036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13036.png) | 13036 |
| ![13037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13037.png) | 13037 |
| ![13038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/13/13038.png) | 13038 |