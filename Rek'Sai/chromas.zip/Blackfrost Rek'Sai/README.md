# Blackfrost Rek'Sai Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![421010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421010.png) | 421010 |
| ![421011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421011.png) | 421011 |
| ![421012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421012.png) | 421012 |
| ![421013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421013.png) | 421013 |
| ![421014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421014.png) | 421014 |
| ![421015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421015.png) | 421015 |
| ![421016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421016.png) | 421016 |