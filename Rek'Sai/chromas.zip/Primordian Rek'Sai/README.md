# Primordian Rek'Sai Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![421027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421027.png) | 421027 |
| ![421028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421028.png) | 421028 |
| ![421029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421029.png) | 421029 |
| ![421030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421030.png) | 421030 |
| ![421031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421031.png) | 421031 |
| ![421032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421032.png) | 421032 |
| ![421033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421033.png) | 421033 |
| ![421034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421034.png) | 421034 |
| ![421035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421035.png) | 421035 |