# Pool Party Rek'Sai Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![421003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421003.png) | 421003 |
| ![421004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421004.png) | 421004 |
| ![421005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421005.png) | 421005 |
| ![421006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421006.png) | 421006 |
| ![421007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421007.png) | 421007 |
| ![421008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421008.png) | 421008 |