# Elderwood Rek'Sai Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![421018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421018.png) | 421018 |
| ![421019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421019.png) | 421019 |
| ![421020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421020.png) | 421020 |
| ![421021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421021.png) | 421021 |
| ![421022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421022.png) | 421022 |
| ![421023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421023.png) | 421023 |
| ![421024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421024.png) | 421024 |
| ![421025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/421/421025.png) | 421025 |