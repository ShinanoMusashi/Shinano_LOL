# Ruined Draven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![119021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119021.png) | 119021 |
| ![119022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119022.png) | 119022 |
| ![119023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119023.png) | 119023 |
| ![119024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119024.png) | 119024 |
| ![119025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119025.png) | 119025 |
| ![119026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119026.png) | 119026 |
| ![119027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119027.png) | 119027 |
| ![119028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119028.png) | 119028 |