# Grand Reckoning Draven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![119059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119059.png) | 119059 |
| ![119060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119060.png) | 119060 |
| ![119061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119061.png) | 119061 |
| ![119062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119062.png) | 119062 |
| ![119063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119063.png) | 119063 |
| ![119064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119064.png) | 119064 |
| ![119065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119065.png) | 119065 |
| ![119066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119066.png) | 119066 |
| ![119067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119067.png) | 119067 |