# Fright Night Draven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![119040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119040.png) | 119040 |
| ![119041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119041.png) | 119041 |
| ![119042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119042.png) | 119042 |
| ![119043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119043.png) | 119043 |
| ![119044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119044.png) | 119044 |
| ![119045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119045.png) | 119045 |
| ![119046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119046.png) | 119046 |
| ![119047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119047.png) | 119047 |