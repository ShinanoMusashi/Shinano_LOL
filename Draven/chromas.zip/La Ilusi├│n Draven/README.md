# La Ilusi��n Draven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![119049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119049.png) | 119049 |
| ![119050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119050.png) | 119050 |
| ![119051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119051.png) | 119051 |
| ![119052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119052.png) | 119052 |
| ![119053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119053.png) | 119053 |
| ![119054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119054.png) | 119054 |
| ![119055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119055.png) | 119055 |
| ![119056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119056.png) | 119056 |
| ![119057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/119/119057.png) | 119057 |