# Cosmic Queen Ashe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![22012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22012.png) | 22012 |
| ![22013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22013.png) | 22013 |
| ![22014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22014.png) | 22014 |
| ![22015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22015.png) | 22015 |
| ![22016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22016.png) | 22016 |