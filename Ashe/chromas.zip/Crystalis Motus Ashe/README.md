# Crystalis Motus Ashe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![22066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22066.png) | 22066 |