# Fae Dragon Ashe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![22024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22024.png) | 22024 |
| ![22025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22025.png) | 22025 |
| ![22026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22026.png) | 22026 |
| ![22027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22027.png) | 22027 |
| ![22028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22028.png) | 22028 |
| ![22029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22029.png) | 22029 |
| ![22030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22030.png) | 22030 |
| ![22031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22031.png) | 22031 |
| ![22042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22042.png) | 22042 |