# Worlds 2017 Ashe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![22010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22010.png) | 22010 |