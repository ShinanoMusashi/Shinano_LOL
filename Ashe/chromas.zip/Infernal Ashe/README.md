# Infernal Ashe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![22068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22068.png) | 22068 |
| ![22069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22069.png) | 22069 |
| ![22070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22070.png) | 22070 |
| ![22071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22071.png) | 22071 |
| ![22072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22072.png) | 22072 |
| ![22073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22073.png) | 22073 |
| ![22074](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22074.png) | 22074 |
| ![22075](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/22/22075.png) | 22075 |