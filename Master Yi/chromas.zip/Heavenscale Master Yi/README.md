# Heavenscale Master Yi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![11097](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11097.png) | 11097 |
| ![11098](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11098.png) | 11098 |
| ![11099](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11099.png) | 11099 |
| ![11100](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11100.png) | 11100 |
| ![11101](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11101.png) | 11101 |
| ![11102](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11102.png) | 11102 |
| ![11103](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11103.png) | 11103 |
| ![11104](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11104.png) | 11104 |
| ![11105](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11105.png) | 11105 |