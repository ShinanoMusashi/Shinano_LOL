# Headhunter Master Yi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![11006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11006.png) | 11006 |
| ![11007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11007.png) | 11007 |
| ![11008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11008.png) | 11008 |