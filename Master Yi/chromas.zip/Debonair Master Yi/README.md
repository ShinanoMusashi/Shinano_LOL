# Debonair Master Yi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![11043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11043.png) | 11043 |
| ![11044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11044.png) | 11044 |
| ![11045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11045.png) | 11045 |
| ![11046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11046.png) | 11046 |
| ![11047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11047.png) | 11047 |
| ![11048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11048.png) | 11048 |
| ![11049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11049.png) | 11049 |
| ![11050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11050.png) | 11050 |
| ![11051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/11/11051.png) | 11051 |