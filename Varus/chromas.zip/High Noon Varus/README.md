# High Noon Varus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![110035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110035.png) | 110035 |
| ![110036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110036.png) | 110036 |
| ![110037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110037.png) | 110037 |
| ![110038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110038.png) | 110038 |
| ![110039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110039.png) | 110039 |
| ![110040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110040.png) | 110040 |
| ![110041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110041.png) | 110041 |
| ![110042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110042.png) | 110042 |
| ![110043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110043.png) | 110043 |