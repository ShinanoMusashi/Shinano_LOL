# Empyrean Varus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![110054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110054.png) | 110054 |
| ![110055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110055.png) | 110055 |
| ![110056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110056.png) | 110056 |
| ![110057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110057.png) | 110057 |
| ![110058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110058.png) | 110058 |
| ![110059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110059.png) | 110059 |