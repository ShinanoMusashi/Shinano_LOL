# Dark Star Varus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![110015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110015.png) | 110015 |