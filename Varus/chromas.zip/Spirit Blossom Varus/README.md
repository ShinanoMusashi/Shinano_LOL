# Spirit Blossom Varus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![110061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110061.png) | 110061 |
| ![110062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110062.png) | 110062 |
| ![110063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110063.png) | 110063 |
| ![110064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110064.png) | 110064 |
| ![110065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110065.png) | 110065 |
| ![110066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110066.png) | 110066 |
| ![110067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110067.png) | 110067 |
| ![110068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110068.png) | 110068 |