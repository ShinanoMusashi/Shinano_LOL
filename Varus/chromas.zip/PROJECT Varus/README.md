# PROJECT Varus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![110025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110025.png) | 110025 |
| ![110026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110026.png) | 110026 |
| ![110027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110027.png) | 110027 |
| ![110028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110028.png) | 110028 |
| ![110029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110029.png) | 110029 |
| ![110030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110030.png) | 110030 |
| ![110031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110031.png) | 110031 |
| ![110032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110032.png) | 110032 |
| ![110033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/110/110033.png) | 110033 |