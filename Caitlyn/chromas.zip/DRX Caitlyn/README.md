# DRX Caitlyn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![51049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51049.png) | 51049 |