# Caitlyn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![51007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51007.png) | 51007 |
| ![51008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51008.png) | 51008 |
| ![51009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51009.png) | 51009 |