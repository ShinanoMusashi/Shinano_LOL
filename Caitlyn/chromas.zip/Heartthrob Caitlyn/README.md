# Heartthrob Caitlyn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![51040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51040.png) | 51040 |
| ![51041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51041.png) | 51041 |
| ![51042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51042.png) | 51042 |
| ![51043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51043.png) | 51043 |
| ![51044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51044.png) | 51044 |
| ![51045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51045.png) | 51045 |
| ![51046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51046.png) | 51046 |
| ![51047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51047.png) | 51047 |