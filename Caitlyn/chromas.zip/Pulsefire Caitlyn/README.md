# Pulsefire Caitlyn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![51021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51021.png) | 51021 |