# Lunar Wraith Caitlyn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![51012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/51/51012.png) | 51012 |