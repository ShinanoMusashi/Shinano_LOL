# Dragonslayer Olaf Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![2017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2017.png) | 2017 |
| ![2018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2018.png) | 2018 |
| ![2019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2019.png) | 2019 |
| ![2020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2020.png) | 2020 |
| ![2021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2021.png) | 2021 |
| ![2022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2022.png) | 2022 |
| ![2023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2023.png) | 2023 |
| ![2024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2024.png) | 2024 |