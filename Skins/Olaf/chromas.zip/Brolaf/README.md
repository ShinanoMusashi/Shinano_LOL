# Brolaf Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![2007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2007.png) | 2007 |
| ![2008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2008.png) | 2008 |
| ![2009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2009.png) | 2009 |
| ![2010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2010.png) | 2010 |
| ![2011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2011.png) | 2011 |
| ![2012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2012.png) | 2012 |
| ![2013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2013.png) | 2013 |
| ![2014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/2/2014.png) | 2014 |