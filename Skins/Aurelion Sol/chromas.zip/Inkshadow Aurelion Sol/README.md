# Inkshadow Aurelion Sol Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![136022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136022.png) | 136022 |
| ![136023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136023.png) | 136023 |
| ![136024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136024.png) | 136024 |
| ![136025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136025.png) | 136025 |
| ![136026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136026.png) | 136026 |
| ![136027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136027.png) | 136027 |
| ![136028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136028.png) | 136028 |
| ![136029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136029.png) | 136029 |
| ![136030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136030.png) | 136030 |