# Mecha Aurelion Sol Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![136004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136004.png) | 136004 |
| ![136005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136005.png) | 136005 |
| ![136006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136006.png) | 136006 |
| ![136007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136007.png) | 136007 |
| ![136008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136008.png) | 136008 |
| ![136009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136009.png) | 136009 |
| ![136010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136010.png) | 136010 |