# Porcelain Protector Aurelion Sol Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![136032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136032.png) | 136032 |
| ![136033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136033.png) | 136033 |
| ![136034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136034.png) | 136034 |
| ![136035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136035.png) | 136035 |
| ![136036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136036.png) | 136036 |
| ![136037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136037.png) | 136037 |