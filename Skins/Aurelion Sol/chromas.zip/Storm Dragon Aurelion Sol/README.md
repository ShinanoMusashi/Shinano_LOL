# Storm Dragon Aurelion Sol Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![136012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136012.png) | 136012 |
| ![136013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136013.png) | 136013 |
| ![136014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136014.png) | 136014 |
| ![136015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136015.png) | 136015 |
| ![136016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136016.png) | 136016 |
| ![136017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136017.png) | 136017 |
| ![136018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136018.png) | 136018 |
| ![136019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136019.png) | 136019 |
| ![136020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/136/136020.png) | 136020 |