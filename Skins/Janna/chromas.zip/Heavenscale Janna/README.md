# Heavenscale Janna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![40057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40057.png) | 40057 |
| ![40058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40058.png) | 40058 |
| ![40059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40059.png) | 40059 |
| ![40060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40060.png) | 40060 |
| ![40061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40061.png) | 40061 |
| ![40062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40062.png) | 40062 |
| ![40063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40063.png) | 40063 |
| ![40064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40064.png) | 40064 |
| ![40065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40065.png) | 40065 |