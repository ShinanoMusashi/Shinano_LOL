# Cyber Halo Janna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![40047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40047.png) | 40047 |
| ![40048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40048.png) | 40048 |
| ![40049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40049.png) | 40049 |
| ![40050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40050.png) | 40050 |
| ![40051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40051.png) | 40051 |
| ![40052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40052.png) | 40052 |
| ![40053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40053.png) | 40053 |
| ![40054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40054.png) | 40054 |
| ![40055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40055.png) | 40055 |