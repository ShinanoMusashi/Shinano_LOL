# Guardian of the Sands Janna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![40021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40021.png) | 40021 |
| ![40022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40022.png) | 40022 |
| ![40023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40023.png) | 40023 |
| ![40024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40024.png) | 40024 |
| ![40025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40025.png) | 40025 |
| ![40026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40026.png) | 40026 |