# Sacred Sword Janna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![40009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40009.png) | 40009 |
| ![40010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40010.png) | 40010 |
| ![40011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40011.png) | 40011 |
| ![40012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40012.png) | 40012 |