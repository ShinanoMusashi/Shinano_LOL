# Battle Queen Janna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![40028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40028.png) | 40028 |
| ![40029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40029.png) | 40029 |
| ![40030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40030.png) | 40030 |
| ![40031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40031.png) | 40031 |
| ![40032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40032.png) | 40032 |
| ![40033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40033.png) | 40033 |
| ![40034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40034.png) | 40034 |
| ![40035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/40/40035.png) | 40035 |