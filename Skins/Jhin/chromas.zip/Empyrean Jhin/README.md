# Empyrean Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202027.png) | 202027 |
| ![202028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202028.png) | 202028 |
| ![202029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202029.png) | 202029 |
| ![202030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202030.png) | 202030 |
| ![202031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202031.png) | 202031 |
| ![202032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202032.png) | 202032 |
| ![202033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202033.png) | 202033 |
| ![202034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202034.png) | 202034 |
| ![202035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202035.png) | 202035 |