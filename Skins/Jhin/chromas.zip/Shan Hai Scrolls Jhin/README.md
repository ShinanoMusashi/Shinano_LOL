# Shan Hai Scrolls Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202015.png) | 202015 |
| ![202016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202016.png) | 202016 |
| ![202017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202017.png) | 202017 |
| ![202018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202018.png) | 202018 |
| ![202019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202019.png) | 202019 |
| ![202020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202020.png) | 202020 |
| ![202021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202021.png) | 202021 |
| ![202022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202022.png) | 202022 |