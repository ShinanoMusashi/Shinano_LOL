# DWG Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202024.png) | 202024 |