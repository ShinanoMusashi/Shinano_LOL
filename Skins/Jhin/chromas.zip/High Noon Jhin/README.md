# High Noon Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202006.png) | 202006 |
| ![202007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202007.png) | 202007 |
| ![202008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202008.png) | 202008 |
| ![202009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202009.png) | 202009 |
| ![202010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202010.png) | 202010 |
| ![202011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202011.png) | 202011 |
| ![202012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202012.png) | 202012 |
| ![202013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202013.png) | 202013 |