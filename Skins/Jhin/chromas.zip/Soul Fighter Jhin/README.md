# Soul Fighter Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202038.png) | 202038 |
| ![202039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202039.png) | 202039 |
| ![202040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202040.png) | 202040 |
| ![202041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202041.png) | 202041 |
| ![202042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202042.png) | 202042 |
| ![202043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202043.png) | 202043 |
| ![202044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202044.png) | 202044 |
| ![202045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202045.png) | 202045 |
| ![202046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202046.png) | 202046 |