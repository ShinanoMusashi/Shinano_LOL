# Mythmaker Jhin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![202048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202048.png) | 202048 |
| ![202049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202049.png) | 202049 |
| ![202050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202050.png) | 202050 |
| ![202051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202051.png) | 202051 |
| ![202052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202052.png) | 202052 |
| ![202053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/202/202053.png) | 202053 |