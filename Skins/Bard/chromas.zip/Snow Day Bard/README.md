# Snow Day Bard Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![432007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432007.png) | 432007 |