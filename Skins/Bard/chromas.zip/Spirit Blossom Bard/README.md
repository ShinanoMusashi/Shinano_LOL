# Spirit Blossom Bard Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![432038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432038.png) | 432038 |
| ![432039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432039.png) | 432039 |
| ![432040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432040.png) | 432040 |
| ![432041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432041.png) | 432041 |
| ![432042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432042.png) | 432042 |
| ![432043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432043.png) | 432043 |
| ![432044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432044.png) | 432044 |
| ![432045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432045.png) | 432045 |