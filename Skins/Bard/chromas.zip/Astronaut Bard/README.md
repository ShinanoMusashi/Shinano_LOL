# Astronaut Bard Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![432009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432009.png) | 432009 |
| ![432010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432010.png) | 432010 |
| ![432011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432011.png) | 432011 |
| ![432012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432012.png) | 432012 |
| ![432013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432013.png) | 432013 |
| ![432014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432014.png) | 432014 |
| ![432015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432015.png) | 432015 |
| ![432016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432016.png) | 432016 |