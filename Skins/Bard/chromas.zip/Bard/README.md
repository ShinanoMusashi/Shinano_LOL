# Bard Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![432002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432002.png) | 432002 |
| ![432003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432003.png) | 432003 |
| ![432004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432004.png) | 432004 |