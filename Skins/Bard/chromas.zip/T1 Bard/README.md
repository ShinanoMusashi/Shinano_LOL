# T1 Bard Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![432036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/432/432036.png) | 432036 |