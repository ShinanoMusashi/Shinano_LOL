# Battle Bunny Aurora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![893002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893002.png) | 893002 |
| ![893003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893003.png) | 893003 |
| ![893004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893004.png) | 893004 |
| ![893005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893005.png) | 893005 |
| ![893006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893006.png) | 893006 |
| ![893007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893007.png) | 893007 |
| ![893008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893008.png) | 893008 |
| ![893009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893009.png) | 893009 |
| ![893010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/893/893010.png) | 893010 |