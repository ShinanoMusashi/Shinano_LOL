# Surgeon Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98023.png) | 98023 |
| ![98024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98024.png) | 98024 |
| ![98025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98025.png) | 98025 |
| ![98026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98026.png) | 98026 |
| ![98027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98027.png) | 98027 |
| ![98028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98028.png) | 98028 |
| ![98029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98029.png) | 98029 |
| ![98030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98030.png) | 98030 |