# Warlord Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98007.png) | 98007 |
| ![98008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98008.png) | 98008 |
| ![98009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98009.png) | 98009 |
| ![98010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98010.png) | 98010 |
| ![98011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98011.png) | 98011 |
| ![98012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98012.png) | 98012 |
| ![98013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98013.png) | 98013 |
| ![98014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98014.png) | 98014 |