# Ashen Guardian Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98050.png) | 98050 |