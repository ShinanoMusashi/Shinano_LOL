# PsyOps Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98032.png) | 98032 |
| ![98033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98033.png) | 98033 |
| ![98034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98034.png) | 98034 |
| ![98035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98035.png) | 98035 |
| ![98036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98036.png) | 98036 |
| ![98037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98037.png) | 98037 |
| ![98038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98038.png) | 98038 |
| ![98039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98039.png) | 98039 |