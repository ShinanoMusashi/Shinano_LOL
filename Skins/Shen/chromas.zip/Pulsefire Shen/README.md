# Pulsefire Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98031.png) | 98031 |