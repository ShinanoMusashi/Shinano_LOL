# Shockblade Shen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![98041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98041.png) | 98041 |
| ![98042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98042.png) | 98042 |
| ![98043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98043.png) | 98043 |
| ![98044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98044.png) | 98044 |
| ![98045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98045.png) | 98045 |
| ![98046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98046.png) | 98046 |
| ![98047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98047.png) | 98047 |
| ![98048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/98/98048.png) | 98048 |