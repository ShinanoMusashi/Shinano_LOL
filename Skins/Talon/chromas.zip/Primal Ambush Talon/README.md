# Primal Ambush Talon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![91051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91051.png) | 91051 |
| ![91052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91052.png) | 91052 |
| ![91053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91053.png) | 91053 |
| ![91054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91054.png) | 91054 |
| ![91055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91055.png) | 91055 |
| ![91056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91056.png) | 91056 |
| ![91057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91057.png) | 91057 |
| ![91058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91058.png) | 91058 |