# Enduring Sword Talon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![91013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91013.png) | 91013 |
| ![91014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91014.png) | 91014 |
| ![91015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91015.png) | 91015 |
| ![91016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91016.png) | 91016 |
| ![91017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91017.png) | 91017 |
| ![91018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91018.png) | 91018 |
| ![91019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91019.png) | 91019 |