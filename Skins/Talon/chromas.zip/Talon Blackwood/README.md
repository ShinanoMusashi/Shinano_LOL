# Talon Blackwood Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![91021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91021.png) | 91021 |
| ![91022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91022.png) | 91022 |
| ![91023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91023.png) | 91023 |
| ![91024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91024.png) | 91024 |
| ![91025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91025.png) | 91025 |
| ![91026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91026.png) | 91026 |
| ![91027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91027.png) | 91027 |
| ![91028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91028.png) | 91028 |