# High Noon Talon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![91040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91040.png) | 91040 |
| ![91041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91041.png) | 91041 |
| ![91042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91042.png) | 91042 |
| ![91043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91043.png) | 91043 |
| ![91044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91044.png) | 91044 |
| ![91045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91045.png) | 91045 |
| ![91046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91046.png) | 91046 |
| ![91047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91047.png) | 91047 |
| ![91048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91048.png) | 91048 |