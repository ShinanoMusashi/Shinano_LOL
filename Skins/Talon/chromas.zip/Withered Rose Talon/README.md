# Withered Rose Talon Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![91030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91030.png) | 91030 |
| ![91031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91031.png) | 91031 |
| ![91032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91032.png) | 91032 |
| ![91033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91033.png) | 91033 |
| ![91034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91034.png) | 91034 |
| ![91035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91035.png) | 91035 |
| ![91036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91036.png) | 91036 |
| ![91037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/91/91037.png) | 91037 |