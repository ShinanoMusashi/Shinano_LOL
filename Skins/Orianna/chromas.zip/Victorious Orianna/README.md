# Victorious Orianna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![61009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61009.png) | 61009 |
| ![61010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61010.png) | 61010 |