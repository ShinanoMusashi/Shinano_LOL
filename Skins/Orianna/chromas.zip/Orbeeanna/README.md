# Orbeeanna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![61021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61021.png) | 61021 |
| ![61022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61022.png) | 61022 |
| ![61023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61023.png) | 61023 |
| ![61024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61024.png) | 61024 |
| ![61025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61025.png) | 61025 |
| ![61026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61026.png) | 61026 |
| ![61027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61027.png) | 61027 |
| ![61028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61028.png) | 61028 |