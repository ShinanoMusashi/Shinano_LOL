# Pool Party Orianna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![61013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61013.png) | 61013 |
| ![61014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61014.png) | 61014 |
| ![61015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61015.png) | 61015 |
| ![61016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61016.png) | 61016 |
| ![61017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61017.png) | 61017 |
| ![61018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61018.png) | 61018 |
| ![61019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61019.png) | 61019 |