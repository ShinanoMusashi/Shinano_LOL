# Dark Star Orianna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![61012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/61/61012.png) | 61012 |