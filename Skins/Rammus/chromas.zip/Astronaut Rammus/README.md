# Astronaut Rammus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![33018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33018.png) | 33018 |
| ![33019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33019.png) | 33019 |
| ![33020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33020.png) | 33020 |
| ![33021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33021.png) | 33021 |
| ![33022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33022.png) | 33022 |
| ![33023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33023.png) | 33023 |
| ![33024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33024.png) | 33024 |
| ![33025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33025.png) | 33025 |