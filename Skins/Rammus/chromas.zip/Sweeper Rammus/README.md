# Sweeper Rammus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![33009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33009.png) | 33009 |
| ![33010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33010.png) | 33010 |
| ![33011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33011.png) | 33011 |
| ![33012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33012.png) | 33012 |
| ![33013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33013.png) | 33013 |
| ![33014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33014.png) | 33014 |
| ![33015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33015.png) | 33015 |