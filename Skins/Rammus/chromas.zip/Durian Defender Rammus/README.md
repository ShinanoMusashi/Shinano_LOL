# Durian Defender Rammus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![33027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33027.png) | 33027 |
| ![33028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33028.png) | 33028 |
| ![33029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33029.png) | 33029 |
| ![33030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33030.png) | 33030 |
| ![33031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33031.png) | 33031 |
| ![33032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33032.png) | 33032 |
| ![33033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33033.png) | 33033 |
| ![33034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/33/33034.png) | 33034 |