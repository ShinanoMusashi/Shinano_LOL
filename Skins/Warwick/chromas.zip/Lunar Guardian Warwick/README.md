# Lunar Guardian Warwick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![19011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19011.png) | 19011 |
| ![19012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19012.png) | 19012 |
| ![19013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19013.png) | 19013 |
| ![19014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19014.png) | 19014 |
| ![19015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19015.png) | 19015 |