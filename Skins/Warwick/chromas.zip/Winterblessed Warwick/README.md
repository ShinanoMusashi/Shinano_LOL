# Winterblessed Warwick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![19047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19047.png) | 19047 |
| ![19048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19048.png) | 19048 |
| ![19049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19049.png) | 19049 |
| ![19050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19050.png) | 19050 |
| ![19051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19051.png) | 19051 |
| ![19052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19052.png) | 19052 |
| ![19053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19053.png) | 19053 |
| ![19054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19054.png) | 19054 |
| ![19055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19055.png) | 19055 |