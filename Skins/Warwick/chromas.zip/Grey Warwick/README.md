# Grey Warwick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![19018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19018.png) | 19018 |
| ![19023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19023.png) | 19023 |
| ![19025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19025.png) | 19025 |