# Old God Warwick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![19036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19036.png) | 19036 |
| ![19037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19037.png) | 19037 |
| ![19038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19038.png) | 19038 |
| ![19039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19039.png) | 19039 |
| ![19040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19040.png) | 19040 |
| ![19041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19041.png) | 19041 |
| ![19042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19042.png) | 19042 |
| ![19043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19043.png) | 19043 |
| ![19044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19044.png) | 19044 |