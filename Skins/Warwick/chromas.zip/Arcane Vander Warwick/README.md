# Arcane Vander Warwick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![19057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/19/19057.png) | 19057 |