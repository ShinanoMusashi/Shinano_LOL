# Battle Academia Jayce Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![126006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126006.png) | 126006 |
| ![126007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126007.png) | 126007 |
| ![126008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126008.png) | 126008 |
| ![126009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126009.png) | 126009 |
| ![126010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126010.png) | 126010 |
| ![126011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126011.png) | 126011 |
| ![126012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126012.png) | 126012 |
| ![126013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126013.png) | 126013 |
| ![126014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126014.png) | 126014 |