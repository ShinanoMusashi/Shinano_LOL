# Resistance Jayce Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![126016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126016.png) | 126016 |
| ![126017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126017.png) | 126017 |
| ![126018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126018.png) | 126018 |
| ![126019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126019.png) | 126019 |
| ![126020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126020.png) | 126020 |
| ![126021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126021.png) | 126021 |
| ![126022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126022.png) | 126022 |
| ![126023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126023.png) | 126023 |