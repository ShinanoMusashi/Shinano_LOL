# Zenith Games Jayce Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![126026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126026.png) | 126026 |
| ![126027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126027.png) | 126027 |
| ![126028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126028.png) | 126028 |
| ![126029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126029.png) | 126029 |
| ![126030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126030.png) | 126030 |
| ![126031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126031.png) | 126031 |
| ![126032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126032.png) | 126032 |
| ![126033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/126/126033.png) | 126033 |