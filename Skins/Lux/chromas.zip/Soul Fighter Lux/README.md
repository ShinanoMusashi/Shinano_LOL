# Soul Fighter Lux Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![99052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99052.png) | 99052 |
| ![99053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99053.png) | 99053 |
| ![99054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99054.png) | 99054 |
| ![99055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99055.png) | 99055 |
| ![99056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99056.png) | 99056 |
| ![99057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99057.png) | 99057 |
| ![99058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99058.png) | 99058 |
| ![99059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99059.png) | 99059 |
| ![99060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99060.png) | 99060 |