# Prestige Spirit Blossom Lux Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![99071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99071.png) | 99071 |