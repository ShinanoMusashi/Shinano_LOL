# Empyrean Lux Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![99043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99043.png) | 99043 |
| ![99044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99044.png) | 99044 |
| ![99045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99045.png) | 99045 |
| ![99046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99046.png) | 99046 |
| ![99047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99047.png) | 99047 |
| ![99048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99048.png) | 99048 |
| ![99049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99049.png) | 99049 |
| ![99050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99050.png) | 99050 |
| ![99051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99051.png) | 99051 |