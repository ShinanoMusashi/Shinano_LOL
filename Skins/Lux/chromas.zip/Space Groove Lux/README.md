# Space Groove Lux Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![99020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99020.png) | 99020 |
| ![99021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99021.png) | 99021 |
| ![99022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99022.png) | 99022 |
| ![99023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99023.png) | 99023 |
| ![99024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99024.png) | 99024 |
| ![99025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99025.png) | 99025 |
| ![99026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99026.png) | 99026 |
| ![99027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99027.png) | 99027 |
| ![99028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99028.png) | 99028 |