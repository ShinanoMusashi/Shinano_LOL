# Lunar Empress Lux Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![99009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99009.png) | 99009 |
| ![99010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99010.png) | 99010 |
| ![99011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99011.png) | 99011 |
| ![99012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99012.png) | 99012 |
| ![99013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/99/99013.png) | 99013 |