# Star Guardian Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222050.png) | 222050 |