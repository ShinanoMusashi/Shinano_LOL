# T1 Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222063.png) | 222063 |