# Odyssey Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222014.png) | 222014 |
| ![222015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222015.png) | 222015 |
| ![222016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222016.png) | 222016 |
| ![222017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222017.png) | 222017 |
| ![222018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222018.png) | 222018 |
| ![222019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222019.png) | 222019 |