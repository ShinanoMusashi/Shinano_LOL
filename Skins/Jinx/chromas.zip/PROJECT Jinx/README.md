# PROJECT Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222021.png) | 222021 |
| ![222022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222022.png) | 222022 |
| ![222023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222023.png) | 222023 |
| ![222024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222024.png) | 222024 |
| ![222025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222025.png) | 222025 |
| ![222026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222026.png) | 222026 |
| ![222027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222027.png) | 222027 |
| ![222028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222028.png) | 222028 |