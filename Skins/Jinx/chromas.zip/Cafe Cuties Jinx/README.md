# Cafe Cuties Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222052.png) | 222052 |
| ![222053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222053.png) | 222053 |
| ![222054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222054.png) | 222054 |
| ![222055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222055.png) | 222055 |
| ![222056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222056.png) | 222056 |
| ![222057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222057.png) | 222057 |
| ![222058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222058.png) | 222058 |
| ![222059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222059.png) | 222059 |