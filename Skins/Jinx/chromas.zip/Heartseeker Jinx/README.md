# Heartseeker Jinx Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![222030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222030.png) | 222030 |
| ![222031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222031.png) | 222031 |
| ![222032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222032.png) | 222032 |
| ![222033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222033.png) | 222033 |
| ![222034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222034.png) | 222034 |
| ![222035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222035.png) | 222035 |
| ![222036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/222/222036.png) | 222036 |