# PsyOps Samira Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![360002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360002.png) | 360002 |
| ![360003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360003.png) | 360003 |
| ![360004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360004.png) | 360004 |
| ![360005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360005.png) | 360005 |
| ![360006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360006.png) | 360006 |
| ![360007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360007.png) | 360007 |
| ![360008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360008.png) | 360008 |
| ![360009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360009.png) | 360009 |