# Space Groove Samira Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![360011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360011.png) | 360011 |
| ![360012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360012.png) | 360012 |
| ![360013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360013.png) | 360013 |
| ![360014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360014.png) | 360014 |
| ![360015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360015.png) | 360015 |
| ![360016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360016.png) | 360016 |
| ![360017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360017.png) | 360017 |
| ![360018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360018.png) | 360018 |
| ![360019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/360/360019.png) | 360019 |