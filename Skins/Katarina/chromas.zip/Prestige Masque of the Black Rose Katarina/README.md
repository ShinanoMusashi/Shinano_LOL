# Prestige Masque of the Black Rose Katarina Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![55069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55069.png) | 55069 |