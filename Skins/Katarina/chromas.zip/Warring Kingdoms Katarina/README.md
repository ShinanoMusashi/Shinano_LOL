# Warring Kingdoms Katarina Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![55011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55011.png) | 55011 |