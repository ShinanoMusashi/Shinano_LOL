# High Noon Katarina Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![55038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55038.png) | 55038 |
| ![55039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55039.png) | 55039 |
| ![55040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55040.png) | 55040 |
| ![55041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55041.png) | 55041 |
| ![55042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55042.png) | 55042 |
| ![55043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55043.png) | 55043 |
| ![55044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55044.png) | 55044 |
| ![55045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55045.png) | 55045 |
| ![55046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/55/55046.png) | 55046 |