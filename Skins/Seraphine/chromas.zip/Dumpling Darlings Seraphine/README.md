# Dumpling Darlings Seraphine Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![147051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147051.png) | 147051 |
| ![147052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147052.png) | 147052 |
| ![147053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147053.png) | 147053 |
| ![147054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147054.png) | 147054 |
| ![147055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147055.png) | 147055 |
| ![147056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147056.png) | 147056 |
| ![147057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147057.png) | 147057 |
| ![147058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147058.png) | 147058 |