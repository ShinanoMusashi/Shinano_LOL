# Graceful Phoenix Seraphine Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![147005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147005.png) | 147005 |
| ![147006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147006.png) | 147006 |
| ![147007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147007.png) | 147007 |
| ![147008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147008.png) | 147008 |
| ![147009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147009.png) | 147009 |
| ![147010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147010.png) | 147010 |
| ![147011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147011.png) | 147011 |
| ![147012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147012.png) | 147012 |
| ![147013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147013.png) | 147013 |