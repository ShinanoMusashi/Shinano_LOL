# Faerie Court Seraphine Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![147025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147025.png) | 147025 |
| ![147026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147026.png) | 147026 |
| ![147027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147027.png) | 147027 |
| ![147028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147028.png) | 147028 |
| ![147029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147029.png) | 147029 |
| ![147030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147030.png) | 147030 |
| ![147031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147031.png) | 147031 |
| ![147032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147032.png) | 147032 |
| ![147033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147033.png) | 147033 |