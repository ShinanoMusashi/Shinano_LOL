# Star Guardian Seraphine Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![147035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147035.png) | 147035 |
| ![147036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147036.png) | 147036 |
| ![147037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147037.png) | 147037 |
| ![147038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147038.png) | 147038 |
| ![147039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147039.png) | 147039 |
| ![147040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147040.png) | 147040 |
| ![147041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147041.png) | 147041 |
| ![147042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147042.png) | 147042 |