# Battle Dove Seraphine Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![147044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147044.png) | 147044 |
| ![147045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147045.png) | 147045 |
| ![147046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147046.png) | 147046 |
| ![147047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147047.png) | 147047 |
| ![147048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147048.png) | 147048 |
| ![147049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/147/147049.png) | 147049 |