# Strike Commander Camille Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![164022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164022.png) | 164022 |
| ![164023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164023.png) | 164023 |
| ![164024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164024.png) | 164024 |
| ![164025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164025.png) | 164025 |
| ![164026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164026.png) | 164026 |
| ![164027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164027.png) | 164027 |
| ![164028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164028.png) | 164028 |
| ![164029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164029.png) | 164029 |
| ![164030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164030.png) | 164030 |