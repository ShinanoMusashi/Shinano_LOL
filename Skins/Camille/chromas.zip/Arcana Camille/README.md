# Arcana Camille Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![164012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164012.png) | 164012 |
| ![164013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164013.png) | 164013 |
| ![164014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164014.png) | 164014 |
| ![164015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164015.png) | 164015 |
| ![164016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164016.png) | 164016 |
| ![164017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164017.png) | 164017 |
| ![164018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164018.png) | 164018 |
| ![164019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/164/164019.png) | 164019 |