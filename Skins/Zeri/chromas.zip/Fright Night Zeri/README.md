# Fright Night Zeri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![221030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221030.png) | 221030 |
| ![221031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221031.png) | 221031 |
| ![221032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221032.png) | 221032 |
| ![221033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221033.png) | 221033 |
| ![221034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221034.png) | 221034 |
| ![221035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221035.png) | 221035 |
| ![221036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221036.png) | 221036 |
| ![221037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221037.png) | 221037 |
| ![221038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221038.png) | 221038 |
| ![221039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221039.png) | 221039 |