# Withered Rose Zeri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![221002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221002.png) | 221002 |
| ![221003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221003.png) | 221003 |
| ![221004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221004.png) | 221004 |
| ![221005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221005.png) | 221005 |
| ![221006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221006.png) | 221006 |
| ![221007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221007.png) | 221007 |
| ![221008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221008.png) | 221008 |
| ![221009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221009.png) | 221009 |