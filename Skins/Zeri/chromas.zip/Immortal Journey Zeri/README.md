# Immortal Journey Zeri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![221020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221020.png) | 221020 |
| ![221021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221021.png) | 221021 |
| ![221022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221022.png) | 221022 |
| ![221023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221023.png) | 221023 |
| ![221024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221024.png) | 221024 |
| ![221025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221025.png) | 221025 |
| ![221026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221026.png) | 221026 |
| ![221027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221027.png) | 221027 |