# Ocean Song Zeri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![221011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221011.png) | 221011 |
| ![221012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221012.png) | 221012 |
| ![221013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221013.png) | 221013 |
| ![221014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221014.png) | 221014 |
| ![221015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221015.png) | 221015 |
| ![221016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221016.png) | 221016 |
| ![221017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221017.png) | 221017 |
| ![221018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/221/221018.png) | 221018 |