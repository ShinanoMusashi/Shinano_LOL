# Battle Academia Ezreal Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![81032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81032.png) | 81032 |