# Heavenscale Ezreal Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![81055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81055.png) | 81055 |
| ![81056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81056.png) | 81056 |
| ![81057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81057.png) | 81057 |
| ![81058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81058.png) | 81058 |
| ![81059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81059.png) | 81059 |
| ![81060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81060.png) | 81060 |
| ![81061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81061.png) | 81061 |
| ![81062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81062.png) | 81062 |
| ![81063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81063.png) | 81063 |
| ![81064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81064.png) | 81064 |