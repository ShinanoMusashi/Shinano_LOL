# HEARTSTEEL Ezreal Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![81045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81045.png) | 81045 |
| ![81046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81046.png) | 81046 |
| ![81047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81047.png) | 81047 |
| ![81048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81048.png) | 81048 |
| ![81049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81049.png) | 81049 |
| ![81050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81050.png) | 81050 |
| ![81051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81051.png) | 81051 |
| ![81052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81052.png) | 81052 |
| ![81053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81053.png) | 81053 |