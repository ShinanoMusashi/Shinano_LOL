# Porcelain Protector Ezreal Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![81026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81026.png) | 81026 |
| ![81027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81027.png) | 81027 |
| ![81028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81028.png) | 81028 |
| ![81029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81029.png) | 81029 |
| ![81030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81030.png) | 81030 |
| ![81031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81031.png) | 81031 |