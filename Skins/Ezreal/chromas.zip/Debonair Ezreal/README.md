# Debonair Ezreal Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![81010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81010.png) | 81010 |
| ![81011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81011.png) | 81011 |
| ![81012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81012.png) | 81012 |
| ![81013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81013.png) | 81013 |
| ![81014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81014.png) | 81014 |
| ![81015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81015.png) | 81015 |
| ![81016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81016.png) | 81016 |
| ![81017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/81/81017.png) | 81017 |