# Street Demons Dr. Mundo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![36022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36022.png) | 36022 |
| ![36023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36023.png) | 36023 |
| ![36024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36024.png) | 36024 |
| ![36025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36025.png) | 36025 |
| ![36026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36026.png) | 36026 |
| ![36027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36027.png) | 36027 |
| ![36028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36028.png) | 36028 |
| ![36029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36029.png) | 36029 |