# Corporate Mundo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![36016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36016.png) | 36016 |
| ![36017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36017.png) | 36017 |
| ![36018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36018.png) | 36018 |
| ![36019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36019.png) | 36019 |
| ![36020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36020.png) | 36020 |