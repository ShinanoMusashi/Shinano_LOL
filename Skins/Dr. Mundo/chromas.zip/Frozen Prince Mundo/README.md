# Frozen Prince Mundo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![36011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36011.png) | 36011 |
| ![36012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36012.png) | 36012 |
| ![36013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36013.png) | 36013 |
| ![36014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36014.png) | 36014 |
| ![36015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/36/36015.png) | 36015 |