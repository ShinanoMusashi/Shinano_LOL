# Inkshadow Volibear Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![106020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106020.png) | 106020 |
| ![106021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106021.png) | 106021 |
| ![106022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106022.png) | 106022 |
| ![106023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106023.png) | 106023 |
| ![106024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106024.png) | 106024 |
| ![106025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106025.png) | 106025 |
| ![106026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106026.png) | 106026 |
| ![106027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106027.png) | 106027 |
| ![106028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106028.png) | 106028 |