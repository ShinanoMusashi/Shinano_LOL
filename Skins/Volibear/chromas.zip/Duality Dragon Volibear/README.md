# Duality Dragon Volibear Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![106010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106010.png) | 106010 |
| ![106011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106011.png) | 106011 |
| ![106012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106012.png) | 106012 |
| ![106013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106013.png) | 106013 |
| ![106014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106014.png) | 106014 |
| ![106015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106015.png) | 106015 |
| ![106016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106016.png) | 106016 |
| ![106017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106017.png) | 106017 |
| ![106018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/106/106018.png) | 106018 |