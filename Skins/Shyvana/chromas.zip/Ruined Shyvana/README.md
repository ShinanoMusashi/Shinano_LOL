# Ruined Shyvana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![102009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102009.png) | 102009 |
| ![102010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102010.png) | 102010 |
| ![102011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102011.png) | 102011 |
| ![102012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102012.png) | 102012 |
| ![102013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102013.png) | 102013 |
| ![102014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102014.png) | 102014 |
| ![102015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102015.png) | 102015 |
| ![102016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/102/102016.png) | 102016 |