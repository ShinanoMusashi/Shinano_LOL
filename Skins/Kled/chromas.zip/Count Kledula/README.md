# Count Kledula Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![240003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240003.png) | 240003 |
| ![240004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240004.png) | 240004 |
| ![240005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240005.png) | 240005 |
| ![240006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240006.png) | 240006 |
| ![240007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240007.png) | 240007 |
| ![240008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240008.png) | 240008 |