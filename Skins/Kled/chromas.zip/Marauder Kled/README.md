# Marauder Kled Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![240010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240010.png) | 240010 |
| ![240011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240011.png) | 240011 |
| ![240012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240012.png) | 240012 |
| ![240013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240013.png) | 240013 |
| ![240014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240014.png) | 240014 |
| ![240015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240015.png) | 240015 |
| ![240016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240016.png) | 240016 |
| ![240017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240017.png) | 240017 |