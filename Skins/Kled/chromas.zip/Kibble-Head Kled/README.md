# Kibble-Head Kled Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![240019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240019.png) | 240019 |
| ![240020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240020.png) | 240020 |
| ![240021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240021.png) | 240021 |
| ![240022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240022.png) | 240022 |
| ![240023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240023.png) | 240023 |
| ![240024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240024.png) | 240024 |
| ![240025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240025.png) | 240025 |
| ![240026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/240/240026.png) | 240026 |