# Furyhorn Cosplay Veigar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45024.png) | 45024 |
| ![45025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45025.png) | 45025 |
| ![45026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45026.png) | 45026 |
| ![45027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45027.png) | 45027 |
| ![45028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45028.png) | 45028 |
| ![45029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45029.png) | 45029 |
| ![45030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45030.png) | 45030 |
| ![45031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45031.png) | 45031 |