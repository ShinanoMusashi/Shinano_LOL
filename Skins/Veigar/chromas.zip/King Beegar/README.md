# King Beegar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45052.png) | 45052 |
| ![45053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45053.png) | 45053 |
| ![45054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45054.png) | 45054 |
| ![45055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45055.png) | 45055 |
| ![45056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45056.png) | 45056 |
| ![45057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45057.png) | 45057 |
| ![45058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45058.png) | 45058 |
| ![45059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45059.png) | 45059 |