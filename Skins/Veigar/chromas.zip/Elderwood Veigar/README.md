# Elderwood Veigar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45014.png) | 45014 |
| ![45015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45015.png) | 45015 |
| ![45016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45016.png) | 45016 |
| ![45017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45017.png) | 45017 |
| ![45018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45018.png) | 45018 |
| ![45019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45019.png) | 45019 |
| ![45020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45020.png) | 45020 |
| ![45021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45021.png) | 45021 |
| ![45022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45022.png) | 45022 |