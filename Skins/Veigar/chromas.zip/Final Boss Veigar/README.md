# Final Boss Veigar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45042.png) | 45042 |