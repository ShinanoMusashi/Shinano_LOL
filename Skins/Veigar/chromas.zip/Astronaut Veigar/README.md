# Astronaut Veigar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45033.png) | 45033 |
| ![45034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45034.png) | 45034 |
| ![45035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45035.png) | 45035 |
| ![45036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45036.png) | 45036 |
| ![45037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45037.png) | 45037 |
| ![45038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45038.png) | 45038 |
| ![45039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45039.png) | 45039 |
| ![45040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45040.png) | 45040 |