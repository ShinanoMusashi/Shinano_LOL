# Omega Squad Veigar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![45010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45010.png) | 45010 |
| ![45011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45011.png) | 45011 |
| ![45012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/45/45012.png) | 45012 |