# Pentakill III Lost Chapter Sona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![37027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37027.png) | 37027 |
| ![37028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37028.png) | 37028 |
| ![37029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37029.png) | 37029 |
| ![37030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37030.png) | 37030 |
| ![37031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37031.png) | 37031 |
| ![37032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37032.png) | 37032 |
| ![37033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37033.png) | 37033 |
| ![37034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37034.png) | 37034 |