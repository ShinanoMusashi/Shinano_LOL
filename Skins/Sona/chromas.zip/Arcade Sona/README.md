# Arcade Sona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![37016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37016.png) | 37016 |