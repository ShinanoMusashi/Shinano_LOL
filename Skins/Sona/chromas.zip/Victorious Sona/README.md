# Victorious Sona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![37057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37057.png) | 37057 |
| ![37058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37058.png) | 37058 |
| ![37059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37059.png) | 37059 |
| ![37060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37060.png) | 37060 |
| ![37061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37061.png) | 37061 |
| ![37062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37062.png) | 37062 |
| ![37063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37063.png) | 37063 |
| ![37064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37064.png) | 37064 |
| ![37065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37065.png) | 37065 |