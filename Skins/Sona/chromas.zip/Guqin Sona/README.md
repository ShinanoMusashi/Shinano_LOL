# Guqin Sona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![37008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37008.png) | 37008 |
| ![37055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37055.png) | 37055 |