# Immortal Journey Sona Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![37047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37047.png) | 37047 |
| ![37048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37048.png) | 37048 |
| ![37049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37049.png) | 37049 |
| ![37050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37050.png) | 37050 |
| ![37051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37051.png) | 37051 |
| ![37052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37052.png) | 37052 |
| ![37053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37053.png) | 37053 |
| ![37054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/37/37054.png) | 37054 |