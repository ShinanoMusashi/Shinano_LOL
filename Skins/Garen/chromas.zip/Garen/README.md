# Garen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![86007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86007.png) | 86007 |
| ![86008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86008.png) | 86008 |
| ![86009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86009.png) | 86009 |