# Battle Academia Garen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![86025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86025.png) | 86025 |
| ![86026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86026.png) | 86026 |
| ![86027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86027.png) | 86027 |
| ![86028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86028.png) | 86028 |
| ![86029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86029.png) | 86029 |
| ![86030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86030.png) | 86030 |
| ![86031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86031.png) | 86031 |
| ![86032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/86/86032.png) | 86032 |