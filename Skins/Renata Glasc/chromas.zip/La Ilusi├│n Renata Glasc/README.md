# La Ilusi��n Renata Glasc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![888022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888022.png) | 888022 |
| ![888023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888023.png) | 888023 |
| ![888024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888024.png) | 888024 |
| ![888025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888025.png) | 888025 |
| ![888026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888026.png) | 888026 |
| ![888027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888027.png) | 888027 |
| ![888028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888028.png) | 888028 |
| ![888029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888029.png) | 888029 |
| ![888030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888030.png) | 888030 |