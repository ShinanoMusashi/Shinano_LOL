# Admiral Glasc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![888002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888002.png) | 888002 |
| ![888003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888003.png) | 888003 |
| ![888004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888004.png) | 888004 |
| ![888005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888005.png) | 888005 |
| ![888006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888006.png) | 888006 |
| ![888007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888007.png) | 888007 |
| ![888008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888008.png) | 888008 |
| ![888009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888009.png) | 888009 |
| ![888011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888011.png) | 888011 |