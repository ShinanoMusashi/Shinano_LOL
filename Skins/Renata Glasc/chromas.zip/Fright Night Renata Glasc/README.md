# Fright Night Renata Glasc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![888012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888012.png) | 888012 |
| ![888013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888013.png) | 888013 |
| ![888014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888014.png) | 888014 |
| ![888015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888015.png) | 888015 |
| ![888016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888016.png) | 888016 |
| ![888017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888017.png) | 888017 |
| ![888018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888018.png) | 888018 |
| ![888019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/888/888019.png) | 888019 |