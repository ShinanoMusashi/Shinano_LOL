# Bee'Koz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![161021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161021.png) | 161021 |
| ![161022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161022.png) | 161022 |
| ![161023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161023.png) | 161023 |
| ![161024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161024.png) | 161024 |
| ![161025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161025.png) | 161025 |
| ![161026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161026.png) | 161026 |
| ![161027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161027.png) | 161027 |
| ![161028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161028.png) | 161028 |