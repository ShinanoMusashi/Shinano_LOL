# Blackfrost Vel'Koz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![161012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161012.png) | 161012 |
| ![161013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161013.png) | 161013 |
| ![161014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161014.png) | 161014 |
| ![161015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161015.png) | 161015 |
| ![161016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161016.png) | 161016 |
| ![161017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161017.png) | 161017 |
| ![161018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161018.png) | 161018 |
| ![161019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161019.png) | 161019 |