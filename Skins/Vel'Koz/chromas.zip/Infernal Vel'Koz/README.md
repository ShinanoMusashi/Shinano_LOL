# Infernal Vel'Koz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![161005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161005.png) | 161005 |
| ![161006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161006.png) | 161006 |
| ![161007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161007.png) | 161007 |
| ![161008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161008.png) | 161008 |
| ![161009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161009.png) | 161009 |
| ![161010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/161/161010.png) | 161010 |