# Cafe Cuties Lulu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![117047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117047.png) | 117047 |
| ![117048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117048.png) | 117048 |
| ![117049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117049.png) | 117049 |
| ![117050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117050.png) | 117050 |
| ![117051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117051.png) | 117051 |
| ![117052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117052.png) | 117052 |
| ![117053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117053.png) | 117053 |
| ![117054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117054.png) | 117054 |