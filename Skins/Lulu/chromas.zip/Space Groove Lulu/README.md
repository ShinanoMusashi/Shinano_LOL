# Space Groove Lulu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![117028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117028.png) | 117028 |
| ![117029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117029.png) | 117029 |
| ![117030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117030.png) | 117030 |
| ![117031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117031.png) | 117031 |
| ![117032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117032.png) | 117032 |
| ![117033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117033.png) | 117033 |
| ![117034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117034.png) | 117034 |
| ![117035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117035.png) | 117035 |
| ![117036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117036.png) | 117036 |