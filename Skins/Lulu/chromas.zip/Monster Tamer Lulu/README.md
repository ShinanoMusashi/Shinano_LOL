# Monster Tamer Lulu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![117038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117038.png) | 117038 |
| ![117039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117039.png) | 117039 |
| ![117040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117040.png) | 117040 |
| ![117041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117041.png) | 117041 |
| ![117042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117042.png) | 117042 |
| ![117043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117043.png) | 117043 |
| ![117044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117044.png) | 117044 |
| ![117045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117045.png) | 117045 |