# Cosmic Enchantress Lulu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![117016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117016.png) | 117016 |
| ![117017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117017.png) | 117017 |
| ![117018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117018.png) | 117018 |
| ![117019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117019.png) | 117019 |
| ![117020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/117/117020.png) | 117020 |