# Heavenscale Smolder Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![901002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901002.png) | 901002 |
| ![901003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901003.png) | 901003 |
| ![901004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901004.png) | 901004 |
| ![901005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901005.png) | 901005 |
| ![901006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901006.png) | 901006 |
| ![901007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901007.png) | 901007 |
| ![901008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901008.png) | 901008 |
| ![901009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901009.png) | 901009 |
| ![901010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/901/901010.png) | 901010 |