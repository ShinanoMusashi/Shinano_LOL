# Star Guardian Taliyah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![163012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163012.png) | 163012 |
| ![163013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163013.png) | 163013 |
| ![163014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163014.png) | 163014 |
| ![163015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163015.png) | 163015 |
| ![163016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163016.png) | 163016 |
| ![163017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163017.png) | 163017 |
| ![163018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163018.png) | 163018 |
| ![163019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163019.png) | 163019 |
| ![163020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163020.png) | 163020 |