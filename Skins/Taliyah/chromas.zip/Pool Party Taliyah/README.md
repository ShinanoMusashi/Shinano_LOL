# Pool Party Taliyah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![163004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163004.png) | 163004 |
| ![163005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163005.png) | 163005 |
| ![163006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163006.png) | 163006 |
| ![163007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163007.png) | 163007 |
| ![163008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163008.png) | 163008 |
| ![163009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163009.png) | 163009 |
| ![163010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163010.png) | 163010 |