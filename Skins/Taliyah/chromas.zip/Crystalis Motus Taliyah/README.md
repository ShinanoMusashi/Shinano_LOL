# Crystalis Motus Taliyah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![163022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/163/163022.png) | 163022 |