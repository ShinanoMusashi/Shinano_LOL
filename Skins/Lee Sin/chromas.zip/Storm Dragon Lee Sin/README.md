# Storm Dragon Lee Sin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![64032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64032.png) | 64032 |
| ![64033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64033.png) | 64033 |
| ![64034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64034.png) | 64034 |
| ![64035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64035.png) | 64035 |
| ![64036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64036.png) | 64036 |
| ![64037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64037.png) | 64037 |
| ![64038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64038.png) | 64038 |
| ![64050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64050.png) | 64050 |