# Zenith Games Lee Sin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![64042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64042.png) | 64042 |
| ![64043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64043.png) | 64043 |
| ![64044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64044.png) | 64044 |
| ![64045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64045.png) | 64045 |
| ![64046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64046.png) | 64046 |
| ![64047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64047.png) | 64047 |
| ![64048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64048.png) | 64048 |
| ![64049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64049.png) | 64049 |