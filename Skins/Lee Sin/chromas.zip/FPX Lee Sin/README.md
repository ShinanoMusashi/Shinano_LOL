# FPX Lee Sin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![64030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64030.png) | 64030 |