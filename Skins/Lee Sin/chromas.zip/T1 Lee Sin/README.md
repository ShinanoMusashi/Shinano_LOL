# T1 Lee Sin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![64069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64069.png) | 64069 |