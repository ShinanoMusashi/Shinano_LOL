# Muay Thai Lee Sin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![64060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64060.png) | 64060 |
| ![64061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64061.png) | 64061 |
| ![64062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64062.png) | 64062 |
| ![64063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64063.png) | 64063 |
| ![64064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64064.png) | 64064 |
| ![64065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64065.png) | 64065 |
| ![64066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64066.png) | 64066 |
| ![64067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/64/64067.png) | 64067 |