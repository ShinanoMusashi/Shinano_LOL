# Primordian Aatrox Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `266034` | ![266034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266034.png) | 1 |
| `266035` | ![266035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266035.png) | 2 |
| `266036` | ![266036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266036.png) | 3 |
| `266037` | ![266037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266037.png) | 4 |
| `266038` | ![266038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266038.png) | 5 |
| `266039` | ![266039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266039.png) | 6 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.