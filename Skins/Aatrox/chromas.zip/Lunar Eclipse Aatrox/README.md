# Lunar Eclipse Aatrox Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![266022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266022.png) | 266022 |
| ![266023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266023.png) | 266023 |
| ![266024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266024.png) | 266024 |
| ![266025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266025.png) | 266025 |
| ![266026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266026.png) | 266026 |
| ![266027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266027.png) | 266027 |
| ![266028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266028.png) | 266028 |
| ![266029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266029.png) | 266029 |