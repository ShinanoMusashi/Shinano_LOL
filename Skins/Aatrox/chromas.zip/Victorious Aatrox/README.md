# Victorious Aatrox Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![266010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266010.png) | 266010 |