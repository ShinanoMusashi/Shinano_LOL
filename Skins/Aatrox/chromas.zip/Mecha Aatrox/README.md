# Mecha Aatrox Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![266004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266004.png) | 266004 |
| ![266005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266005.png) | 266005 |
| ![266006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266006.png) | 266006 |