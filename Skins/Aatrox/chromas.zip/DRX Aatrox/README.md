# DRX Aatrox Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![266032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/266/266032.png) | 266032 |