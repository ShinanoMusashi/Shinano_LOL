# iG Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114079](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114079.png) | 114079 |