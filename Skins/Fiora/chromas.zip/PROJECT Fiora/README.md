# PROJECT Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114040.png) | 114040 |