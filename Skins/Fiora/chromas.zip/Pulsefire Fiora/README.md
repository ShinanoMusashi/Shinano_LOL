# Pulsefire Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114042.png) | 114042 |
| ![114043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114043.png) | 114043 |
| ![114044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114044.png) | 114044 |
| ![114045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114045.png) | 114045 |
| ![114046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114046.png) | 114046 |
| ![114047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114047.png) | 114047 |
| ![114048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114048.png) | 114048 |
| ![114049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114049.png) | 114049 |