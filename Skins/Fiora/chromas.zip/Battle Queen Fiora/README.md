# Battle Queen Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114090](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114090.png) | 114090 |
| ![114091](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114091.png) | 114091 |
| ![114092](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114092.png) | 114092 |
| ![114093](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114093.png) | 114093 |
| ![114094](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114094.png) | 114094 |
| ![114095](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114095.png) | 114095 |
| ![114096](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114096.png) | 114096 |
| ![114097](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114097.png) | 114097 |