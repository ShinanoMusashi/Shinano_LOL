# Bewitching Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114061.png) | 114061 |
| ![114062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114062.png) | 114062 |
| ![114063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114063.png) | 114063 |
| ![114064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114064.png) | 114064 |
| ![114065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114065.png) | 114065 |
| ![114066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114066.png) | 114066 |
| ![114067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114067.png) | 114067 |
| ![114068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114068.png) | 114068 |