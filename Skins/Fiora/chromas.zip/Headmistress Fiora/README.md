# Headmistress Fiora Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![114006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114006.png) | 114006 |
| ![114007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114007.png) | 114007 |
| ![114008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114008.png) | 114008 |
| ![114009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114009.png) | 114009 |
| ![114010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114010.png) | 114010 |
| ![114011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114011.png) | 114011 |
| ![114012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114012.png) | 114012 |
| ![114013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/114/114013.png) | 114013 |