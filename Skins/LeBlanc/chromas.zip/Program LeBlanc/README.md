# Program LeBlanc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![7013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7013.png) | 7013 |
| ![7014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7014.png) | 7014 |
| ![7015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7015.png) | 7015 |
| ![7016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7016.png) | 7016 |
| ![7017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7017.png) | 7017 |
| ![7018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7018.png) | 7018 |