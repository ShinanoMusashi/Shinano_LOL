# Debonair LeBlanc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![7036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7036.png) | 7036 |
| ![7037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7037.png) | 7037 |
| ![7038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7038.png) | 7038 |
| ![7039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7039.png) | 7039 |
| ![7040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7040.png) | 7040 |
| ![7041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7041.png) | 7041 |
| ![7042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7042.png) | 7042 |
| ![7043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7043.png) | 7043 |
| ![7044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7044.png) | 7044 |