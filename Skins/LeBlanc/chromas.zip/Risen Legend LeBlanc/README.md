# Risen Legend LeBlanc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![7056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7056.png) | 7056 |
| ![7057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7057.png) | 7057 |