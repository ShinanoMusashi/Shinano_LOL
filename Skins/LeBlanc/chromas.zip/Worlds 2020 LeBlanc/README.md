# Worlds 2020 LeBlanc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![7030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7030.png) | 7030 |
| ![7031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7031.png) | 7031 |
| ![7032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7032.png) | 7032 |