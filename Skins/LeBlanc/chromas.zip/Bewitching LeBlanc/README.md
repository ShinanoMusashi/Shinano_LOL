# Bewitching LeBlanc Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![7046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7046.png) | 7046 |
| ![7047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7047.png) | 7047 |
| ![7048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7048.png) | 7048 |
| ![7049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7049.png) | 7049 |
| ![7050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7050.png) | 7050 |
| ![7051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7051.png) | 7051 |
| ![7052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7052.png) | 7052 |
| ![7053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/7/7053.png) | 7053 |