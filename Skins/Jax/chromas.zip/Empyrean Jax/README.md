# Empyrean Jax Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![24023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24023.png) | 24023 |
| ![24024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24024.png) | 24024 |
| ![24025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24025.png) | 24025 |
| ![24026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24026.png) | 24026 |
| ![24027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24027.png) | 24027 |
| ![24028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24028.png) | 24028 |
| ![24029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24029.png) | 24029 |
| ![24030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24030.png) | 24030 |
| ![24031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24031.png) | 24031 |