# Mecha Kingdoms Jax Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![24015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24015.png) | 24015 |
| ![24016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24016.png) | 24016 |
| ![24017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24017.png) | 24017 |
| ![24018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24018.png) | 24018 |
| ![24019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24019.png) | 24019 |