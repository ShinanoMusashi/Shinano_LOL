# Nemesis Jax Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![24009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24009.png) | 24009 |
| ![24010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24010.png) | 24010 |
| ![24011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24011.png) | 24011 |