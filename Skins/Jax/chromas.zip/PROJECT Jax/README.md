# PROJECT Jax Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![24034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24034.png) | 24034 |
| ![24035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24035.png) | 24035 |
| ![24036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24036.png) | 24036 |
| ![24037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24037.png) | 24037 |
| ![24038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24038.png) | 24038 |
| ![24039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24039.png) | 24039 |
| ![24040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24040.png) | 24040 |
| ![24041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/24/24041.png) | 24041 |