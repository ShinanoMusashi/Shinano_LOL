# Inkshadow Yasuo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![157058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157058.png) | 157058 |
| ![157059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157059.png) | 157059 |
| ![157060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157060.png) | 157060 |
| ![157061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157061.png) | 157061 |
| ![157062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157062.png) | 157062 |
| ![157063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157063.png) | 157063 |
| ![157064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157064.png) | 157064 |
| ![157065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157065.png) | 157065 |
| ![157066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157066.png) | 157066 |
| ![157067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157067.png) | 157067 |