# Battle Boss Yasuo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![157019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157019.png) | 157019 |
| ![157020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157020.png) | 157020 |
| ![157021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157021.png) | 157021 |
| ![157022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157022.png) | 157022 |
| ![157023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157023.png) | 157023 |
| ![157024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157024.png) | 157024 |
| ![157025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157025.png) | 157025 |
| ![157026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157026.png) | 157026 |