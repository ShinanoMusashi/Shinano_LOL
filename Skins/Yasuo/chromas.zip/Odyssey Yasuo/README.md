# Odyssey Yasuo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![157011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157011.png) | 157011 |
| ![157012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157012.png) | 157012 |
| ![157013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157013.png) | 157013 |
| ![157014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157014.png) | 157014 |
| ![157015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157015.png) | 157015 |
| ![157016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157016.png) | 157016 |