# Sea Dog Yasuo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![157046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157046.png) | 157046 |
| ![157047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157047.png) | 157047 |
| ![157048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157048.png) | 157048 |
| ![157049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157049.png) | 157049 |
| ![157050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157050.png) | 157050 |
| ![157051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157051.png) | 157051 |
| ![157052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157052.png) | 157052 |
| ![157053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157053.png) | 157053 |