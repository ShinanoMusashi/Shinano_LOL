# True Damage Yasuo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![157027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157027.png) | 157027 |
| ![157028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157028.png) | 157028 |
| ![157029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157029.png) | 157029 |
| ![157030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157030.png) | 157030 |
| ![157031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157031.png) | 157031 |
| ![157032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157032.png) | 157032 |
| ![157033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/157/157033.png) | 157033 |