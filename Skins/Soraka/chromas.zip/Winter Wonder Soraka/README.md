# Winter Wonder Soraka Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![16010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16010.png) | 16010 |
| ![16011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16011.png) | 16011 |
| ![16012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16012.png) | 16012 |
| ![16013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16013.png) | 16013 |
| ![16014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16014.png) | 16014 |