# Cafe Cuties Soraka Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![16019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16019.png) | 16019 |
| ![16020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16020.png) | 16020 |
| ![16021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16021.png) | 16021 |
| ![16022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16022.png) | 16022 |
| ![16023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16023.png) | 16023 |
| ![16024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16024.png) | 16024 |
| ![16025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16025.png) | 16025 |
| ![16026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16026.png) | 16026 |