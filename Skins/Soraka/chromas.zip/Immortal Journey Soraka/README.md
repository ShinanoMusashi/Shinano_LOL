# Immortal Journey Soraka Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![16038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16038.png) | 16038 |
| ![16039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16039.png) | 16039 |
| ![16040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16040.png) | 16040 |
| ![16041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16041.png) | 16041 |
| ![16042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16042.png) | 16042 |
| ![16043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16043.png) | 16043 |