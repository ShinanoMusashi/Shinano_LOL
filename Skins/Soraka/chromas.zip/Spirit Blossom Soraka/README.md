# Spirit Blossom Soraka Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![16028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16028.png) | 16028 |
| ![16029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16029.png) | 16029 |
| ![16030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16030.png) | 16030 |
| ![16031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16031.png) | 16031 |
| ![16032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16032.png) | 16032 |
| ![16033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16033.png) | 16033 |
| ![16034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16034.png) | 16034 |
| ![16035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16035.png) | 16035 |
| ![16036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16036.png) | 16036 |