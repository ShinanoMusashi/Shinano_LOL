# Faerie Court Soraka Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![16045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16045.png) | 16045 |
| ![16046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16046.png) | 16046 |
| ![16047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16047.png) | 16047 |
| ![16048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16048.png) | 16048 |
| ![16049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16049.png) | 16049 |
| ![16050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16050.png) | 16050 |
| ![16051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16051.png) | 16051 |
| ![16052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/16/16052.png) | 16052 |