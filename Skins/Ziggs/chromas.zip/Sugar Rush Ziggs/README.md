# Sugar Rush Ziggs Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![115015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115015.png) | 115015 |
| ![115016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115016.png) | 115016 |
| ![115017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115017.png) | 115017 |
| ![115018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115018.png) | 115018 |
| ![115019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115019.png) | 115019 |
| ![115020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115020.png) | 115020 |
| ![115021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115021.png) | 115021 |
| ![115022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115022.png) | 115022 |