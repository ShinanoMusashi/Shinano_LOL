# BZZZiggs Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![115025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115025.png) | 115025 |
| ![115026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115026.png) | 115026 |
| ![115027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115027.png) | 115027 |
| ![115028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115028.png) | 115028 |
| ![115029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115029.png) | 115029 |
| ![115030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115030.png) | 115030 |
| ![115031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115031.png) | 115031 |
| ![115032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115032.png) | 115032 |