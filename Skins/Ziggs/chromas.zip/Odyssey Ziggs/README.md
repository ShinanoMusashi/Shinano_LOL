# Odyssey Ziggs Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![115008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115008.png) | 115008 |
| ![115009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115009.png) | 115009 |
| ![115010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115010.png) | 115010 |
| ![115011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115011.png) | 115011 |
| ![115012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115012.png) | 115012 |
| ![115013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115013.png) | 115013 |