# La Ilusi��n Ziggs Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![115034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115034.png) | 115034 |
| ![115035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115035.png) | 115035 |
| ![115036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115036.png) | 115036 |
| ![115037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115037.png) | 115037 |
| ![115038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115038.png) | 115038 |
| ![115039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115039.png) | 115039 |
| ![115040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115040.png) | 115040 |
| ![115041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115041.png) | 115041 |
| ![115042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/115/115042.png) | 115042 |