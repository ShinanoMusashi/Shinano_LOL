# Cyber Cat Yuumi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![350051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350051.png) | 350051 |
| ![350052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350052.png) | 350052 |
| ![350053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350053.png) | 350053 |
| ![350054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350054.png) | 350054 |
| ![350055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350055.png) | 350055 |
| ![350056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350056.png) | 350056 |
| ![350057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350057.png) | 350057 |
| ![350058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350058.png) | 350058 |
| ![350059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350059.png) | 350059 |
| ![350060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350060.png) | 350060 |