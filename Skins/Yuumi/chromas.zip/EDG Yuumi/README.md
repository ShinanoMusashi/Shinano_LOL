# EDG Yuumi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![350038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350038.png) | 350038 |
| ![350048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350048.png) | 350048 |