# Yuubee Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![350020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350020.png) | 350020 |
| ![350021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350021.png) | 350021 |
| ![350022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350022.png) | 350022 |
| ![350023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350023.png) | 350023 |
| ![350024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350024.png) | 350024 |
| ![350025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350025.png) | 350025 |
| ![350026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350026.png) | 350026 |
| ![350027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350027.png) | 350027 |