# Shiba Yuumi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![350040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350040.png) | 350040 |
| ![350041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350041.png) | 350041 |
| ![350042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350042.png) | 350042 |
| ![350043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350043.png) | 350043 |
| ![350044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350044.png) | 350044 |
| ![350045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350045.png) | 350045 |
| ![350046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350046.png) | 350046 |
| ![350047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/350/350047.png) | 350047 |