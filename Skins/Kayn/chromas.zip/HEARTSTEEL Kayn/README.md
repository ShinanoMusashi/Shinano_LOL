# HEARTSTEEL Kayn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![141021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141021.png) | 141021 |
| ![141022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141022.png) | 141022 |
| ![141023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141023.png) | 141023 |
| ![141024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141024.png) | 141024 |
| ![141025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141025.png) | 141025 |