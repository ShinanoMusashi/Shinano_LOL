# Snow Moon Kayn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![141016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141016.png) | 141016 |
| ![141017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141017.png) | 141017 |
| ![141018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141018.png) | 141018 |
| ![141019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141019.png) | 141019 |