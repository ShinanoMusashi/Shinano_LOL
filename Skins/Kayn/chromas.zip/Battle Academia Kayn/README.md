# Battle Academia Kayn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![141027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141027.png) | 141027 |
| ![141028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141028.png) | 141028 |
| ![141029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141029.png) | 141029 |
| ![141030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141030.png) | 141030 |