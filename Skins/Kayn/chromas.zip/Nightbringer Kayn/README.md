# Nightbringer Kayn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![141010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141010.png) | 141010 |
| ![141011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141011.png) | 141011 |
| ![141012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141012.png) | 141012 |
| ![141013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141013.png) | 141013 |
| ![141014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141014.png) | 141014 |