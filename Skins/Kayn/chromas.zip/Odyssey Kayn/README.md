# Odyssey Kayn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![141003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141003.png) | 141003 |
| ![141004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141004.png) | 141004 |
| ![141005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141005.png) | 141005 |
| ![141006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141006.png) | 141006 |
| ![141007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/141/141007.png) | 141007 |