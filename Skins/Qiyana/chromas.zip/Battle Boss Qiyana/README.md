# Battle Boss Qiyana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![246003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246003.png) | 246003 |
| ![246004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246004.png) | 246004 |
| ![246005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246005.png) | 246005 |
| ![246006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246006.png) | 246006 |
| ![246007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246007.png) | 246007 |
| ![246008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246008.png) | 246008 |
| ![246009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246009.png) | 246009 |