# Shockblade Qiyana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![246022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246022.png) | 246022 |
| ![246023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246023.png) | 246023 |
| ![246024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246024.png) | 246024 |
| ![246025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246025.png) | 246025 |
| ![246026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246026.png) | 246026 |
| ![246027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246027.png) | 246027 |
| ![246028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246028.png) | 246028 |
| ![246029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246029.png) | 246029 |