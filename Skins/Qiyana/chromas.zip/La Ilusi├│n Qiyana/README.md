# La Ilusi��n Qiyana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![246041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246041.png) | 246041 |
| ![246042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246042.png) | 246042 |
| ![246043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246043.png) | 246043 |
| ![246044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246044.png) | 246044 |
| ![246045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246045.png) | 246045 |
| ![246046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246046.png) | 246046 |
| ![246047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246047.png) | 246047 |
| ![246048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246048.png) | 246048 |
| ![246049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/246/246049.png) | 246049 |