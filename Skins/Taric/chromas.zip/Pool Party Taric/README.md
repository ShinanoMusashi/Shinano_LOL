# Pool Party Taric Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![44005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44005.png) | 44005 |
| ![44006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44006.png) | 44006 |
| ![44007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44007.png) | 44007 |
| ![44008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44008.png) | 44008 |