# Space Groove Taric Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![44019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44019.png) | 44019 |
| ![44020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44020.png) | 44020 |
| ![44021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44021.png) | 44021 |
| ![44022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44022.png) | 44022 |
| ![44023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44023.png) | 44023 |
| ![44024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44024.png) | 44024 |
| ![44025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44025.png) | 44025 |
| ![44026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44026.png) | 44026 |