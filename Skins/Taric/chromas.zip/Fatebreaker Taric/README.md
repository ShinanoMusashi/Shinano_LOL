# Fatebreaker Taric Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![44028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44028.png) | 44028 |
| ![44029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44029.png) | 44029 |
| ![44030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44030.png) | 44030 |
| ![44031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44031.png) | 44031 |
| ![44032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44032.png) | 44032 |
| ![44033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44033.png) | 44033 |
| ![44034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44034.png) | 44034 |
| ![44035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44035.png) | 44035 |