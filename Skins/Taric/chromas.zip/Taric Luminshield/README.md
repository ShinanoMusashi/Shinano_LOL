# Taric Luminshield Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![44010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44010.png) | 44010 |
| ![44011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44011.png) | 44011 |
| ![44012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44012.png) | 44012 |
| ![44013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44013.png) | 44013 |
| ![44014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44014.png) | 44014 |
| ![44015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44015.png) | 44015 |
| ![44016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44016.png) | 44016 |
| ![44017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/44/44017.png) | 44017 |