# Academy Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103057.png) | 103057 |