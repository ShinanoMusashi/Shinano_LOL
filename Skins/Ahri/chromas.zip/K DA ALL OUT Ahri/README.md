# K DA ALL OUT Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103034.png) | 103034 |
| ![103035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103035.png) | 103035 |
| ![103036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103036.png) | 103036 |
| ![103037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103037.png) | 103037 |
| ![103038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103038.png) | 103038 |
| ![103039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103039.png) | 103039 |
| ![103040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103040.png) | 103040 |
| ![103041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103041.png) | 103041 |
| ![103063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103063.png) | 103063 |