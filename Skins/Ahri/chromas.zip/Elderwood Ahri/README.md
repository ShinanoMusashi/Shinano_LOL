# Elderwood Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103019.png) | 103019 |
| ![103020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103020.png) | 103020 |
| ![103021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103021.png) | 103021 |
| ![103022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103022.png) | 103022 |
| ![103023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103023.png) | 103023 |
| ![103024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103024.png) | 103024 |
| ![103025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103025.png) | 103025 |
| ![103026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103026.png) | 103026 |
| ![103061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103061.png) | 103061 |