# Foxfire Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103054.png) | 103054 |
| ![103075](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103075.png) | 103075 |