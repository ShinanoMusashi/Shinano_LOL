# Popstar Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103008.png) | 103008 |
| ![103009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103009.png) | 103009 |
| ![103010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103010.png) | 103010 |
| ![103011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103011.png) | 103011 |
| ![103012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103012.png) | 103012 |
| ![103013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103013.png) | 103013 |
| ![103055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103055.png) | 103055 |