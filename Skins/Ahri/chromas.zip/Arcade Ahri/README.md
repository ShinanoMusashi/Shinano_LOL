# Arcade Ahri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![103058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/103/103058.png) | 103058 |