# Lunar Guardian Kha'Zix Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![121070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121070.png) | 121070 |
| ![121071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121071.png) | 121071 |
| ![121072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121072.png) | 121072 |
| ![121073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121073.png) | 121073 |
| ![121074](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121074.png) | 121074 |
| ![121075](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121075.png) | 121075 |
| ![121076](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121076.png) | 121076 |
| ![121077](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121077.png) | 121077 |
| ![121078](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121078.png) | 121078 |