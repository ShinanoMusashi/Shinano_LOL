# Odyssey Kha'Zix Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![121061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121061.png) | 121061 |
| ![121062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121062.png) | 121062 |
| ![121063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121063.png) | 121063 |
| ![121064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121064.png) | 121064 |
| ![121065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121065.png) | 121065 |
| ![121066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121066.png) | 121066 |
| ![121067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121067.png) | 121067 |
| ![121068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121068.png) | 121068 |