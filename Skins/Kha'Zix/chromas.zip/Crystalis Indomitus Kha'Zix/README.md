# Crystalis Indomitus Kha'Zix Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![121080](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121080.png) | 121080 |