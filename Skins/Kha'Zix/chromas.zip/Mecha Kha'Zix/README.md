# Mecha Kha'Zix Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![121005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121005.png) | 121005 |
| ![121006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121006.png) | 121006 |
| ![121007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121007.png) | 121007 |
| ![121008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121008.png) | 121008 |
| ![121009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121009.png) | 121009 |
| ![121010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/121/121010.png) | 121010 |