# Dark Star Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43011.png) | 43011 |
| ![43012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43012.png) | 43012 |
| ![43013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43013.png) | 43013 |
| ![43014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43014.png) | 43014 |
| ![43015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43015.png) | 43015 |
| ![43016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43016.png) | 43016 |
| ![43017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43017.png) | 43017 |
| ![43018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43018.png) | 43018 |