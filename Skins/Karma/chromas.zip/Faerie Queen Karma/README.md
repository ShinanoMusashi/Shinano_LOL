# Faerie Queen Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43055.png) | 43055 |
| ![43056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43056.png) | 43056 |
| ![43057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43057.png) | 43057 |
| ![43058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43058.png) | 43058 |
| ![43059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43059.png) | 43059 |
| ![43060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43060.png) | 43060 |