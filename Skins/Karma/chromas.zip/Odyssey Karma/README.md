# Odyssey Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43028.png) | 43028 |
| ![43029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43029.png) | 43029 |
| ![43030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43030.png) | 43030 |
| ![43031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43031.png) | 43031 |
| ![43032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43032.png) | 43032 |
| ![43033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43033.png) | 43033 |
| ![43034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43034.png) | 43034 |
| ![43035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43035.png) | 43035 |