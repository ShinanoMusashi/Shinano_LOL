# Ruined Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43036.png) | 43036 |
| ![43037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43037.png) | 43037 |
| ![43038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43038.png) | 43038 |
| ![43039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43039.png) | 43039 |
| ![43040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43040.png) | 43040 |
| ![43041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43041.png) | 43041 |
| ![43042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43042.png) | 43042 |
| ![43043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43043.png) | 43043 |