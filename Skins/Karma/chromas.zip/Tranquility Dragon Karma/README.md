# Tranquility Dragon Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43045.png) | 43045 |
| ![43046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43046.png) | 43046 |
| ![43047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43047.png) | 43047 |
| ![43048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43048.png) | 43048 |
| ![43049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43049.png) | 43049 |
| ![43050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43050.png) | 43050 |
| ![43051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43051.png) | 43051 |
| ![43052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43052.png) | 43052 |
| ![43053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43053.png) | 43053 |