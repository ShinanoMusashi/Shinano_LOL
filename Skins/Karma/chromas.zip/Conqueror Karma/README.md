# Conqueror Karma Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![43010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/43/43010.png) | 43010 |