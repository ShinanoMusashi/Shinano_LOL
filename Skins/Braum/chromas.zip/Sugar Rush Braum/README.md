# Sugar Rush Braum Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![201025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201025.png) | 201025 |
| ![201026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201026.png) | 201026 |
| ![201027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201027.png) | 201027 |
| ![201028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201028.png) | 201028 |
| ![201029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201029.png) | 201029 |
| ![201030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201030.png) | 201030 |
| ![201031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201031.png) | 201031 |
| ![201032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201032.png) | 201032 |