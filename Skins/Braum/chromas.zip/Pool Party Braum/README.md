# Pool Party Braum Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![201034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201034.png) | 201034 |
| ![201035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201035.png) | 201035 |
| ![201036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201036.png) | 201036 |
| ![201037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201037.png) | 201037 |
| ![201038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201038.png) | 201038 |
| ![201039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201039.png) | 201039 |
| ![201040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201040.png) | 201040 |
| ![201041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201041.png) | 201041 |