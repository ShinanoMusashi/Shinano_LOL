# Grill Master Braum Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![201043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201043.png) | 201043 |
| ![201044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201044.png) | 201044 |
| ![201045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201045.png) | 201045 |
| ![201046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201046.png) | 201046 |
| ![201047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201047.png) | 201047 |
| ![201048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201048.png) | 201048 |
| ![201049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201049.png) | 201049 |
| ![201050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/201/201050.png) | 201050 |