# Astronaut Corki Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![42027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42027.png) | 42027 |
| ![42028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42028.png) | 42028 |
| ![42029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42029.png) | 42029 |
| ![42030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42030.png) | 42030 |
| ![42031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42031.png) | 42031 |
| ![42032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42032.png) | 42032 |
| ![42033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42033.png) | 42033 |
| ![42034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42034.png) | 42034 |