# Dragonwing Corki Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![42017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42017.png) | 42017 |
| ![42035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42035.png) | 42035 |