# Arcade Corki Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![42009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42009.png) | 42009 |
| ![42010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42010.png) | 42010 |
| ![42011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42011.png) | 42011 |
| ![42012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42012.png) | 42012 |
| ![42013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42013.png) | 42013 |
| ![42014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42014.png) | 42014 |
| ![42015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42015.png) | 42015 |
| ![42016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42016.png) | 42016 |