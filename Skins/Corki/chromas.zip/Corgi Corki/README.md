# Corgi Corki Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![42019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42019.png) | 42019 |
| ![42020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42020.png) | 42020 |
| ![42021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42021.png) | 42021 |
| ![42022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42022.png) | 42022 |
| ![42023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42023.png) | 42023 |
| ![42024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42024.png) | 42024 |
| ![42025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/42/42025.png) | 42025 |