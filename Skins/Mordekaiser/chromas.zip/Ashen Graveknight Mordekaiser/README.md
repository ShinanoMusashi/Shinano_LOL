# Ashen Graveknight Mordekaiser Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![82043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82043.png) | 82043 |