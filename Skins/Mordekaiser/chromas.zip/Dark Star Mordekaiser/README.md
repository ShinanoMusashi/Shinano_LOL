# Dark Star Mordekaiser Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![82007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82007.png) | 82007 |
| ![82008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82008.png) | 82008 |
| ![82009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82009.png) | 82009 |
| ![82010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82010.png) | 82010 |
| ![82011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82011.png) | 82011 |
| ![82012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82012.png) | 82012 |