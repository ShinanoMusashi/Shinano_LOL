# Pentakill III Lost Chapter Mordekaiser Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![82024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82024.png) | 82024 |
| ![82025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82025.png) | 82025 |
| ![82026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82026.png) | 82026 |
| ![82027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82027.png) | 82027 |
| ![82028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82028.png) | 82028 |
| ![82029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82029.png) | 82029 |
| ![82030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82030.png) | 82030 |
| ![82031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82031.png) | 82031 |