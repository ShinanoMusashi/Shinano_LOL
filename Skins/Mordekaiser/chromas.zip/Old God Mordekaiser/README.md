# Old God Mordekaiser Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![82045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82045.png) | 82045 |
| ![82046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82046.png) | 82046 |
| ![82047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82047.png) | 82047 |
| ![82048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82048.png) | 82048 |
| ![82049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82049.png) | 82049 |
| ![82050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82050.png) | 82050 |
| ![82051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82051.png) | 82051 |
| ![82052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82052.png) | 82052 |
| ![82053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/82/82053.png) | 82053 |