# Cosmic Invoker Illaoi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![420011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420011.png) | 420011 |
| ![420012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420012.png) | 420012 |
| ![420013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420013.png) | 420013 |
| ![420014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420014.png) | 420014 |
| ![420015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420015.png) | 420015 |
| ![420016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420016.png) | 420016 |
| ![420017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420017.png) | 420017 |