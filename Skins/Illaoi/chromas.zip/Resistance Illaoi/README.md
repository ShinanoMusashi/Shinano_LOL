# Resistance Illaoi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![420003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420003.png) | 420003 |
| ![420004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420004.png) | 420004 |
| ![420005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420005.png) | 420005 |
| ![420006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420006.png) | 420006 |
| ![420007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420007.png) | 420007 |
| ![420008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420008.png) | 420008 |
| ![420009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420009.png) | 420009 |