# Battle Bear Illaoi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![420028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420028.png) | 420028 |
| ![420029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420029.png) | 420029 |
| ![420030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420030.png) | 420030 |
| ![420031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420031.png) | 420031 |
| ![420032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420032.png) | 420032 |
| ![420033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420033.png) | 420033 |
| ![420034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420034.png) | 420034 |
| ![420035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420035.png) | 420035 |
| ![420036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420036.png) | 420036 |