# Snow Moon Illaoi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![420019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420019.png) | 420019 |
| ![420020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420020.png) | 420020 |
| ![420021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420021.png) | 420021 |
| ![420022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420022.png) | 420022 |
| ![420023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420023.png) | 420023 |
| ![420024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420024.png) | 420024 |
| ![420025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420025.png) | 420025 |
| ![420026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/420/420026.png) | 420026 |