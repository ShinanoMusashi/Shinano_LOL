# Rain Shepherd Fizz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![105036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105036.png) | 105036 |
| ![105037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105037.png) | 105037 |
| ![105038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105038.png) | 105038 |
| ![105039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105039.png) | 105039 |
| ![105040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105040.png) | 105040 |
| ![105041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105041.png) | 105041 |
| ![105042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105042.png) | 105042 |
| ![105043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105043.png) | 105043 |