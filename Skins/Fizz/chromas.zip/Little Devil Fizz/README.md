# Little Devil Fizz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![105017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105017.png) | 105017 |
| ![105018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105018.png) | 105018 |
| ![105019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105019.png) | 105019 |
| ![105020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105020.png) | 105020 |
| ![105021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105021.png) | 105021 |
| ![105022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105022.png) | 105022 |
| ![105023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105023.png) | 105023 |
| ![105024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105024.png) | 105024 |