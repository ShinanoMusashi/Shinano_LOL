# Omega Squad Fizz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![105011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105011.png) | 105011 |
| ![105012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105012.png) | 105012 |
| ![105013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105013.png) | 105013 |