# Fizz Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![105005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105005.png) | 105005 |
| ![105006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105006.png) | 105006 |
| ![105007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/105/105007.png) | 105007 |