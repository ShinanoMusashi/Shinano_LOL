# Cafe Cuties Rumble Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![68024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68024.png) | 68024 |
| ![68025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68025.png) | 68025 |
| ![68026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68026.png) | 68026 |
| ![68027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68027.png) | 68027 |
| ![68028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68028.png) | 68028 |
| ![68029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68029.png) | 68029 |
| ![68030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68030.png) | 68030 |
| ![68031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68031.png) | 68031 |