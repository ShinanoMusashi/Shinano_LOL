# Space Groove Rumble Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![68014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68014.png) | 68014 |
| ![68015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68015.png) | 68015 |
| ![68016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68016.png) | 68016 |
| ![68017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68017.png) | 68017 |
| ![68018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68018.png) | 68018 |
| ![68019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68019.png) | 68019 |
| ![68020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68020.png) | 68020 |
| ![68021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68021.png) | 68021 |
| ![68022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68022.png) | 68022 |