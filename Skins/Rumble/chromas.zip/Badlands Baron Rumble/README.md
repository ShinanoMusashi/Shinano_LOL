# Badlands Baron Rumble Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![68005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68005.png) | 68005 |
| ![68006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68006.png) | 68006 |
| ![68007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68007.png) | 68007 |
| ![68008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68008.png) | 68008 |
| ![68009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68009.png) | 68009 |
| ![68010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68010.png) | 68010 |
| ![68011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68011.png) | 68011 |
| ![68012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/68/68012.png) | 68012 |