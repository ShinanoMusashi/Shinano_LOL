# Headhunter Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84010.png) | 84010 |
| ![84011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84011.png) | 84011 |
| ![84012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84012.png) | 84012 |