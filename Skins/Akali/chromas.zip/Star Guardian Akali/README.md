# Star Guardian Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84062.png) | 84062 |
| ![84063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84063.png) | 84063 |
| ![84064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84064.png) | 84064 |
| ![84065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84065.png) | 84065 |
| ![84066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84066.png) | 84066 |
| ![84067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84067.png) | 84067 |