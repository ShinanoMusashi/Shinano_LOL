# DRX Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84069.png) | 84069 |