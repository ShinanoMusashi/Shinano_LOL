# Crime City Nightmare Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84051.png) | 84051 |
| ![84052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84052.png) | 84052 |
| ![84053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84053.png) | 84053 |
| ![84054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84054.png) | 84054 |
| ![84055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84055.png) | 84055 |
| ![84056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84056.png) | 84056 |
| ![84057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84057.png) | 84057 |
| ![84058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84058.png) | 84058 |
| ![84059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84059.png) | 84059 |