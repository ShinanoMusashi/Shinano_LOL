# Nurse Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84033.png) | 84033 |
| ![84034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84034.png) | 84034 |
| ![84035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84035.png) | 84035 |
| ![84036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84036.png) | 84036 |
| ![84037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84037.png) | 84037 |
| ![84038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84038.png) | 84038 |
| ![84039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84039.png) | 84039 |
| ![84040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84040.png) | 84040 |