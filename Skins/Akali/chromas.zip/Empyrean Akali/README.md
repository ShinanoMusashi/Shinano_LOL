# Empyrean Akali Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![84083](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84083.png) | 84083 |
| ![84084](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84084.png) | 84084 |
| ![84085](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84085.png) | 84085 |
| ![84086](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84086.png) | 84086 |
| ![84087](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84087.png) | 84087 |
| ![84088](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84088.png) | 84088 |
| ![84089](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84089.png) | 84089 |
| ![84090](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84090.png) | 84090 |
| ![84091](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/84/84091.png) | 84091 |