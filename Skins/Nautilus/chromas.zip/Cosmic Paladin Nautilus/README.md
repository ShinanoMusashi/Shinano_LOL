# Cosmic Paladin Nautilus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![111028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111028.png) | 111028 |
| ![111029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111029.png) | 111029 |
| ![111030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111030.png) | 111030 |
| ![111031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111031.png) | 111031 |
| ![111032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111032.png) | 111032 |
| ![111033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111033.png) | 111033 |
| ![111034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111034.png) | 111034 |
| ![111035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111035.png) | 111035 |