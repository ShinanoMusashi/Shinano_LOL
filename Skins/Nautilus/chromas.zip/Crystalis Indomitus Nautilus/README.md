# Crystalis Indomitus Nautilus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![111037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111037.png) | 111037 |