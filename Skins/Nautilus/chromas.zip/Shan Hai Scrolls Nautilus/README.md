# Shan Hai Scrolls Nautilus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![111010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111010.png) | 111010 |
| ![111011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111011.png) | 111011 |
| ![111012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111012.png) | 111012 |
| ![111013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111013.png) | 111013 |
| ![111014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111014.png) | 111014 |
| ![111015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111015.png) | 111015 |
| ![111016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111016.png) | 111016 |
| ![111017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/111/111017.png) | 111017 |