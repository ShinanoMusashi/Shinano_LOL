# Music Fan Gragas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![79040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79040.png) | 79040 |
| ![79041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79041.png) | 79041 |
| ![79042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79042.png) | 79042 |
| ![79043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79043.png) | 79043 |
| ![79044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79044.png) | 79044 |
| ![79045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79045.png) | 79045 |
| ![79046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79046.png) | 79046 |
| ![79047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79047.png) | 79047 |