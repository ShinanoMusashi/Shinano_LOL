# Warden Gragas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![79012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79012.png) | 79012 |
| ![79013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79013.png) | 79013 |
| ![79014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79014.png) | 79014 |
| ![79015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79015.png) | 79015 |
| ![79016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79016.png) | 79016 |
| ![79017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79017.png) | 79017 |
| ![79018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79018.png) | 79018 |
| ![79019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79019.png) | 79019 |