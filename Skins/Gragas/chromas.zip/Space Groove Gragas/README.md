# Space Groove Gragas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![79021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79021.png) | 79021 |
| ![79022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79022.png) | 79022 |
| ![79023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79023.png) | 79023 |
| ![79024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79024.png) | 79024 |
| ![79025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79025.png) | 79025 |
| ![79026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79026.png) | 79026 |
| ![79027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79027.png) | 79027 |
| ![79028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79028.png) | 79028 |