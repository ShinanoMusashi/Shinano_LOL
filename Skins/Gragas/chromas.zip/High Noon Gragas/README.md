# High Noon Gragas Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![79030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79030.png) | 79030 |
| ![79031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79031.png) | 79031 |
| ![79032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79032.png) | 79032 |
| ![79033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79033.png) | 79033 |
| ![79034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79034.png) | 79034 |
| ![79035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79035.png) | 79035 |
| ![79036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79036.png) | 79036 |
| ![79037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79037.png) | 79037 |
| ![79038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/79/79038.png) | 79038 |