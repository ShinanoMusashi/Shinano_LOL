# Battle Bunny Prime Riven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![92046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92046.png) | 92046 |
| ![92047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92047.png) | 92047 |
| ![92048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92048.png) | 92048 |
| ![92049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92049.png) | 92049 |
| ![92050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92050.png) | 92050 |
| ![92051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92051.png) | 92051 |
| ![92052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92052.png) | 92052 |
| ![92053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92053.png) | 92053 |
| ![92054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92054.png) | 92054 |
| ![92072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92072.png) | 92072 |