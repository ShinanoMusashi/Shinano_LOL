# Sentinel Riven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![92035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92035.png) | 92035 |
| ![92036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92036.png) | 92036 |
| ![92037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92037.png) | 92037 |
| ![92038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92038.png) | 92038 |
| ![92039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92039.png) | 92039 |
| ![92040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92040.png) | 92040 |
| ![92041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92041.png) | 92041 |
| ![92042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92042.png) | 92042 |
| ![92043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92043.png) | 92043 |