# Dragonblade Riven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![92017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92017.png) | 92017 |