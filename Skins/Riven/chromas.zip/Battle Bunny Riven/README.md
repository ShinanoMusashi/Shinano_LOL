# Battle Bunny Riven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![92008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92008.png) | 92008 |
| ![92009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92009.png) | 92009 |
| ![92010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92010.png) | 92010 |
| ![92011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92011.png) | 92011 |
| ![92012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92012.png) | 92012 |
| ![92013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92013.png) | 92013 |
| ![92014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92014.png) | 92014 |
| ![92015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92015.png) | 92015 |