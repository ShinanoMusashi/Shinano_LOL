# Primal Ambush Riven Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![92064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92064.png) | 92064 |
| ![92065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92065.png) | 92065 |
| ![92066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92066.png) | 92066 |
| ![92067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92067.png) | 92067 |
| ![92068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92068.png) | 92068 |
| ![92069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92069.png) | 92069 |
| ![92070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92070.png) | 92070 |
| ![92071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/92/92071.png) | 92071 |