# Eternal Dragon Brand Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![63013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63013.png) | 63013 |
| ![63014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63014.png) | 63014 |
| ![63015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63015.png) | 63015 |
| ![63016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63016.png) | 63016 |
| ![63017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63017.png) | 63017 |
| ![63018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63018.png) | 63018 |
| ![63019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63019.png) | 63019 |
| ![63020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63020.png) | 63020 |
| ![63023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/63/63023.png) | 63023 |