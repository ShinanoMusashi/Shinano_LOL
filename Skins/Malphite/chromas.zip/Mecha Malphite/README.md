# Mecha Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54008.png) | 54008 |
| ![54009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54009.png) | 54009 |
| ![54010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54010.png) | 54010 |
| ![54011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54011.png) | 54011 |
| ![54012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54012.png) | 54012 |
| ![54013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54013.png) | 54013 |
| ![54014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54014.png) | 54014 |
| ![54015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54015.png) | 54015 |