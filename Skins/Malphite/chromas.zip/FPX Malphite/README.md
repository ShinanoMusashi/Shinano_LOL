# FPX Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54026.png) | 54026 |
| ![54047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54047.png) | 54047 |