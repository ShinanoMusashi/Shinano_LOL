# Old God Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54028.png) | 54028 |
| ![54029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54029.png) | 54029 |
| ![54030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54030.png) | 54030 |
| ![54031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54031.png) | 54031 |
| ![54032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54032.png) | 54032 |
| ![54033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54033.png) | 54033 |
| ![54034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54034.png) | 54034 |
| ![54035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54035.png) | 54035 |
| ![54036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54036.png) | 54036 |