# Lunar Guardian Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54038.png) | 54038 |
| ![54039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54039.png) | 54039 |
| ![54040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54040.png) | 54040 |
| ![54041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54041.png) | 54041 |
| ![54042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54042.png) | 54042 |
| ![54043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54043.png) | 54043 |
| ![54044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54044.png) | 54044 |
| ![54045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54045.png) | 54045 |
| ![54046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54046.png) | 54046 |