# Pool Party Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54049.png) | 54049 |
| ![54050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54050.png) | 54050 |
| ![54051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54051.png) | 54051 |
| ![54052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54052.png) | 54052 |
| ![54053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54053.png) | 54053 |
| ![54054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54054.png) | 54054 |
| ![54055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54055.png) | 54055 |
| ![54056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54056.png) | 54056 |