# Odyssey Malphite Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![54017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54017.png) | 54017 |
| ![54018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54018.png) | 54018 |
| ![54019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54019.png) | 54019 |
| ![54020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54020.png) | 54020 |
| ![54021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54021.png) | 54021 |
| ![54022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/54/54022.png) | 54022 |