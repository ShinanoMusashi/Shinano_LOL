# Blackfrost Renekton Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![58019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58019.png) | 58019 |
| ![58020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58020.png) | 58020 |
| ![58021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58021.png) | 58021 |
| ![58022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58022.png) | 58022 |
| ![58023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58023.png) | 58023 |
| ![58024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58024.png) | 58024 |
| ![58025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58025.png) | 58025 |