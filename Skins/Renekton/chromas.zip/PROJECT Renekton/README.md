# PROJECT Renekton Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![58027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58027.png) | 58027 |
| ![58028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58028.png) | 58028 |
| ![58029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58029.png) | 58029 |
| ![58030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58030.png) | 58030 |
| ![58031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58031.png) | 58031 |
| ![58032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58032.png) | 58032 |