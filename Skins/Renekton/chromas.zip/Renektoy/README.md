# Renektoy Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![58010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58010.png) | 58010 |
| ![58011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58011.png) | 58011 |
| ![58012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58012.png) | 58012 |
| ![58013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58013.png) | 58013 |
| ![58014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58014.png) | 58014 |
| ![58015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58015.png) | 58015 |
| ![58016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58016.png) | 58016 |