# Dawnbringer Renekton Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![58034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58034.png) | 58034 |
| ![58035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58035.png) | 58035 |
| ![58036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58036.png) | 58036 |
| ![58037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58037.png) | 58037 |
| ![58038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58038.png) | 58038 |
| ![58039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58039.png) | 58039 |
| ![58040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58040.png) | 58040 |
| ![58041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58041.png) | 58041 |