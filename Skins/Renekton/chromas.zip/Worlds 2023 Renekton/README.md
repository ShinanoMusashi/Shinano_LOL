# Worlds 2023 Renekton Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![58043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58043.png) | 58043 |
| ![58044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58044.png) | 58044 |
| ![58045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58045.png) | 58045 |
| ![58046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58046.png) | 58046 |
| ![58047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/58/58047.png) | 58047 |