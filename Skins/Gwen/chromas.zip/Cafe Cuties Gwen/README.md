# Cafe Cuties Gwen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![887012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887012.png) | 887012 |
| ![887013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887013.png) | 887013 |
| ![887014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887014.png) | 887014 |
| ![887015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887015.png) | 887015 |
| ![887016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887016.png) | 887016 |
| ![887017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887017.png) | 887017 |
| ![887018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887018.png) | 887018 |
| ![887019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/887/887019.png) | 887019 |