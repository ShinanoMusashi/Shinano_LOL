# Sentinel Diana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![131028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131028.png) | 131028 |
| ![131029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131029.png) | 131029 |
| ![131030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131030.png) | 131030 |
| ![131031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131031.png) | 131031 |
| ![131032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131032.png) | 131032 |
| ![131033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131033.png) | 131033 |
| ![131034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131034.png) | 131034 |
| ![131035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131035.png) | 131035 |
| ![131036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131036.png) | 131036 |