# Heavenscale Diana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![131055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131055.png) | 131055 |
| ![131056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131056.png) | 131056 |
| ![131057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131057.png) | 131057 |
| ![131058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131058.png) | 131058 |
| ![131059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131059.png) | 131059 |
| ![131060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131060.png) | 131060 |
| ![131061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131061.png) | 131061 |
| ![131062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131062.png) | 131062 |
| ![131063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131063.png) | 131063 |