# Lunar Goddess Diana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![131004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131004.png) | 131004 |
| ![131005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131005.png) | 131005 |
| ![131006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131006.png) | 131006 |
| ![131007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131007.png) | 131007 |
| ![131008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131008.png) | 131008 |
| ![131009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131009.png) | 131009 |
| ![131010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131010.png) | 131010 |