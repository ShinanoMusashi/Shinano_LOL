# Dragonslayer Diana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![131019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131019.png) | 131019 |
| ![131020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131020.png) | 131020 |
| ![131021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131021.png) | 131021 |
| ![131022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131022.png) | 131022 |
| ![131023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131023.png) | 131023 |
| ![131024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131024.png) | 131024 |