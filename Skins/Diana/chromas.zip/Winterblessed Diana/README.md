# Winterblessed Diana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![131048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131048.png) | 131048 |
| ![131049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131049.png) | 131049 |
| ![131050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131050.png) | 131050 |
| ![131051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131051.png) | 131051 |
| ![131052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131052.png) | 131052 |
| ![131053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/131/131053.png) | 131053 |