# PsyOps Viktor Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112006.png' alt='Chroma 112006' width='100'> | Chroma 112006 | 112006 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112007.png' alt='Chroma 112007' width='100'> | Chroma 112007 | 112007 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112008.png' alt='Chroma 112008' width='100'> | Chroma 112008 | 112008 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112009.png' alt='Chroma 112009' width='100'> | Chroma 112009 | 112009 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112010.png' alt='Chroma 112010' width='100'> | Chroma 112010 | 112010 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112011.png' alt='Chroma 112011' width='100'> | Chroma 112011 | 112011 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112012.png' alt='Chroma 112012' width='100'> | Chroma 112012 | 112012 |
| 08 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112013.png' alt='Chroma 112013' width='100'> | Chroma 112013 | 112013 |
