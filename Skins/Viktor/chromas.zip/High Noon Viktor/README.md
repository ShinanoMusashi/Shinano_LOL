# High Noon Viktor Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112015.png' alt='Chroma 112015' width='100'> | Chroma 112015 | 112015 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112016.png' alt='Chroma 112016' width='100'> | Chroma 112016 | 112016 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112017.png' alt='Chroma 112017' width='100'> | Chroma 112017 | 112017 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112018.png' alt='Chroma 112018' width='100'> | Chroma 112018 | 112018 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112019.png' alt='Chroma 112019' width='100'> | Chroma 112019 | 112019 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112020.png' alt='Chroma 112020' width='100'> | Chroma 112020 | 112020 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112021.png' alt='Chroma 112021' width='100'> | Chroma 112021 | 112021 |
| 08 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112022.png' alt='Chroma 112022' width='100'> | Chroma 112022 | 112022 |
| 09 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/112/112023.png' alt='Chroma 112023' width='100'> | Chroma 112023 | 112023 |
