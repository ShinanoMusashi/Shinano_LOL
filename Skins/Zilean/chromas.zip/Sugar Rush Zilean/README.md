# Sugar Rush Zilean Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![26007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26007.png) | 26007 |
| ![26008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26008.png) | 26008 |
| ![26009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26009.png) | 26009 |
| ![26010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26010.png) | 26010 |
| ![26011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26011.png) | 26011 |
| ![26012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26012.png) | 26012 |
| ![26013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/26/26013.png) | 26013 |