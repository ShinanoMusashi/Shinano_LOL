# Space Groove Teemo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![17048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17048.png) | 17048 |
| ![17049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17049.png) | 17049 |
| ![17050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17050.png) | 17050 |
| ![17051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17051.png) | 17051 |
| ![17052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17052.png) | 17052 |
| ![17053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17053.png) | 17053 |