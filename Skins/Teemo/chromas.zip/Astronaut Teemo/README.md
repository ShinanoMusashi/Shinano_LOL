# Astronaut Teemo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![17026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17026.png) | 17026 |