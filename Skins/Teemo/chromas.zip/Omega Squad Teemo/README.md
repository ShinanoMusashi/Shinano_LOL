# Omega Squad Teemo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![17015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17015.png) | 17015 |
| ![17016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17016.png) | 17016 |
| ![17017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17017.png) | 17017 |