# Firecracker Teemo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![17038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17038.png) | 17038 |
| ![17039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17039.png) | 17039 |
| ![17040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17040.png) | 17040 |
| ![17041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17041.png) | 17041 |
| ![17042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17042.png) | 17042 |
| ![17043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17043.png) | 17043 |
| ![17044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17044.png) | 17044 |
| ![17045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17045.png) | 17045 |
| ![17046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17046.png) | 17046 |