# Little Devil Teemo Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![17028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17028.png) | 17028 |
| ![17029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17029.png) | 17029 |
| ![17030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17030.png) | 17030 |
| ![17031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17031.png) | 17031 |
| ![17032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17032.png) | 17032 |
| ![17033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17033.png) | 17033 |
| ![17034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17034.png) | 17034 |
| ![17035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17035.png) | 17035 |
| ![17036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/17/17036.png) | 17036 |