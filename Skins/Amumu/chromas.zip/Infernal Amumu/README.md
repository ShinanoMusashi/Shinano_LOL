# Infernal Amumu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![32018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32018.png) | 32018 |
| ![32019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32019.png) | 32019 |
| ![32020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32020.png) | 32020 |
| ![32021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32021.png) | 32021 |
| ![32022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32022.png) | 32022 |