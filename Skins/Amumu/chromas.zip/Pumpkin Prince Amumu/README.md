# Pumpkin Prince Amumu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![32025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32025.png) | 32025 |
| ![32026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32026.png) | 32026 |
| ![32027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32027.png) | 32027 |
| ![32028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32028.png) | 32028 |
| ![32029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32029.png) | 32029 |
| ![32030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32030.png) | 32030 |
| ![32031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32031.png) | 32031 |
| ![32032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32032.png) | 32032 |
| ![32033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32033.png) | 32033 |