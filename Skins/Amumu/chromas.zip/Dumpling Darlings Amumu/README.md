# Dumpling Darlings Amumu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![32054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32054.png) | 32054 |
| ![32055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32055.png) | 32055 |
| ![32056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32056.png) | 32056 |
| ![32057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32057.png) | 32057 |
| ![32058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32058.png) | 32058 |
| ![32059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32059.png) | 32059 |
| ![32060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32060.png) | 32060 |
| ![32061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32061.png) | 32061 |