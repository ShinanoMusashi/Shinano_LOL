# Porcelain Amumu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![32035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32035.png) | 32035 |
| ![32036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32036.png) | 32036 |
| ![32037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32037.png) | 32037 |
| ![32038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32038.png) | 32038 |
| ![32039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32039.png) | 32039 |
| ![32040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32040.png) | 32040 |
| ![32041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32041.png) | 32041 |
| ![32042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32042.png) | 32042 |
| ![32043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32043.png) | 32043 |