# Surprise Party Amumu Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![32009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32009.png) | 32009 |
| ![32010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32010.png) | 32010 |
| ![32011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32011.png) | 32011 |
| ![32012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32012.png) | 32012 |
| ![32013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32013.png) | 32013 |
| ![32014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32014.png) | 32014 |
| ![32015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32015.png) | 32015 |
| ![32016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/32/32016.png) | 32016 |