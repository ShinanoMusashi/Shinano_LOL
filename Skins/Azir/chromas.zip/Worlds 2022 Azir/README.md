# Worlds 2022 Azir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![268015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268015.png) | 268015 |
| ![268016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268016.png) | 268016 |
| ![268017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268017.png) | 268017 |
| ![268018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268018.png) | 268018 |