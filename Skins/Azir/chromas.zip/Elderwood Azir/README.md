# Elderwood Azir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![268006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268006.png) | 268006 |
| ![268007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268007.png) | 268007 |
| ![268008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268008.png) | 268008 |
| ![268009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268009.png) | 268009 |
| ![268010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268010.png) | 268010 |
| ![268011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268011.png) | 268011 |
| ![268012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268012.png) | 268012 |
| ![268013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268013.png) | 268013 |