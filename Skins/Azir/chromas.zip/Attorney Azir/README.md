# Attorney Azir Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![268020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268020.png) | 268020 |
| ![268021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268021.png) | 268021 |
| ![268022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268022.png) | 268022 |
| ![268023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268023.png) | 268023 |
| ![268024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268024.png) | 268024 |
| ![268025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268025.png) | 268025 |
| ![268026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268026.png) | 268026 |
| ![268027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/268/268027.png) | 268027 |