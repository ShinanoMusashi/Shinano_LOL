# Broken Covenant Xayah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![498039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498039.png) | 498039 |
| ![498040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498040.png) | 498040 |
| ![498041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498041.png) | 498041 |
| ![498042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498042.png) | 498042 |
| ![498043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498043.png) | 498043 |
| ![498044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498044.png) | 498044 |
| ![498045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498045.png) | 498045 |
| ![498046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498046.png) | 498046 |