# Star Guardian Xayah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![498005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498005.png) | 498005 |
| ![498006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498006.png) | 498006 |
| ![498007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498007.png) | 498007 |