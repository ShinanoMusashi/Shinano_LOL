# Battle Bat Xayah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![498048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498048.png) | 498048 |
| ![498049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498049.png) | 498049 |
| ![498050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498050.png) | 498050 |
| ![498051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498051.png) | 498051 |
| ![498052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498052.png) | 498052 |
| ![498053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498053.png) | 498053 |
| ![498054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498054.png) | 498054 |
| ![498055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498055.png) | 498055 |
| ![498056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498056.png) | 498056 |