# Elderwood Xayah Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![498009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498009.png) | 498009 |
| ![498010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498010.png) | 498010 |
| ![498011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498011.png) | 498011 |
| ![498012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498012.png) | 498012 |
| ![498013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498013.png) | 498013 |
| ![498014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498014.png) | 498014 |
| ![498015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498015.png) | 498015 |
| ![498016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/498/498016.png) | 498016 |