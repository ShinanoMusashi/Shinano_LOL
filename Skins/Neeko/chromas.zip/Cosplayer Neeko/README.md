# Cosplayer Neeko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![518041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518041.png) | 518041 |
| ![518042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518042.png) | 518042 |
| ![518043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518043.png) | 518043 |
| ![518044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518044.png) | 518044 |
| ![518045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518045.png) | 518045 |
| ![518046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518046.png) | 518046 |
| ![518047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518047.png) | 518047 |
| ![518048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518048.png) | 518048 |