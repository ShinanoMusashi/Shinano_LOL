# Winter Wonder Neeko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![518002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518002.png) | 518002 |
| ![518003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518003.png) | 518003 |
| ![518004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518004.png) | 518004 |
| ![518005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518005.png) | 518005 |
| ![518006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518006.png) | 518006 |
| ![518007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518007.png) | 518007 |
| ![518008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518008.png) | 518008 |
| ![518009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518009.png) | 518009 |