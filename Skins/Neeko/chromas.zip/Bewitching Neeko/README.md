# Bewitching Neeko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![518023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518023.png) | 518023 |
| ![518024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518024.png) | 518024 |
| ![518025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518025.png) | 518025 |
| ![518026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518026.png) | 518026 |
| ![518027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518027.png) | 518027 |
| ![518028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518028.png) | 518028 |
| ![518029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518029.png) | 518029 |
| ![518030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/518/518030.png) | 518030 |