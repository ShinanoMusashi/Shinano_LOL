# True Damage Ekko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![245020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245020.png) | 245020 |
| ![245021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245021.png) | 245021 |
| ![245022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245022.png) | 245022 |
| ![245023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245023.png) | 245023 |
| ![245024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245024.png) | 245024 |
| ![245025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245025.png) | 245025 |
| ![245026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245026.png) | 245026 |
| ![245027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245027.png) | 245027 |