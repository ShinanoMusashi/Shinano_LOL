# Sandstorm Ekko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![245004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245004.png) | 245004 |
| ![245005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245005.png) | 245005 |
| ![245006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245006.png) | 245006 |
| ![245007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245007.png) | 245007 |
| ![245008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245008.png) | 245008 |
| ![245009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245009.png) | 245009 |
| ![245010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245010.png) | 245010 |