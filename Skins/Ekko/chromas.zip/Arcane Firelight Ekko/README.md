# Arcane Firelight Ekko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![245037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245037.png) | 245037 |
| ![245038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245038.png) | 245038 |
| ![245039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245039.png) | 245039 |
| ![245040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245040.png) | 245040 |
| ![245041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245041.png) | 245041 |
| ![245042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245042.png) | 245042 |
| ![245043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245043.png) | 245043 |
| ![245044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245044.png) | 245044 |