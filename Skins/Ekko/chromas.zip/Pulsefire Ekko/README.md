# Pulsefire Ekko Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![245029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245029.png) | 245029 |
| ![245030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245030.png) | 245030 |
| ![245031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245031.png) | 245031 |
| ![245032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245032.png) | 245032 |
| ![245033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245033.png) | 245033 |
| ![245034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245034.png) | 245034 |
| ![245035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/245/245035.png) | 245035 |