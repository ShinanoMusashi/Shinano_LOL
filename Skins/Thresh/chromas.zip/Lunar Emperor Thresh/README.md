# Lunar Emperor Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412040.png) | 412040 |
| ![412041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412041.png) | 412041 |
| ![412042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412042.png) | 412042 |
| ![412043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412043.png) | 412043 |
| ![412044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412044.png) | 412044 |
| ![412045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412045.png) | 412045 |
| ![412046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412046.png) | 412046 |
| ![412047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412047.png) | 412047 |
| ![412048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412048.png) | 412048 |