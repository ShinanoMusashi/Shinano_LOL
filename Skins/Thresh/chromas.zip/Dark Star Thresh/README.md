# Dark Star Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412016.png) | 412016 |