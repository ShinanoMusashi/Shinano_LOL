# Worlds 2013 Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412012.png) | 412012 |