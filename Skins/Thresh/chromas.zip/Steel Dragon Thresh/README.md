# Steel Dragon Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412029.png) | 412029 |
| ![412030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412030.png) | 412030 |
| ![412031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412031.png) | 412031 |
| ![412032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412032.png) | 412032 |
| ![412033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412033.png) | 412033 |
| ![412034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412034.png) | 412034 |
| ![412035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412035.png) | 412035 |
| ![412036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412036.png) | 412036 |
| ![412037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412037.png) | 412037 |