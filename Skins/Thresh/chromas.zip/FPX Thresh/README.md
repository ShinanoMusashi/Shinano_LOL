# FPX Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412018.png) | 412018 |