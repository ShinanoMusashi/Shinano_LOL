# Winterblessed Thresh Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![412050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412050.png) | 412050 |
| ![412051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412051.png) | 412051 |
| ![412052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412052.png) | 412052 |
| ![412053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412053.png) | 412053 |
| ![412054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412054.png) | 412054 |
| ![412055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412055.png) | 412055 |
| ![412056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412056.png) | 412056 |
| ![412057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412057.png) | 412057 |
| ![412058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/412/412058.png) | 412058 |