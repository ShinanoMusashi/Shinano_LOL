# True Damage Senna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![235002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235002.png) | 235002 |
| ![235003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235003.png) | 235003 |
| ![235004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235004.png) | 235004 |
| ![235005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235005.png) | 235005 |
| ![235006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235006.png) | 235006 |
| ![235007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235007.png) | 235007 |
| ![235008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235008.png) | 235008 |