# Star Guardian Senna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![235048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235048.png) | 235048 |
| ![235049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235049.png) | 235049 |
| ![235050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235050.png) | 235050 |
| ![235051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235051.png) | 235051 |
| ![235052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235052.png) | 235052 |
| ![235053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235053.png) | 235053 |
| ![235054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235054.png) | 235054 |
| ![235055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235055.png) | 235055 |