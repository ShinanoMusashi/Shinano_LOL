# High Noon Senna Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![235011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235011.png) | 235011 |
| ![235012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235012.png) | 235012 |
| ![235013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235013.png) | 235013 |
| ![235014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235014.png) | 235014 |
| ![235015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235015.png) | 235015 |
| ![235037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/235/235037.png) | 235037 |