# Choo-Choo Ornn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![516021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516021.png) | 516021 |
| ![516022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516022.png) | 516022 |
| ![516023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516023.png) | 516023 |
| ![516024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516024.png) | 516024 |
| ![516025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516025.png) | 516025 |
| ![516026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516026.png) | 516026 |
| ![516027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516027.png) | 516027 |
| ![516028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516028.png) | 516028 |