# Elderwood Ornn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![516003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516003.png) | 516003 |
| ![516004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516004.png) | 516004 |
| ![516005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516005.png) | 516005 |
| ![516006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516006.png) | 516006 |
| ![516007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516007.png) | 516007 |
| ![516008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516008.png) | 516008 |
| ![516009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516009.png) | 516009 |
| ![516010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/516/516010.png) | 516010 |