# Chosen of the Wolf Swain Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![50034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50034.png) | 50034 |
| ![50035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50035.png) | 50035 |
| ![50036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50036.png) | 50036 |
| ![50037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50037.png) | 50037 |
| ![50038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50038.png) | 50038 |
| ![50039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50039.png) | 50039 |
| ![50040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50040.png) | 50040 |
| ![50041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50041.png) | 50041 |