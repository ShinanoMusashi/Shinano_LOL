# Winterblessed Swain Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![50023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50023.png) | 50023 |
| ![50024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50024.png) | 50024 |
| ![50025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50025.png) | 50025 |
| ![50026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50026.png) | 50026 |
| ![50027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50027.png) | 50027 |
| ![50028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50028.png) | 50028 |
| ![50029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50029.png) | 50029 |
| ![50030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50030.png) | 50030 |
| ![50031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50031.png) | 50031 |