# Crystal Rose Swain Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![50013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50013.png) | 50013 |
| ![50014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50014.png) | 50014 |
| ![50015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50015.png) | 50015 |
| ![50016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50016.png) | 50016 |
| ![50017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50017.png) | 50017 |
| ![50018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50018.png) | 50018 |
| ![50019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50019.png) | 50019 |
| ![50020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50020.png) | 50020 |
| ![50022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50022.png) | 50022 |