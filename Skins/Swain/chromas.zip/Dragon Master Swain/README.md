# Dragon Master Swain Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![50005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50005.png) | 50005 |
| ![50006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50006.png) | 50006 |
| ![50007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50007.png) | 50007 |
| ![50008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50008.png) | 50008 |
| ![50009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50009.png) | 50009 |
| ![50010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/50/50010.png) | 50010 |