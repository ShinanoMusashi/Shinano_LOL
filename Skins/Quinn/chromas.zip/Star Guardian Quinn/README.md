# Star Guardian Quinn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![133015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133015.png) | 133015 |
| ![133016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133016.png) | 133016 |
| ![133017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133017.png) | 133017 |
| ![133018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133018.png) | 133018 |
| ![133019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133019.png) | 133019 |
| ![133020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133020.png) | 133020 |
| ![133021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133021.png) | 133021 |
| ![133022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133022.png) | 133022 |
| ![133023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133023.png) | 133023 |