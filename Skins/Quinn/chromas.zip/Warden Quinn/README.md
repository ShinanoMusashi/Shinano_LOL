# Warden Quinn Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![133006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133006.png) | 133006 |
| ![133007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133007.png) | 133007 |
| ![133008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133008.png) | 133008 |
| ![133009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133009.png) | 133009 |
| ![133010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133010.png) | 133010 |
| ![133011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133011.png) | 133011 |
| ![133012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133012.png) | 133012 |
| ![133013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/133/133013.png) | 133013 |