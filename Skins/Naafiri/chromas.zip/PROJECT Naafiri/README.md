# PROJECT Naafiri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![950012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950012.png) | 950012 |
| ![950013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950013.png) | 950013 |
| ![950014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950014.png) | 950014 |
| ![950015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950015.png) | 950015 |
| ![950016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950016.png) | 950016 |
| ![950017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950017.png) | 950017 |
| ![950018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950018.png) | 950018 |
| ![950019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950019.png) | 950019 |