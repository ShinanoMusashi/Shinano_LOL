# Glizzy Naafiri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![950021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950021.png) | 950021 |
| ![950022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950022.png) | 950022 |
| ![950023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950023.png) | 950023 |
| ![950024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950024.png) | 950024 |
| ![950025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950025.png) | 950025 |
| ![950026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950026.png) | 950026 |
| ![950027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950027.png) | 950027 |
| ![950028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950028.png) | 950028 |