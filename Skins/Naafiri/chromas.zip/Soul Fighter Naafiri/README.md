# Soul Fighter Naafiri Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![950002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950002.png) | 950002 |
| ![950003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950003.png) | 950003 |
| ![950004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950004.png) | 950004 |
| ![950005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950005.png) | 950005 |
| ![950006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950006.png) | 950006 |
| ![950007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950007.png) | 950007 |
| ![950008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950008.png) | 950008 |
| ![950009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950009.png) | 950009 |
| ![950010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/950/950010.png) | 950010 |