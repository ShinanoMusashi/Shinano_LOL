# Firecracker Sejuani Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![113009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113009.png) | 113009 |
| ![113010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113010.png) | 113010 |
| ![113011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113011.png) | 113011 |
| ![113012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113012.png) | 113012 |
| ![113013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113013.png) | 113013 |
| ![113014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113014.png) | 113014 |
| ![113027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113027.png) | 113027 |