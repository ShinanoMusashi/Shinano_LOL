# PROJECT Sejuani Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![113017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113017.png) | 113017 |
| ![113018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113018.png) | 113018 |
| ![113019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113019.png) | 113019 |
| ![113020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113020.png) | 113020 |
| ![113021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113021.png) | 113021 |
| ![113022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113022.png) | 113022 |
| ![113023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113023.png) | 113023 |
| ![113024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113024.png) | 113024 |
| ![113025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113025.png) | 113025 |