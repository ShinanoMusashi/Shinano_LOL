# Solar Eclipse Sejuani Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![113028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113028.png) | 113028 |
| ![113029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113029.png) | 113029 |
| ![113030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113030.png) | 113030 |
| ![113031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113031.png) | 113031 |
| ![113032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113032.png) | 113032 |
| ![113033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113033.png) | 113033 |
| ![113034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113034.png) | 113034 |
| ![113035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113035.png) | 113035 |