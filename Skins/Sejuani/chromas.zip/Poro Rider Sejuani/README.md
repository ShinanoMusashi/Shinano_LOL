# Poro Rider Sejuani Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![113047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/113/113047.png) | 113047 |