# Aether Wing Kayle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![10051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10051.png) | 10051 |
| ![10052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10052.png) | 10052 |
| ![10053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10053.png) | 10053 |
| ![10054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10054.png) | 10054 |
| ![10055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10055.png) | 10055 |
| ![10056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10056.png) | 10056 |