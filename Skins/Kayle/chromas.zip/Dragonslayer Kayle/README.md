# Dragonslayer Kayle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![10025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10025.png) | 10025 |
| ![10026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10026.png) | 10026 |
| ![10027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10027.png) | 10027 |
| ![10028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10028.png) | 10028 |
| ![10029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10029.png) | 10029 |
| ![10030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10030.png) | 10030 |
| ![10031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10031.png) | 10031 |
| ![10032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10032.png) | 10032 |