# Empyrean Kayle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![10068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10068.png) | 10068 |
| ![10069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10069.png) | 10069 |
| ![10070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10070.png) | 10070 |
| ![10071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10071.png) | 10071 |
| ![10072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10072.png) | 10072 |
| ![10073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10073.png) | 10073 |
| ![10074](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10074.png) | 10074 |
| ![10075](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10075.png) | 10075 |
| ![10076](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10076.png) | 10076 |
| ![10077](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10077.png) | 10077 |