# Sun-Eater Kayle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![10043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10043.png) | 10043 |
| ![10044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10044.png) | 10044 |
| ![10045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10045.png) | 10045 |
| ![10046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10046.png) | 10046 |
| ![10047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10047.png) | 10047 |
| ![10048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10048.png) | 10048 |
| ![10049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10049.png) | 10049 |
| ![10050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10050.png) | 10050 |