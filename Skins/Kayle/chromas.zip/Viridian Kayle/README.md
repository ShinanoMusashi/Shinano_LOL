# Viridian Kayle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![10010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10010.png) | 10010 |
| ![10011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10011.png) | 10011 |
| ![10012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10012.png) | 10012 |
| ![10013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10013.png) | 10013 |
| ![10014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/10/10014.png) | 10014 |