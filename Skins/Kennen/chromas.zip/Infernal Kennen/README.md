# Infernal Kennen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![85017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85017.png) | 85017 |
| ![85018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85018.png) | 85018 |
| ![85019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85019.png) | 85019 |
| ![85020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85020.png) | 85020 |
| ![85021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85021.png) | 85021 |
| ![85022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85022.png) | 85022 |