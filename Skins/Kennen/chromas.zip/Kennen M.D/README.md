# Kennen M.D. Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![85009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85009.png) | 85009 |
| ![85010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85010.png) | 85010 |
| ![85011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85011.png) | 85011 |
| ![85012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85012.png) | 85012 |
| ![85013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85013.png) | 85013 |
| ![85014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85014.png) | 85014 |
| ![85015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85015.png) | 85015 |
| ![85016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85016.png) | 85016 |