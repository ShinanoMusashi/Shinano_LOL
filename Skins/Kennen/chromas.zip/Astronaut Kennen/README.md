# Astronaut Kennen Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![85026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85026.png) | 85026 |
| ![85027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85027.png) | 85027 |
| ![85028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85028.png) | 85028 |
| ![85029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85029.png) | 85029 |
| ![85030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85030.png) | 85030 |
| ![85031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85031.png) | 85031 |
| ![85032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85032.png) | 85032 |
| ![85033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/85/85033.png) | 85033 |