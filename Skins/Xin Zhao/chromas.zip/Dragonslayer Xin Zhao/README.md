# Dragonslayer Xin Zhao Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![5014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5014.png) | 5014 |
| ![5015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5015.png) | 5015 |
| ![5016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5016.png) | 5016 |
| ![5017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5017.png) | 5017 |
| ![5018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5018.png) | 5018 |
| ![5019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5019.png) | 5019 |