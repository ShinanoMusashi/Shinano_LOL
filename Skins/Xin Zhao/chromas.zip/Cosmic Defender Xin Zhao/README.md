# Cosmic Defender Xin Zhao Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![5021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5021.png) | 5021 |
| ![5022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5022.png) | 5022 |
| ![5023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5023.png) | 5023 |
| ![5024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5024.png) | 5024 |
| ![5025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5025.png) | 5025 |