# Warring Kingdoms Xin Zhao Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![5007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5007.png) | 5007 |
| ![5008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5008.png) | 5008 |
| ![5009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5009.png) | 5009 |
| ![5010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5010.png) | 5010 |
| ![5011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5011.png) | 5011 |
| ![5012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5012.png) | 5012 |
| ![5026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5026.png) | 5026 |