# Firecracker Xin Zhao Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![5037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5037.png) | 5037 |
| ![5038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5038.png) | 5038 |
| ![5039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5039.png) | 5039 |
| ![5040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5040.png) | 5040 |
| ![5041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5041.png) | 5041 |
| ![5042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5042.png) | 5042 |
| ![5043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5043.png) | 5043 |
| ![5044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5044.png) | 5044 |
| ![5045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/5/5045.png) | 5045 |