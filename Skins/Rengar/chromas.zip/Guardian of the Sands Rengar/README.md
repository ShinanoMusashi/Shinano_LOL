# Guardian of the Sands Rengar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![107024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107024.png) | 107024 |
| ![107025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107025.png) | 107025 |
| ![107026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107026.png) | 107026 |
| ![107027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107027.png) | 107027 |
| ![107028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107028.png) | 107028 |
| ![107029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107029.png) | 107029 |