# Mecha Rengar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![107009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107009.png) | 107009 |
| ![107010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107010.png) | 107010 |
| ![107011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107011.png) | 107011 |
| ![107012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107012.png) | 107012 |
| ![107013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107013.png) | 107013 |
| ![107014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107014.png) | 107014 |