# Sentinel Rengar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![107031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107031.png) | 107031 |
| ![107032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107032.png) | 107032 |
| ![107033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107033.png) | 107033 |
| ![107034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107034.png) | 107034 |
| ![107035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107035.png) | 107035 |
| ![107036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107036.png) | 107036 |
| ![107037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107037.png) | 107037 |
| ![107038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107038.png) | 107038 |
| ![107039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107039.png) | 107039 |