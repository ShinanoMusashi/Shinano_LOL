# Headhunter Rengar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![107004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107004.png) | 107004 |
| ![107005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107005.png) | 107005 |
| ![107006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107006.png) | 107006 |
| ![107007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/107/107007.png) | 107007 |