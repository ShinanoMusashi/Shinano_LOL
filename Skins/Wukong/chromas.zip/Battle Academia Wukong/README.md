# Battle Academia Wukong Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![62008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62008.png) | 62008 |
| ![62009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62009.png) | 62009 |
| ![62010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62010.png) | 62010 |
| ![62011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62011.png) | 62011 |
| ![62012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62012.png) | 62012 |
| ![62013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62013.png) | 62013 |
| ![62014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62014.png) | 62014 |
| ![62015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62015.png) | 62015 |