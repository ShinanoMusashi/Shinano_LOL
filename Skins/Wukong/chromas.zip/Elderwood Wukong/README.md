# Elderwood Wukong Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![62017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62017.png) | 62017 |
| ![62018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62018.png) | 62018 |
| ![62019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62019.png) | 62019 |
| ![62020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62020.png) | 62020 |
| ![62021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62021.png) | 62021 |
| ![62022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62022.png) | 62022 |
| ![62023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62023.png) | 62023 |
| ![62024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62024.png) | 62024 |