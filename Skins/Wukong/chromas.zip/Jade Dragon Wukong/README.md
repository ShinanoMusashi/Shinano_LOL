# Jade Dragon Wukong Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![62025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/62/62025.png) | 62025 |