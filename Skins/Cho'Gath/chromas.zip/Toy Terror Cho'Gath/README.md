# Toy Terror Cho'Gath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![31033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31033.png) | 31033 |
| ![31034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31034.png) | 31034 |
| ![31035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31035.png) | 31035 |
| ![31036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31036.png) | 31036 |
| ![31037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31037.png) | 31037 |
| ![31038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31038.png) | 31038 |
| ![31039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31039.png) | 31039 |
| ![31040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31040.png) | 31040 |