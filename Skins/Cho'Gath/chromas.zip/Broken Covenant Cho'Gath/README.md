# Broken Covenant Cho'Gath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![31024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31024.png) | 31024 |
| ![31025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31025.png) | 31025 |
| ![31026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31026.png) | 31026 |
| ![31027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31027.png) | 31027 |
| ![31028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31028.png) | 31028 |
| ![31029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31029.png) | 31029 |
| ![31030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31030.png) | 31030 |
| ![31031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31031.png) | 31031 |