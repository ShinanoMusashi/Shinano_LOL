# Shan Hai Scrolls Cho'Gath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![31015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31015.png) | 31015 |
| ![31016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31016.png) | 31016 |
| ![31017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31017.png) | 31017 |
| ![31018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31018.png) | 31018 |
| ![31019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31019.png) | 31019 |
| ![31020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31020.png) | 31020 |
| ![31021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31021.png) | 31021 |
| ![31022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31022.png) | 31022 |