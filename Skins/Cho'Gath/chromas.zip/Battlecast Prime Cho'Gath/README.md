# Battlecast Prime Cho'Gath Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![31008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31008.png) | 31008 |
| ![31009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31009.png) | 31009 |
| ![31010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31010.png) | 31010 |
| ![31011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31011.png) | 31011 |
| ![31012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31012.png) | 31012 |
| ![31013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/31/31013.png) | 31013 |