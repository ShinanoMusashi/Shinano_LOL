# Victorious Lucian Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![236026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236026.png) | 236026 |
| ![236027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236027.png) | 236027 |
| ![236028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236028.png) | 236028 |
| ![236029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236029.png) | 236029 |
| ![236030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236030.png) | 236030 |