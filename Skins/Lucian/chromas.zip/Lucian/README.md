# Lucian Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![236003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236003.png) | 236003 |
| ![236004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236004.png) | 236004 |
| ![236005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236005.png) | 236005 |