# PROJECT Lucian Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![236017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236017.png) | 236017 |