# Winterblessed Lucian Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![236053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236053.png) | 236053 |
| ![236054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236054.png) | 236054 |
| ![236055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236055.png) | 236055 |
| ![236056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236056.png) | 236056 |
| ![236057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236057.png) | 236057 |
| ![236058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236058.png) | 236058 |
| ![236059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236059.png) | 236059 |
| ![236060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236060.png) | 236060 |
| ![236061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/236/236061.png) | 236061 |