# Marauder Kalista Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![429006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429006.png) | 429006 |
| ![429007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429007.png) | 429007 |
| ![429008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429008.png) | 429008 |
| ![429009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429009.png) | 429009 |
| ![429010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429010.png) | 429010 |
| ![429011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429011.png) | 429011 |
| ![429012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429012.png) | 429012 |
| ![429013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429013.png) | 429013 |