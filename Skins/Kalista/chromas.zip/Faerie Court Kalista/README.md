# Faerie Court Kalista Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![429015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429015.png) | 429015 |
| ![429016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429016.png) | 429016 |
| ![429017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429017.png) | 429017 |
| ![429018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429018.png) | 429018 |
| ![429019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429019.png) | 429019 |
| ![429020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429020.png) | 429020 |
| ![429021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429021.png) | 429021 |
| ![429022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429022.png) | 429022 |
| ![429023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429023.png) | 429023 |