# Worlds 2015 Kalista Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![429004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/429/429004.png) | 429004 |