# Empyrean Malzahar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![90040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90040.png) | 90040 |
| ![90041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90041.png) | 90041 |
| ![90042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90042.png) | 90042 |
| ![90043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90043.png) | 90043 |
| ![90044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90044.png) | 90044 |
| ![90045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90045.png) | 90045 |
| ![90046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90046.png) | 90046 |
| ![90047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90047.png) | 90047 |
| ![90048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90048.png) | 90048 |