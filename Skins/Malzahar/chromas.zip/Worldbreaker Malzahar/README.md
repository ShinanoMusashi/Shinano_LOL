# Worldbreaker Malzahar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![90010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90010.png) | 90010 |
| ![90011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90011.png) | 90011 |
| ![90012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90012.png) | 90012 |
| ![90013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90013.png) | 90013 |
| ![90014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90014.png) | 90014 |
| ![90015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90015.png) | 90015 |
| ![90016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90016.png) | 90016 |
| ![90017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90017.png) | 90017 |