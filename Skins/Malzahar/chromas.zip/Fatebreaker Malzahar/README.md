# Fatebreaker Malzahar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![90050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90050.png) | 90050 |
| ![90051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90051.png) | 90051 |
| ![90052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90052.png) | 90052 |
| ![90053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90053.png) | 90053 |
| ![90054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90054.png) | 90054 |
| ![90055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90055.png) | 90055 |
| ![90056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90056.png) | 90056 |
| ![90057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90057.png) | 90057 |