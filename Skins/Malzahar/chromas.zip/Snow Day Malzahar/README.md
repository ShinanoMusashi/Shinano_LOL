# Snow Day Malzahar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![90008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/90/90008.png) | 90008 |