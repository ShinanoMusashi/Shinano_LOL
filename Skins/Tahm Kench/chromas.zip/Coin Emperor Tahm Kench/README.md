# Coin Emperor Tahm Kench Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![223004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223004.png) | 223004 |
| ![223005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223005.png) | 223005 |
| ![223006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223006.png) | 223006 |
| ![223007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223007.png) | 223007 |
| ![223008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223008.png) | 223008 |
| ![223009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223009.png) | 223009 |