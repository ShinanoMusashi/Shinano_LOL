# High Noon Tahm Kench Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![223021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223021.png) | 223021 |
| ![223022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223022.png) | 223022 |
| ![223023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223023.png) | 223023 |
| ![223024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223024.png) | 223024 |
| ![223025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223025.png) | 223025 |
| ![223026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223026.png) | 223026 |
| ![223027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223027.png) | 223027 |
| ![223028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223028.png) | 223028 |
| ![223029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223029.png) | 223029 |