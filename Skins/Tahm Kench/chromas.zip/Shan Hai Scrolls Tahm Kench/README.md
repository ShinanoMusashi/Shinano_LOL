# Shan Hai Scrolls Tahm Kench Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![223031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223031.png) | 223031 |
| ![223032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223032.png) | 223032 |
| ![223033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223033.png) | 223033 |
| ![223034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223034.png) | 223034 |
| ![223035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223035.png) | 223035 |
| ![223036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223036.png) | 223036 |
| ![223037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223037.png) | 223037 |
| ![223038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/223/223038.png) | 223038 |