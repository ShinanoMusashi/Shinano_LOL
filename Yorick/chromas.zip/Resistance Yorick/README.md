# Resistance Yorick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![83013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83013.png) | 83013 |
| ![83014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83014.png) | 83014 |
| ![83015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83015.png) | 83015 |
| ![83016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83016.png) | 83016 |
| ![83017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83017.png) | 83017 |
| ![83018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83018.png) | 83018 |
| ![83019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83019.png) | 83019 |
| ![83020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83020.png) | 83020 |