# High Noon Yorick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![83051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83051.png) | 83051 |
| ![83052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83052.png) | 83052 |
| ![83053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83053.png) | 83053 |
| ![83054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83054.png) | 83054 |
| ![83055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83055.png) | 83055 |
| ![83056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83056.png) | 83056 |
| ![83057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83057.png) | 83057 |
| ![83058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83058.png) | 83058 |