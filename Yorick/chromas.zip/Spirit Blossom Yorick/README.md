# Spirit Blossom Yorick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![83031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83031.png) | 83031 |
| ![83032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83032.png) | 83032 |
| ![83033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83033.png) | 83033 |
| ![83034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83034.png) | 83034 |
| ![83035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83035.png) | 83035 |
| ![83036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83036.png) | 83036 |
| ![83037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83037.png) | 83037 |
| ![83038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83038.png) | 83038 |
| ![83039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83039.png) | 83039 |