# Pentakill III Lost Chapter Yorick Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![83022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83022.png) | 83022 |
| ![83023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83023.png) | 83023 |
| ![83024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83024.png) | 83024 |
| ![83025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83025.png) | 83025 |
| ![83026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83026.png) | 83026 |
| ![83027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83027.png) | 83027 |
| ![83028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83028.png) | 83028 |
| ![83029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/83/83029.png) | 83029 |