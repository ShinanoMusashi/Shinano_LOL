# Woof and Lamb Kindred Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![203024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203024.png) | 203024 |
| ![203025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203025.png) | 203025 |
| ![203026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203026.png) | 203026 |
| ![203027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203027.png) | 203027 |
| ![203028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203028.png) | 203028 |
| ![203029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203029.png) | 203029 |
| ![203030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203030.png) | 203030 |
| ![203031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203031.png) | 203031 |