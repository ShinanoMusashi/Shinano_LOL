# DRX Kindred Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![203032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203032.png) | 203032 |