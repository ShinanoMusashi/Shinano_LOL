# Spirit Blossom Kindred Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![203004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203004.png) | 203004 |
| ![203005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203005.png) | 203005 |
| ![203006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203006.png) | 203006 |
| ![203007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203007.png) | 203007 |
| ![203008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203008.png) | 203008 |
| ![203009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203009.png) | 203009 |
| ![203010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203010.png) | 203010 |
| ![203011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203011.png) | 203011 |