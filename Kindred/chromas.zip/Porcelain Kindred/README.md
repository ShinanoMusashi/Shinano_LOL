# Porcelain Kindred Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![203013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203013.png) | 203013 |
| ![203014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203014.png) | 203014 |
| ![203015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203015.png) | 203015 |
| ![203016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203016.png) | 203016 |
| ![203017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203017.png) | 203017 |
| ![203018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203018.png) | 203018 |
| ![203019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203019.png) | 203019 |
| ![203020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203020.png) | 203020 |
| ![203021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/203/203021.png) | 203021 |