# Fright Night Trundle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![48013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48013.png) | 48013 |
| ![48014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48014.png) | 48014 |
| ![48015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48015.png) | 48015 |
| ![48016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48016.png) | 48016 |
| ![48017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48017.png) | 48017 |
| ![48018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48018.png) | 48018 |
| ![48019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48019.png) | 48019 |
| ![48020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48020.png) | 48020 |