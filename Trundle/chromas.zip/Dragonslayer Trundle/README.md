# Dragonslayer Trundle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![48007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48007.png) | 48007 |
| ![48008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48008.png) | 48008 |
| ![48009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48009.png) | 48009 |
| ![48010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48010.png) | 48010 |
| ![48011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48011.png) | 48011 |