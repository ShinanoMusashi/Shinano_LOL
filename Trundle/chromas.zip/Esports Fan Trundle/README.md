# Esports Fan Trundle Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![48022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48022.png) | 48022 |
| ![48023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48023.png) | 48023 |
| ![48024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48024.png) | 48024 |
| ![48025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48025.png) | 48025 |
| ![48026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48026.png) | 48026 |
| ![48027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48027.png) | 48027 |
| ![48028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48028.png) | 48028 |
| ![48029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/48/48029.png) | 48029 |