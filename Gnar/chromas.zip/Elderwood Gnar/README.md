# Elderwood Gnar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![150023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150023.png) | 150023 |
| ![150024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150024.png) | 150024 |
| ![150025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150025.png) | 150025 |
| ![150026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150026.png) | 150026 |
| ![150027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150027.png) | 150027 |
| ![150028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150028.png) | 150028 |
| ![150029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150029.png) | 150029 |
| ![150030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150030.png) | 150030 |