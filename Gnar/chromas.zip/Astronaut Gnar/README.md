# Astronaut Gnar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![150016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150016.png) | 150016 |
| ![150017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150017.png) | 150017 |
| ![150018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150018.png) | 150018 |
| ![150019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150019.png) | 150019 |
| ![150020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150020.png) | 150020 |
| ![150021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150021.png) | 150021 |