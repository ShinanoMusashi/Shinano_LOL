# La Ilusi��n Gnar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![150032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150032.png) | 150032 |
| ![150033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150033.png) | 150033 |
| ![150034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150034.png) | 150034 |
| ![150035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150035.png) | 150035 |
| ![150036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150036.png) | 150036 |
| ![150037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150037.png) | 150037 |
| ![150038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150038.png) | 150038 |
| ![150039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150039.png) | 150039 |
| ![150040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150040.png) | 150040 |