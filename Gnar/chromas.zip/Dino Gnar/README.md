# Dino Gnar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![150005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150005.png) | 150005 |
| ![150006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150006.png) | 150006 |
| ![150007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150007.png) | 150007 |
| ![150008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150008.png) | 150008 |
| ![150009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150009.png) | 150009 |
| ![150010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150010.png) | 150010 |
| ![150011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150011.png) | 150011 |
| ![150012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/150/150012.png) | 150012 |