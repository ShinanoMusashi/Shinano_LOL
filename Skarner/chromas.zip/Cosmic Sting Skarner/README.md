# Cosmic Sting Skarner Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![72006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72006.png) | 72006 |
| ![72007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72007.png) | 72007 |
| ![72008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72008.png) | 72008 |
| ![72009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72009.png) | 72009 |
| ![72010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72010.png) | 72010 |
| ![72011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72011.png) | 72011 |
| ![72012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72012.png) | 72012 |
| ![72013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/72/72013.png) | 72013 |