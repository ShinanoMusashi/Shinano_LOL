# Dark Cosmic Lissandra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![127013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127013.png) | 127013 |
| ![127014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127014.png) | 127014 |
| ![127015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127015.png) | 127015 |
| ![127016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127016.png) | 127016 |
| ![127017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127017.png) | 127017 |
| ![127018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127018.png) | 127018 |
| ![127019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127019.png) | 127019 |
| ![127020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127020.png) | 127020 |
| ![127021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127021.png) | 127021 |