# Space Groove Lissandra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![127035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127035.png) | 127035 |
| ![127036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127036.png) | 127036 |
| ![127037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127037.png) | 127037 |
| ![127038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127038.png) | 127038 |
| ![127039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127039.png) | 127039 |
| ![127040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127040.png) | 127040 |
| ![127041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127041.png) | 127041 |
| ![127042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127042.png) | 127042 |