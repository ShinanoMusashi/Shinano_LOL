# Coven Lissandra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![127005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127005.png) | 127005 |
| ![127006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127006.png) | 127006 |
| ![127007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127007.png) | 127007 |
| ![127008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127008.png) | 127008 |
| ![127009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127009.png) | 127009 |
| ![127010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127010.png) | 127010 |
| ![127011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127011.png) | 127011 |
| ![127022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127022.png) | 127022 |