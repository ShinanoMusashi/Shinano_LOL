# Porcelain Lissandra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![127024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127024.png) | 127024 |
| ![127025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127025.png) | 127025 |
| ![127026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127026.png) | 127026 |
| ![127027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127027.png) | 127027 |
| ![127028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127028.png) | 127028 |
| ![127029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127029.png) | 127029 |
| ![127030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127030.png) | 127030 |
| ![127031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127031.png) | 127031 |
| ![127032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/127/127032.png) | 127032 |