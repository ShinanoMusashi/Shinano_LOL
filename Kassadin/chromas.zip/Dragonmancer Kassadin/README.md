# Dragonmancer Kassadin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![38025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38025.png) | 38025 |
| ![38026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38026.png) | 38026 |
| ![38027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38027.png) | 38027 |
| ![38028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38028.png) | 38028 |
| ![38029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38029.png) | 38029 |
| ![38030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38030.png) | 38030 |
| ![38031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38031.png) | 38031 |
| ![38032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38032.png) | 38032 |