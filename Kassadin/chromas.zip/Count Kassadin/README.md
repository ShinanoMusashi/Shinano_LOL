# Count Kassadin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![38008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38008.png) | 38008 |
| ![38009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38009.png) | 38009 |
| ![38010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38010.png) | 38010 |
| ![38011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38011.png) | 38011 |
| ![38012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38012.png) | 38012 |
| ![38013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38013.png) | 38013 |