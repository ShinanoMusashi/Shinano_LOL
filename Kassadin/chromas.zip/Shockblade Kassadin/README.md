# Shockblade Kassadin Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![38016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38016.png) | 38016 |
| ![38017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38017.png) | 38017 |
| ![38018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38018.png) | 38018 |
| ![38019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38019.png) | 38019 |
| ![38020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38020.png) | 38020 |
| ![38021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38021.png) | 38021 |
| ![38022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38022.png) | 38022 |
| ![38023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/38/38023.png) | 38023 |