# Firecracker Sett Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![875029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875029.png) | 875029 |
| ![875030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875030.png) | 875030 |
| ![875031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875031.png) | 875031 |
| ![875032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875032.png) | 875032 |
| ![875033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875033.png) | 875033 |
| ![875034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875034.png) | 875034 |
| ![875035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875035.png) | 875035 |
| ![875036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875036.png) | 875036 |
| ![875037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875037.png) | 875037 |