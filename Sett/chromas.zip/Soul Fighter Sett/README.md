# Soul Fighter Sett Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![875046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875046.png) | 875046 |
| ![875047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875047.png) | 875047 |
| ![875048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875048.png) | 875048 |
| ![875049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875049.png) | 875049 |
| ![875050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875050.png) | 875050 |
| ![875051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875051.png) | 875051 |
| ![875052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875052.png) | 875052 |
| ![875053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875053.png) | 875053 |
| ![875054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875054.png) | 875054 |