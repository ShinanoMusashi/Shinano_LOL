# Mecha Kingdoms Sett Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![875002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875002.png) | 875002 |
| ![875003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875003.png) | 875003 |
| ![875004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875004.png) | 875004 |
| ![875005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875005.png) | 875005 |
| ![875006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875006.png) | 875006 |
| ![875007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875007.png) | 875007 |