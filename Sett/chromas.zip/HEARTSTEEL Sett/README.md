# HEARTSTEEL Sett Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![875057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875057.png) | 875057 |
| ![875058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875058.png) | 875058 |
| ![875059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875059.png) | 875059 |
| ![875060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875060.png) | 875060 |
| ![875061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875061.png) | 875061 |
| ![875062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875062.png) | 875062 |
| ![875063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875063.png) | 875063 |
| ![875064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875064.png) | 875064 |
| ![875065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875065.png) | 875065 |