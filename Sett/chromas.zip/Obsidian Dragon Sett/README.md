# Obsidian Dragon Sett Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![875020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875020.png) | 875020 |
| ![875021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875021.png) | 875021 |
| ![875022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875022.png) | 875022 |
| ![875023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875023.png) | 875023 |
| ![875024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875024.png) | 875024 |
| ![875025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875025.png) | 875025 |
| ![875026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875026.png) | 875026 |
| ![875027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875027.png) | 875027 |
| ![875028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875028.png) | 875028 |
| ![875055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/875/875055.png) | 875055 |