# Rocket Girl Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18007.png) | 18007 |
| ![18008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18008.png) | 18008 |
| ![18009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18009.png) | 18009 |