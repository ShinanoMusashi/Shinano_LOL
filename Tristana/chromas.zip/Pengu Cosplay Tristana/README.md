# Pengu Cosplay Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18034.png) | 18034 |
| ![18035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18035.png) | 18035 |
| ![18036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18036.png) | 18036 |
| ![18037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18037.png) | 18037 |
| ![18038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18038.png) | 18038 |
| ![18039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18039.png) | 18039 |