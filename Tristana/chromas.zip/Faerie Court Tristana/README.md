# Faerie Court Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18062.png) | 18062 |
| ![18063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18063.png) | 18063 |
| ![18064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18064.png) | 18064 |
| ![18065](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18065.png) | 18065 |
| ![18066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18066.png) | 18066 |
| ![18067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18067.png) | 18067 |
| ![18068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18068.png) | 18068 |
| ![18069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18069.png) | 18069 |