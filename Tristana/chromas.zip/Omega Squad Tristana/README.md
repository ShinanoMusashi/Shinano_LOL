# Omega Squad Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18013.png) | 18013 |
| ![18014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18014.png) | 18014 |
| ![18015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18015.png) | 18015 |
| ![18016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18016.png) | 18016 |
| ![18017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18017.png) | 18017 |