# Little Demon Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18025.png) | 18025 |
| ![18026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18026.png) | 18026 |
| ![18027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18027.png) | 18027 |
| ![18028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18028.png) | 18028 |
| ![18029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18029.png) | 18029 |
| ![18030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18030.png) | 18030 |
| ![18031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18031.png) | 18031 |
| ![18032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18032.png) | 18032 |