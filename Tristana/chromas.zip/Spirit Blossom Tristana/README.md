# Spirit Blossom Tristana Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![18052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18052.png) | 18052 |
| ![18053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18053.png) | 18053 |
| ![18054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18054.png) | 18054 |
| ![18055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18055.png) | 18055 |
| ![18056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18056.png) | 18056 |
| ![18057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18057.png) | 18057 |
| ![18058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18058.png) | 18058 |
| ![18059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18059.png) | 18059 |
| ![18060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/18/18060.png) | 18060 |