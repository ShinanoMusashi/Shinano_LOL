# Lunar Beast Darius Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![122025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122025.png) | 122025 |
| ![122026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122026.png) | 122026 |
| ![122027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122027.png) | 122027 |
| ![122028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122028.png) | 122028 |
| ![122029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122029.png) | 122029 |
| ![122030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122030.png) | 122030 |
| ![122031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122031.png) | 122031 |