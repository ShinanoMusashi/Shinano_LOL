# Crime City Nightmare Darius Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![122034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122034.png) | 122034 |
| ![122035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122035.png) | 122035 |
| ![122036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122036.png) | 122036 |
| ![122037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122037.png) | 122037 |
| ![122038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122038.png) | 122038 |
| ![122039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122039.png) | 122039 |
| ![122040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122040.png) | 122040 |
| ![122041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122041.png) | 122041 |
| ![122042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122042.png) | 122042 |