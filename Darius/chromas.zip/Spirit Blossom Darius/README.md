# Spirit Blossom Darius Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![122044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122044.png) | 122044 |
| ![122045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122045.png) | 122045 |
| ![122046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122046.png) | 122046 |
| ![122047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122047.png) | 122047 |
| ![122048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122048.png) | 122048 |
| ![122049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122049.png) | 122049 |
| ![122050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122050.png) | 122050 |
| ![122051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122051.png) | 122051 |
| ![122052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122052.png) | 122052 |