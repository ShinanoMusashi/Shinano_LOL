# High Noon Darius Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![122017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122017.png) | 122017 |
| ![122018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122018.png) | 122018 |
| ![122019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122019.png) | 122019 |
| ![122020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122020.png) | 122020 |
| ![122021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122021.png) | 122021 |
| ![122022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122022.png) | 122022 |
| ![122023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122023.png) | 122023 |