# Porcelain Darius Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![122055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122055.png) | 122055 |
| ![122056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122056.png) | 122056 |
| ![122057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122057.png) | 122057 |
| ![122058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122058.png) | 122058 |
| ![122059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122059.png) | 122059 |
| ![122060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122060.png) | 122060 |
| ![122061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122061.png) | 122061 |
| ![122062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122062.png) | 122062 |
| ![122063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/122/122063.png) | 122063 |