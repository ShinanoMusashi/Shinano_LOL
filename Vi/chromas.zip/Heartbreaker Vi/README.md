# Heartbreaker Vi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![254013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254013.png) | 254013 |
| ![254014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254014.png) | 254014 |
| ![254015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254015.png) | 254015 |
| ![254016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254016.png) | 254016 |
| ![254017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254017.png) | 254017 |
| ![254018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254018.png) | 254018 |
| ![254019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254019.png) | 254019 |