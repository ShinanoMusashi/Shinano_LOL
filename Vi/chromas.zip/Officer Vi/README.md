# Officer Vi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![254006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254006.png) | 254006 |
| ![254007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254007.png) | 254007 |
| ![254008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254008.png) | 254008 |
| ![254009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254009.png) | 254009 |
| ![254010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254010.png) | 254010 |