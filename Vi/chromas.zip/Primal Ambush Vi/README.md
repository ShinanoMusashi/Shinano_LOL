# Primal Ambush Vi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![254040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254040.png) | 254040 |
| ![254041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254041.png) | 254041 |
| ![254042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254042.png) | 254042 |
| ![254043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254043.png) | 254043 |
| ![254044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254044.png) | 254044 |
| ![254045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254045.png) | 254045 |
| ![254046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254046.png) | 254046 |
| ![254047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254047.png) | 254047 |