# Heartache Vi Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![254031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254031.png) | 254031 |
| ![254032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254032.png) | 254032 |
| ![254033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254033.png) | 254033 |
| ![254034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254034.png) | 254034 |
| ![254035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254035.png) | 254035 |
| ![254036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254036.png) | 254036 |
| ![254037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254037.png) | 254037 |
| ![254038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/254/254038.png) | 254038 |