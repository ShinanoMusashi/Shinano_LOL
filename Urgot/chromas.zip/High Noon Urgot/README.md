# High Noon Urgot Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![6010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6010.png) | 6010 |
| ![6011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6011.png) | 6011 |
| ![6012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6012.png) | 6012 |
| ![6013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6013.png) | 6013 |
| ![6014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6014.png) | 6014 |