# Pajama Guardian Cosplay Urgot Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![6016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6016.png) | 6016 |
| ![6017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6017.png) | 6017 |
| ![6018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6018.png) | 6018 |
| ![6019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6019.png) | 6019 |
| ![6020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6020.png) | 6020 |
| ![6021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6021.png) | 6021 |
| ![6022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6022.png) | 6022 |