# Battlecast Urgot Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![6004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6004.png) | 6004 |
| ![6005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6005.png) | 6005 |
| ![6006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6006.png) | 6006 |
| ![6007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6007.png) | 6007 |
| ![6008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6008.png) | 6008 |