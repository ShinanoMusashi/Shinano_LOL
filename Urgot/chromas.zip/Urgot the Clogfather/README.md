# Urgot the Clogfather Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![6033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6033.png) | 6033 |
| ![6034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6034.png) | 6034 |
| ![6035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6035.png) | 6035 |
| ![6036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6036.png) | 6036 |
| ![6037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6037.png) | 6037 |
| ![6038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6038.png) | 6038 |
| ![6039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6039.png) | 6039 |
| ![6040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/6/6040.png) | 6040 |