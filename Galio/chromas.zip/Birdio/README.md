# Birdio Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![3007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3007.png) | 3007 |
| ![3008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3008.png) | 3008 |
| ![3009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3009.png) | 3009 |
| ![3010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3010.png) | 3010 |
| ![3011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3011.png) | 3011 |
| ![3012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3012.png) | 3012 |
| ![3029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3029.png) | 3029 |