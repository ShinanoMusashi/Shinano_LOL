# Infernal Galio Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![3014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3014.png) | 3014 |
| ![3015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3015.png) | 3015 |
| ![3016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3016.png) | 3016 |
| ![3017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3017.png) | 3017 |
| ![3018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3018.png) | 3018 |