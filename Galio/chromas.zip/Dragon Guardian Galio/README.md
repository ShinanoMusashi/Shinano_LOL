# Dragon Guardian Galio Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![3020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3020.png) | 3020 |
| ![3021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3021.png) | 3021 |
| ![3022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3022.png) | 3022 |
| ![3023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3023.png) | 3023 |
| ![3024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3024.png) | 3024 |
| ![3025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3025.png) | 3025 |
| ![3026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3026.png) | 3026 |
| ![3027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/3/3027.png) | 3027 |