# Bewitching Elise Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![60007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60007.png) | 60007 |
| ![60008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60008.png) | 60008 |
| ![60009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60009.png) | 60009 |
| ![60010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60010.png) | 60010 |
| ![60011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60011.png) | 60011 |
| ![60012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60012.png) | 60012 |
| ![60013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60013.png) | 60013 |
| ![60014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60014.png) | 60014 |