# Withered Rose Elise Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![60016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60016.png) | 60016 |
| ![60017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60017.png) | 60017 |
| ![60018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60018.png) | 60018 |
| ![60019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60019.png) | 60019 |
| ![60020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60020.png) | 60020 |
| ![60021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60021.png) | 60021 |
| ![60022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60022.png) | 60022 |
| ![60023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60023.png) | 60023 |
| ![60035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/60/60035.png) | 60035 |