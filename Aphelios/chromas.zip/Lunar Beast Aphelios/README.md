# Lunar Beast Aphelios Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![523010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523010.png) | 523010 |
| ![523011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523011.png) | 523011 |
| ![523012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523012.png) | 523012 |
| ![523013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523013.png) | 523013 |
| ![523014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523014.png) | 523014 |
| ![523015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523015.png) | 523015 |
| ![523016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523016.png) | 523016 |