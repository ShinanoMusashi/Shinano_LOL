# Spirit Blossom Aphelios Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![523021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523021.png) | 523021 |
| ![523022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523022.png) | 523022 |
| ![523023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523023.png) | 523023 |
| ![523024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523024.png) | 523024 |
| ![523025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523025.png) | 523025 |
| ![523026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523026.png) | 523026 |
| ![523027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523027.png) | 523027 |
| ![523028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523028.png) | 523028 |
| ![523029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523029.png) | 523029 |