# HEARTSTEEL Aphelios Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![523031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523031.png) | 523031 |
| ![523032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523032.png) | 523032 |
| ![523033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523033.png) | 523033 |
| ![523034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523034.png) | 523034 |
| ![523035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523035.png) | 523035 |
| ![523036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523036.png) | 523036 |
| ![523037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523037.png) | 523037 |
| ![523038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523038.png) | 523038 |
| ![523039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523039.png) | 523039 |