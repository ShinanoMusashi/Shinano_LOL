# Nightbringer Aphelios Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![523002](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523002.png) | 523002 |
| ![523003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523003.png) | 523003 |
| ![523004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523004.png) | 523004 |
| ![523005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523005.png) | 523005 |
| ![523006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523006.png) | 523006 |
| ![523007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523007.png) | 523007 |
| ![523008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523008.png) | 523008 |