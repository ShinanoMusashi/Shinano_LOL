# EDG Aphelios Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![523019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/523/523019.png) | 523019 |