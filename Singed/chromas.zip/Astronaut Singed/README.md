# Astronaut Singed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![27020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27020.png) | 27020 |
| ![27021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27021.png) | 27021 |
| ![27022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27022.png) | 27022 |
| ![27023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27023.png) | 27023 |
| ![27024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27024.png) | 27024 |
| ![27025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27025.png) | 27025 |
| ![27026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27026.png) | 27026 |
| ![27027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27027.png) | 27027 |