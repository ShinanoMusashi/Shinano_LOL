# Resistance Singed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![27011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27011.png) | 27011 |
| ![27012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27012.png) | 27012 |
| ![27013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27013.png) | 27013 |
| ![27014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27014.png) | 27014 |
| ![27015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27015.png) | 27015 |
| ![27016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27016.png) | 27016 |
| ![27017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27017.png) | 27017 |
| ![27018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/27/27018.png) | 27018 |