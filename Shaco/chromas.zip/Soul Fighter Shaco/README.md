# Soul Fighter Shaco Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![35045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35045.png) | 35045 |
| ![35046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35046.png) | 35046 |
| ![35047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35047.png) | 35047 |
| ![35048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35048.png) | 35048 |
| ![35049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35049.png) | 35049 |
| ![35050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35050.png) | 35050 |
| ![35051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35051.png) | 35051 |
| ![35052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35052.png) | 35052 |
| ![35053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35053.png) | 35053 |