# Fright Night Shaco Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![35055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35055.png) | 35055 |
| ![35056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35056.png) | 35056 |
| ![35057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35057.png) | 35057 |
| ![35058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35058.png) | 35058 |
| ![35059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35059.png) | 35059 |
| ![35060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35060.png) | 35060 |
| ![35061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35061.png) | 35061 |
| ![35062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35062.png) | 35062 |
| ![35063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35063.png) | 35063 |