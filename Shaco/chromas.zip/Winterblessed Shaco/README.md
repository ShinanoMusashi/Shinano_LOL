# Winterblessed Shaco Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![35034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35034.png) | 35034 |
| ![35035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35035.png) | 35035 |
| ![35036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35036.png) | 35036 |
| ![35037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35037.png) | 35037 |
| ![35038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35038.png) | 35038 |
| ![35039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35039.png) | 35039 |
| ![35040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35040.png) | 35040 |
| ![35041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35041.png) | 35041 |
| ![35042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35042.png) | 35042 |