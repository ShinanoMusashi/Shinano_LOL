# Dark Star Shaco Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![35009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35009.png) | 35009 |
| ![35010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35010.png) | 35010 |
| ![35011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35011.png) | 35011 |
| ![35012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35012.png) | 35012 |
| ![35013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35013.png) | 35013 |
| ![35014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/35/35014.png) | 35014 |