# Armored Titan Nasus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![75036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75036.png) | 75036 |
| ![75037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75037.png) | 75037 |
| ![75038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75038.png) | 75038 |
| ![75039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75039.png) | 75039 |
| ![75040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75040.png) | 75040 |
| ![75041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75041.png) | 75041 |
| ![75042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75042.png) | 75042 |
| ![75043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75043.png) | 75043 |
| ![75044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75044.png) | 75044 |