# Lunar Guardian Nasus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![75012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75012.png) | 75012 |
| ![75013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75013.png) | 75013 |
| ![75014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75014.png) | 75014 |
| ![75015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75015.png) | 75015 |