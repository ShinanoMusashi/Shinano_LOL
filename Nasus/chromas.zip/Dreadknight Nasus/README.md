# Dreadknight Nasus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![75007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75007.png) | 75007 |
| ![75008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75008.png) | 75008 |
| ![75009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75009.png) | 75009 |