# Space Groove Nasus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![75026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75026.png) | 75026 |
| ![75027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75027.png) | 75027 |
| ![75028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75028.png) | 75028 |
| ![75029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75029.png) | 75029 |
| ![75030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75030.png) | 75030 |
| ![75031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75031.png) | 75031 |
| ![75032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75032.png) | 75032 |
| ![75033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75033.png) | 75033 |
| ![75034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75034.png) | 75034 |