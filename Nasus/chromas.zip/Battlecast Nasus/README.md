# Battlecast Nasus Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![75017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75017.png) | 75017 |
| ![75018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75018.png) | 75018 |
| ![75019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75019.png) | 75019 |
| ![75020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75020.png) | 75020 |
| ![75021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75021.png) | 75021 |
| ![75022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75022.png) | 75022 |
| ![75023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75023.png) | 75023 |
| ![75024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/75/75024.png) | 75024 |