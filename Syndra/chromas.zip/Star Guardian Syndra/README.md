# Star Guardian Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134035.png) | 134035 |
| ![134036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134036.png) | 134036 |
| ![134037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134037.png) | 134037 |
| ![134038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134038.png) | 134038 |
| ![134039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134039.png) | 134039 |
| ![134040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134040.png) | 134040 |
| ![134041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134041.png) | 134041 |
| ![134042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134042.png) | 134042 |
| ![134043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134043.png) | 134043 |