# Dumpling Darlings Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134066](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134066.png) | 134066 |
| ![134067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134067.png) | 134067 |
| ![134068](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134068.png) | 134068 |
| ![134069](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134069.png) | 134069 |
| ![134070](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134070.png) | 134070 |
| ![134071](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134071.png) | 134071 |
| ![134072](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134072.png) | 134072 |
| ![134073](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134073.png) | 134073 |