# Coven Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134055.png) | 134055 |
| ![134056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134056.png) | 134056 |
| ![134057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134057.png) | 134057 |
| ![134058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134058.png) | 134058 |
| ![134059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134059.png) | 134059 |
| ![134060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134060.png) | 134060 |
| ![134061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134061.png) | 134061 |
| ![134062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134062.png) | 134062 |
| ![134063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134063.png) | 134063 |