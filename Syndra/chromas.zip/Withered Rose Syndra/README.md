# Withered Rose Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134017.png) | 134017 |
| ![134018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134018.png) | 134018 |
| ![134019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134019.png) | 134019 |
| ![134020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134020.png) | 134020 |
| ![134021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134021.png) | 134021 |
| ![134022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134022.png) | 134022 |
| ![134023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134023.png) | 134023 |
| ![134024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134024.png) | 134024 |