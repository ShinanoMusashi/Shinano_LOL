# SKT T1 Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134064.png) | 134064 |