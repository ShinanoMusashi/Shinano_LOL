# Spirit Blossom Syndra Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![134045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134045.png) | 134045 |
| ![134046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134046.png) | 134046 |
| ![134047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134047.png) | 134047 |
| ![134048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134048.png) | 134048 |
| ![134049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134049.png) | 134049 |
| ![134050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134050.png) | 134050 |
| ![134051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134051.png) | 134051 |
| ![134052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134052.png) | 134052 |
| ![134053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/134/134053.png) | 134053 |