# Lunar Beast Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234002.png' alt='Chroma 234002' width='100'> | Chroma 234002 | 234002 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234003.png' alt='Chroma 234003' width='100'> | Chroma 234003 | 234003 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234004.png' alt='Chroma 234004' width='100'> | Chroma 234004 | 234004 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234005.png' alt='Chroma 234005' width='100'> | Chroma 234005 | 234005 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234006.png' alt='Chroma 234006' width='100'> | Chroma 234006 | 234006 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234007.png' alt='Chroma 234007' width='100'> | Chroma 234007 | 234007 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234008.png' alt='Chroma 234008' width='100'> | Chroma 234008 | 234008 |
