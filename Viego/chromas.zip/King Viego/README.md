# King Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234022.png' alt='Chroma 234022' width='100'> | Chroma 234022 | 234022 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234023.png' alt='Chroma 234023' width='100'> | Chroma 234023 | 234023 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234024.png' alt='Chroma 234024' width='100'> | Chroma 234024 | 234024 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234025.png' alt='Chroma 234025' width='100'> | Chroma 234025 | 234025 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234026.png' alt='Chroma 234026' width='100'> | Chroma 234026 | 234026 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234027.png' alt='Chroma 234027' width='100'> | Chroma 234027 | 234027 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234028.png' alt='Chroma 234028' width='100'> | Chroma 234028 | 234028 |
| 08 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234029.png' alt='Chroma 234029' width='100'> | Chroma 234029 | 234029 |
