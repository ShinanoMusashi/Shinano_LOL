# Worlds 2024 Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234038.png' alt='Chroma 234038' width='100'> | Chroma 234038 | 234038 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234039.png' alt='Chroma 234039' width='100'> | Chroma 234039 | 234039 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234040.png' alt='Chroma 234040' width='100'> | Chroma 234040 | 234040 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234041.png' alt='Chroma 234041' width='100'> | Chroma 234041 | 234041 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234042.png' alt='Chroma 234042' width='100'> | Chroma 234042 | 234042 |
