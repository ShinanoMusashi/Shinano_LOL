# Soul Fighter Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234031.png' alt='Chroma 234031' width='100'> | Chroma 234031 | 234031 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234032.png' alt='Chroma 234032' width='100'> | Chroma 234032 | 234032 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234033.png' alt='Chroma 234033' width='100'> | Chroma 234033 | 234033 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234034.png' alt='Chroma 234034' width='100'> | Chroma 234034 | 234034 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234035.png' alt='Chroma 234035' width='100'> | Chroma 234035 | 234035 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234036.png' alt='Chroma 234036' width='100'> | Chroma 234036 | 234036 |
