# EDG Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234020.png' alt='Chroma 234020' width='100'> | Chroma 234020 | 234020 |
