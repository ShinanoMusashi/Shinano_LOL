# Dissonance of Pentakill Viego Chromas

| Index | Preview | Chroma Name | Chroma ID |
|:---|:---|:---|:---|
| 01 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234011.png' alt='Chroma 234011' width='100'> | Chroma 234011 | 234011 |
| 02 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234012.png' alt='Chroma 234012' width='100'> | Chroma 234012 | 234012 |
| 03 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234013.png' alt='Chroma 234013' width='100'> | Chroma 234013 | 234013 |
| 04 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234014.png' alt='Chroma 234014' width='100'> | Chroma 234014 | 234014 |
| 05 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234015.png' alt='Chroma 234015' width='100'> | Chroma 234015 | 234015 |
| 06 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234016.png' alt='Chroma 234016' width='100'> | Chroma 234016 | 234016 |
| 07 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234017.png' alt='Chroma 234017' width='100'> | Chroma 234017 | 234017 |
| 08 | <img src='https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/234/234018.png' alt='Chroma 234018' width='100'> | Chroma 234018 | 234018 |
