# Blitzcrank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53008.png) | 53008 |
| ![53009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53009.png) | 53009 |
| ![53010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53010.png) | 53010 |