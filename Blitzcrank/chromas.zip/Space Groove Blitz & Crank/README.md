# Space Groove Blitz & Crank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53030.png) | 53030 |
| ![53031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53031.png) | 53031 |
| ![53032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53032.png) | 53032 |
| ![53033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53033.png) | 53033 |
| ![53034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53034.png) | 53034 |
| ![53035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53035.png) | 53035 |