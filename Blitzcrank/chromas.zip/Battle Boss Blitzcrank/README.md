# Battle Boss Blitzcrank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53012.png) | 53012 |
| ![53013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53013.png) | 53013 |
| ![53014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53014.png) | 53014 |
| ![53015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53015.png) | 53015 |
| ![53016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53016.png) | 53016 |
| ![53017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53017.png) | 53017 |
| ![53018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53018.png) | 53018 |
| ![53019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53019.png) | 53019 |