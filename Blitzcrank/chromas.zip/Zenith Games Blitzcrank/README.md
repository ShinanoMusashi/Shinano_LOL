# Zenith Games Blitzcrank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53048.png) | 53048 |
| ![53049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53049.png) | 53049 |
| ![53050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53050.png) | 53050 |
| ![53051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53051.png) | 53051 |
| ![53052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53052.png) | 53052 |
| ![53053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53053.png) | 53053 |
| ![53054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53054.png) | 53054 |
| ![53055](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53055.png) | 53055 |