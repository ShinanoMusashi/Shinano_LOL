# Victorious Blitzcrank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53037.png) | 53037 |
| ![53038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53038.png) | 53038 |
| ![53039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53039.png) | 53039 |
| ![53040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53040.png) | 53040 |
| ![53041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53041.png) | 53041 |
| ![53042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53042.png) | 53042 |
| ![53043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53043.png) | 53043 |
| ![53044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53044.png) | 53044 |
| ![53045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53045.png) | 53045 |
| ![53046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53046.png) | 53046 |