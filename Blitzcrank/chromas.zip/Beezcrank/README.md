# Beezcrank Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![53057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53057.png) | 53057 |
| ![53058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53058.png) | 53058 |
| ![53059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53059.png) | 53059 |
| ![53060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53060.png) | 53060 |
| ![53061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53061.png) | 53061 |
| ![53062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53062.png) | 53062 |
| ![53063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53063.png) | 53063 |
| ![53064](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/53/53064.png) | 53064 |