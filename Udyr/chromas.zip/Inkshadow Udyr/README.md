# Inkshadow Udyr Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![77007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/77/77007.png) | 77007 |
| ![77008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/77/77008.png) | 77008 |
| ![77009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/77/77009.png) | 77009 |
| ![77010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/77/77010.png) | 77010 |
| ![77011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/77/77011.png) | 77011 |