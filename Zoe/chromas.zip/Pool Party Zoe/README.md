# Pool Party Zoe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![142003](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142003.png) | 142003 |
| ![142004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142004.png) | 142004 |
| ![142005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142005.png) | 142005 |
| ![142006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142006.png) | 142006 |
| ![142007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142007.png) | 142007 |
| ![142008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142008.png) | 142008 |