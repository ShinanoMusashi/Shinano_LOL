# Dark Star Zoe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![142034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142034.png) | 142034 |
| ![142035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142035.png) | 142035 |
| ![142036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142036.png) | 142036 |
| ![142037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142037.png) | 142037 |
| ![142038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142038.png) | 142038 |
| ![142039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142039.png) | 142039 |
| ![142040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142040.png) | 142040 |
| ![142041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142041.png) | 142041 |
| ![142042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142042.png) | 142042 |