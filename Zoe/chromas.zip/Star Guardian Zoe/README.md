# Star Guardian Zoe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![142010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142010.png) | 142010 |
| ![142011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142011.png) | 142011 |
| ![142012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142012.png) | 142012 |
| ![142013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142013.png) | 142013 |
| ![142014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142014.png) | 142014 |
| ![142015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142015.png) | 142015 |
| ![142016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142016.png) | 142016 |
| ![142017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142017.png) | 142017 |