# EDG Zoe Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![142021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142021.png) | 142021 |
| ![142032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/142/142032.png) | 142032 |