# Battle Bunny Miss Fortune Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![21034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21034.png) | 21034 |
| ![21035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21035.png) | 21035 |
| ![21036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21036.png) | 21036 |
| ![21037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21037.png) | 21037 |
| ![21038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21038.png) | 21038 |
| ![21039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21039.png) | 21039 |