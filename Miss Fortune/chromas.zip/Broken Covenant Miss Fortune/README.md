# Broken Covenant Miss Fortune Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![21042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21042.png) | 21042 |
| ![21043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21043.png) | 21043 |
| ![21044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21044.png) | 21044 |
| ![21045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21045.png) | 21045 |
| ![21046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21046.png) | 21046 |
| ![21047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21047.png) | 21047 |
| ![21048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21048.png) | 21048 |
| ![21049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21049.png) | 21049 |