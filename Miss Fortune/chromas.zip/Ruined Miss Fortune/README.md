# Ruined Miss Fortune Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![21022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21022.png) | 21022 |
| ![21023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21023.png) | 21023 |
| ![21024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21024.png) | 21024 |
| ![21025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21025.png) | 21025 |
| ![21026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21026.png) | 21026 |
| ![21027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21027.png) | 21027 |
| ![21028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21028.png) | 21028 |
| ![21029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21029.png) | 21029 |
| ![21030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/21/21030.png) | 21030 |