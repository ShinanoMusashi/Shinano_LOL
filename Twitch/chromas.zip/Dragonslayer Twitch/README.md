# Dragonslayer Twitch Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29037.png) | 29037 |
| ![29038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29038.png) | 29038 |
| ![29039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29039.png) | 29039 |
| ![29040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29040.png) | 29040 |
| ![29041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29041.png) | 29041 |
| ![29042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29042.png) | 29042 |
| ![29043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29043.png) | 29043 |
| ![29044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29044.png) | 29044 |