# Twitch Shadowfoot Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29028.png) | 29028 |
| ![29029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29029.png) | 29029 |
| ![29030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29030.png) | 29030 |
| ![29031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29031.png) | 29031 |
| ![29032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29032.png) | 29032 |
| ![29033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29033.png) | 29033 |
| ![29034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29034.png) | 29034 |
| ![29035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29035.png) | 29035 |