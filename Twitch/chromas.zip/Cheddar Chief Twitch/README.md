# Cheddar Chief Twitch Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29056](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29056.png) | 29056 |
| ![29057](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29057.png) | 29057 |
| ![29058](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29058.png) | 29058 |
| ![29059](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29059.png) | 29059 |
| ![29060](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29060.png) | 29060 |
| ![29061](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29061.png) | 29061 |
| ![29062](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29062.png) | 29062 |
| ![29063](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29063.png) | 29063 |