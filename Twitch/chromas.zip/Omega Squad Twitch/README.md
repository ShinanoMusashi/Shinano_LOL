# Omega Squad Twitch Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29009.png) | 29009 |
| ![29010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29010.png) | 29010 |
| ![29011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29011.png) | 29011 |