# Medieval Twitch Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29021.png) | 29021 |
| ![29023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29023.png) | 29023 |
| ![29024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29024.png) | 29024 |