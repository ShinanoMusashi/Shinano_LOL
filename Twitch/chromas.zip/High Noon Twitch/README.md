# High Noon Twitch Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![29046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29046.png) | 29046 |
| ![29047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29047.png) | 29047 |
| ![29048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29048.png) | 29048 |
| ![29049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29049.png) | 29049 |
| ![29050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29050.png) | 29050 |
| ![29051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29051.png) | 29051 |
| ![29052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29052.png) | 29052 |
| ![29053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29053.png) | 29053 |
| ![29054](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/29/29054.png) | 29054 |