# Fright Night Nunu & Willump Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![20045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20045.png) | 20045 |
| ![20046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20046.png) | 20046 |
| ![20047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20047.png) | 20047 |
| ![20048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20048.png) | 20048 |
| ![20049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20049.png) | 20049 |
| ![20050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20050.png) | 20050 |
| ![20051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20051.png) | 20051 |
| ![20052](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20052.png) | 20052 |
| ![20053](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20053.png) | 20053 |