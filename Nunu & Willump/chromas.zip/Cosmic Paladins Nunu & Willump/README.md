# Cosmic Paladins Nunu & Willump Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![20036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20036.png) | 20036 |
| ![20037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20037.png) | 20037 |
| ![20038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20038.png) | 20038 |
| ![20039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20039.png) | 20039 |
| ![20040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20040.png) | 20040 |
| ![20041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20041.png) | 20041 |
| ![20042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20042.png) | 20042 |
| ![20043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20043.png) | 20043 |