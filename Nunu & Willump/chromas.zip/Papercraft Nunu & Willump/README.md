# Papercraft Nunu & Willump Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![20009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20009.png) | 20009 |
| ![20010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20010.png) | 20010 |
| ![20011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20011.png) | 20011 |
| ![20012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20012.png) | 20012 |
| ![20013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20013.png) | 20013 |
| ![20014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20014.png) | 20014 |
| ![20015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20015.png) | 20015 |