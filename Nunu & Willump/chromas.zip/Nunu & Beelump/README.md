# Nunu & Beelump Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![20027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20027.png) | 20027 |
| ![20028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20028.png) | 20028 |
| ![20029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20029.png) | 20029 |
| ![20030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20030.png) | 20030 |
| ![20031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20031.png) | 20031 |
| ![20032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20032.png) | 20032 |
| ![20033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20033.png) | 20033 |
| ![20034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/20/20034.png) | 20034 |