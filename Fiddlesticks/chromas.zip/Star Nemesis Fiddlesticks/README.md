# Star Nemesis Fiddlesticks Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![9028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9028.png) | 9028 |
| ![9029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9029.png) | 9029 |
| ![9030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9030.png) | 9030 |
| ![9031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9031.png) | 9031 |
| ![9032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9032.png) | 9032 |
| ![9033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9033.png) | 9033 |
| ![9034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9034.png) | 9034 |
| ![9035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9035.png) | 9035 |
| ![9036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9036.png) | 9036 |