# Praetorian Fiddlesticks Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![9010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9010.png) | 9010 |
| ![9011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9011.png) | 9011 |
| ![9012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9012.png) | 9012 |
| ![9013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9013.png) | 9013 |
| ![9014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9014.png) | 9014 |
| ![9015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9015.png) | 9015 |