# Surprise Party Fiddlesticks Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![9016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9016.png) | 9016 |
| ![9017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9017.png) | 9017 |
| ![9018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9018.png) | 9018 |