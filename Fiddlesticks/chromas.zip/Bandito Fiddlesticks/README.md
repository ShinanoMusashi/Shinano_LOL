# Bandito Fiddlesticks Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![9019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9019.png) | 9019 |
| ![9020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9020.png) | 9020 |
| ![9021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9021.png) | 9021 |
| ![9022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9022.png) | 9022 |
| ![9023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9023.png) | 9023 |
| ![9024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9024.png) | 9024 |
| ![9025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9025.png) | 9025 |
| ![9026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9026.png) | 9026 |