# Blood Moon Fiddlesticks Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![9038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9038.png) | 9038 |
| ![9039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9039.png) | 9039 |
| ![9040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9040.png) | 9040 |
| ![9041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9041.png) | 9041 |
| ![9042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9042.png) | 9042 |
| ![9043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9043.png) | 9043 |
| ![9044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9044.png) | 9044 |
| ![9045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/9/9045.png) | 9045 |