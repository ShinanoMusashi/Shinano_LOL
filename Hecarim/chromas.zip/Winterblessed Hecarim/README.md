# Winterblessed Hecarim Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![120032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120032.png) | 120032 |
| ![120033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120033.png) | 120033 |
| ![120034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120034.png) | 120034 |
| ![120035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120035.png) | 120035 |
| ![120036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120036.png) | 120036 |
| ![120037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120037.png) | 120037 |
| ![120038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120038.png) | 120038 |
| ![120039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120039.png) | 120039 |
| ![120040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120040.png) | 120040 |