# Cosmic Charger Hecarim Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![120015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120015.png) | 120015 |
| ![120016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120016.png) | 120016 |
| ![120017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120017.png) | 120017 |
| ![120018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120018.png) | 120018 |
| ![120019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120019.png) | 120019 |
| ![120020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120020.png) | 120020 |
| ![120021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120021.png) | 120021 |