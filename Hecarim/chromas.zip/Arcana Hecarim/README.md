# Arcana Hecarim Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![120023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120023.png) | 120023 |
| ![120024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120024.png) | 120024 |
| ![120025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120025.png) | 120025 |
| ![120026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120026.png) | 120026 |
| ![120027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120027.png) | 120027 |
| ![120028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120028.png) | 120028 |
| ![120029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120029.png) | 120029 |
| ![120030](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120030.png) | 120030 |