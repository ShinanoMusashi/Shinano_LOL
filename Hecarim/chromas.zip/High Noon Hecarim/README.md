# High Noon Hecarim Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![120009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120009.png) | 120009 |
| ![120010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120010.png) | 120010 |
| ![120011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120011.png) | 120011 |
| ![120012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120012.png) | 120012 |
| ![120013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/120/120013.png) | 120013 |