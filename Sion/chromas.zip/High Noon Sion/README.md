# High Noon Sion Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![14031](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14031.png) | 14031 |
| ![14032](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14032.png) | 14032 |
| ![14033](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14033.png) | 14033 |
| ![14034](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14034.png) | 14034 |
| ![14035](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14035.png) | 14035 |
| ![14036](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14036.png) | 14036 |
| ![14037](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14037.png) | 14037 |
| ![14038](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14038.png) | 14038 |
| ![14039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14039.png) | 14039 |