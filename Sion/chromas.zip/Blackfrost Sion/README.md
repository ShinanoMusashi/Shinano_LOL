# Blackfrost Sion Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![14023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14023.png) | 14023 |
| ![14024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14024.png) | 14024 |
| ![14025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14025.png) | 14025 |
| ![14026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14026.png) | 14026 |
| ![14027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14027.png) | 14027 |
| ![14028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14028.png) | 14028 |
| ![14029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14029.png) | 14029 |