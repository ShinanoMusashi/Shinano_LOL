# Cosmic Paladin Sion Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![14041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14041.png) | 14041 |
| ![14042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14042.png) | 14042 |
| ![14043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14043.png) | 14043 |
| ![14044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14044.png) | 14044 |
| ![14045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14045.png) | 14045 |
| ![14046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14046.png) | 14046 |
| ![14047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14047.png) | 14047 |
| ![14048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14048.png) | 14048 |