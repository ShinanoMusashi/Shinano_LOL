# Mecha Zero Sion Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![14006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14006.png) | 14006 |
| ![14007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14007.png) | 14007 |
| ![14008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14008.png) | 14008 |
| ![14009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14009.png) | 14009 |
| ![14010](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14010.png) | 14010 |
| ![14011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14011.png) | 14011 |
| ![14012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14012.png) | 14012 |
| ![14013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/14/14013.png) | 14013 |