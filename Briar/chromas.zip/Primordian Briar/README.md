# Primordian Briar Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![233011](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233011.png) | 233011 |
| ![233012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233012.png) | 233012 |
| ![233013](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233013.png) | 233013 |
| ![233014](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233014.png) | 233014 |
| ![233015](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233015.png) | 233015 |
| ![233016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233016.png) | 233016 |
| ![233017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233017.png) | 233017 |
| ![233018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233018.png) | 233018 |
| ![233019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/233/233019.png) | 233019 |