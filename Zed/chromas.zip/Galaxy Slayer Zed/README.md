# Galaxy Slayer Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238024.png) | 238024 |
| ![238025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238025.png) | 238025 |
| ![238026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238026.png) | 238026 |
| ![238027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238027.png) | 238027 |
| ![238028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238028.png) | 238028 |
| ![238029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238029.png) | 238029 |
| ![238039](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238039.png) | 238039 |