# Empyrean Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238040](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238040.png) | 238040 |
| ![238041](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238041.png) | 238041 |
| ![238042](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238042.png) | 238042 |
| ![238043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238043.png) | 238043 |
| ![238044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238044.png) | 238044 |
| ![238045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238045.png) | 238045 |
| ![238046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238046.png) | 238046 |
| ![238047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238047.png) | 238047 |
| ![238048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238048.png) | 238048 |