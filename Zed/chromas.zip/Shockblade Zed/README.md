# Shockblade Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238004](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238004.png) | 238004 |
| ![238005](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238005.png) | 238005 |
| ![238006](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238006.png) | 238006 |
| ![238007](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238007.png) | 238007 |
| ![238008](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238008.png) | 238008 |
| ![238009](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238009.png) | 238009 |