# Worlds 2016 Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238012](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238012.png) | 238012 |