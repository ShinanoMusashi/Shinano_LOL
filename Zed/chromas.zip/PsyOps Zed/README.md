# PsyOps Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238016](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238016.png) | 238016 |
| ![238017](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238017.png) | 238017 |
| ![238018](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238018.png) | 238018 |
| ![238019](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238019.png) | 238019 |
| ![238020](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238020.png) | 238020 |
| ![238021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238021.png) | 238021 |
| ![238022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238022.png) | 238022 |
| ![238023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238023.png) | 238023 |