# SKT T1 Zed Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![238067](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/238/238067.png) | 238067 |