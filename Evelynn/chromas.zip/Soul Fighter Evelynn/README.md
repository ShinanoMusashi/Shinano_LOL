# Soul Fighter Evelynn Chromas

| Chroma ID | Preview | Unique number |
|---|---|---|
| `28043` | ![28043](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28043.png) | 1 |
| `28044` | ![28044](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28044.png) | 2 |
| `28045` | ![28045](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28045.png) | 3 |
| `28046` | ![28046](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28046.png) | 4 |
| `28047` | ![28047](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28047.png) | 5 |
| `28048` | ![28048](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28048.png) | 6 |
| `28049` | ![28049](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28049.png) | 7 |
| `28050` | ![28050](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28050.png) | 8 |
| `28051` | ![28051](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/28/28051.png) | 9 |

---

**Note:** 'Unique number' is just a sequential counter for the chromas listed in the API for this skin.