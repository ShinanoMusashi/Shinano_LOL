# High Noon Rell Chromas

| Preview | Chroma ID |
|---------|-----------|
| ![526021](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526021.png) | 526021 |
| ![526022](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526022.png) | 526022 |
| ![526023](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526023.png) | 526023 |
| ![526024](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526024.png) | 526024 |
| ![526025](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526025.png) | 526025 |
| ![526026](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526026.png) | 526026 |
| ![526027](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526027.png) | 526027 |
| ![526028](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526028.png) | 526028 |
| ![526029](https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/v1/champion-chroma-images/526/526029.png) | 526029 |